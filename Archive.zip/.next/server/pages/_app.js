"use strict";
(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 66267:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13126);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks_useConfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20132);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
 // third-party


 // load locales files




const loadLocaleData = locale => {
  switch (locale) {
    case 'fr':
      return __webpack_require__.e(/* import() */ 9252).then(__webpack_require__.t.bind(__webpack_require__, 69252, 19));

    case 'ro':
      return __webpack_require__.e(/* import() */ 2946).then(__webpack_require__.t.bind(__webpack_require__, 82946, 19));

    case 'zh':
      return __webpack_require__.e(/* import() */ 6893).then(__webpack_require__.t.bind(__webpack_require__, 66893, 19));

    default:
      return __webpack_require__.e(/* import() */ 4762).then(__webpack_require__.t.bind(__webpack_require__, 84762, 19));
  }
}; // ==============================|| LOCALIZATION ||============================== //


const Locales = ({
  children
}) => {
  const {
    locale
  } = (0,hooks_useConfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
  const {
    0: messages,
    1: setMessages
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    loadLocaleData(locale).then(d => {
      setMessages(d.default);
    });
  }, [locale]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: messages && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_intl__WEBPACK_IMPORTED_MODULE_1__.IntlProvider, {
      locale: locale,
      defaultLocale: "en",
      messages: messages,
      children: children
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Locales);

/***/ }),

/***/ 27476:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ui_component_RTLLayout)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
;// CONCATENATED MODULE: external "@emotion/react"
const react_namespaceObject = require("@emotion/react");
;// CONCATENATED MODULE: external "@emotion/cache"
const cache_namespaceObject = require("@emotion/cache");
var cache_default = /*#__PURE__*/__webpack_require__.n(cache_namespaceObject);
;// CONCATENATED MODULE: external "stylis-plugin-rtl"
const external_stylis_plugin_rtl_namespaceObject = require("stylis-plugin-rtl");
var external_stylis_plugin_rtl_default = /*#__PURE__*/__webpack_require__.n(external_stylis_plugin_rtl_namespaceObject);
// EXTERNAL MODULE: ./src/hooks/useConfig.js
var useConfig = __webpack_require__(20132);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/ui-component/RTLLayout.js
 // material-ui


 // third-party


 // ==============================|| RTL LAYOUT ||============================== //



const RTLLayout = ({
  children
}) => {
  const {
    rtlLayout
  } = (0,useConfig/* default */.Z)();
  (0,external_react_.useEffect)(() => {
    document.dir = rtlLayout ? 'rtl' : 'ltr';
  }, [rtlLayout]);
  const cacheRtl = cache_default()({
    key: rtlLayout ? 'rtl' : 'css',
    prepend: true,
    stylisPlugins: rtlLayout ? [(external_stylis_plugin_rtl_default())] : []
  });
  return /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.CacheProvider, {
    value: cacheRtl,
    children: children
  });
};

/* harmony default export */ const ui_component_RTLLayout = (RTLLayout);

/***/ }),

/***/ 67880:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ extended_Snackbar)
});

// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(65692);
;// CONCATENATED MODULE: external "@mui/material/Snackbar"
const Snackbar_namespaceObject = require("@mui/material/Snackbar");
var Snackbar_default = /*#__PURE__*/__webpack_require__.n(Snackbar_namespaceObject);
// EXTERNAL MODULE: external "@mui/icons-material/Close"
var Close_ = __webpack_require__(4173);
var Close_default = /*#__PURE__*/__webpack_require__.n(Close_);
// EXTERNAL MODULE: ./src/store/index.js + 2 modules
var store = __webpack_require__(95394);
// EXTERNAL MODULE: ./src/store/slices/snackbar.js
var slices_snackbar = __webpack_require__(12686);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/ui-component/extended/Snackbar.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// material-ui

 // assets



 // animation function





function TransitionSlideLeft(props) {
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Slide, _objectSpread(_objectSpread({}, props), {}, {
    direction: "left"
  }));
}

function TransitionSlideUp(props) {
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Slide, _objectSpread(_objectSpread({}, props), {}, {
    direction: "up"
  }));
}

function TransitionSlideRight(props) {
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Slide, _objectSpread(_objectSpread({}, props), {}, {
    direction: "right"
  }));
}

function TransitionSlideDown(props) {
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Slide, _objectSpread(_objectSpread({}, props), {}, {
    direction: "down"
  }));
}

function GrowTransition(props) {
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Grow, _objectSpread({}, props));
} // animation options


const animation = {
  SlideLeft: TransitionSlideLeft,
  SlideUp: TransitionSlideUp,
  SlideRight: TransitionSlideRight,
  SlideDown: TransitionSlideDown,
  Grow: GrowTransition,
  Fade: material_.Fade
}; // ==============================|| SNACKBAR ||============================== //

const Snackbar = () => {
  const dispatch = (0,store/* useDispatch */.I0)();
  const snackbar = (0,store/* useSelector */.v9)(state => state.snackbar);
  const {
    actionButton,
    anchorOrigin,
    alert,
    close,
    message,
    open,
    transition,
    variant
  } = snackbar;

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    dispatch((0,slices_snackbar/* closeSnackbar */.sy)());
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [variant === 'default' && /*#__PURE__*/jsx_runtime_.jsx((Snackbar_default()), {
      anchorOrigin: anchorOrigin,
      open: open,
      autoHideDuration: 6000,
      onClose: handleClose,
      message: message,
      TransitionComponent: animation[transition],
      action: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
          color: "secondary",
          size: "small",
          onClick: handleClose,
          children: "UNDO"
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.IconButton, {
          size: "small",
          "aria-label": "close",
          color: "inherit",
          onClick: handleClose,
          sx: {
            mt: 0.25
          },
          children: /*#__PURE__*/jsx_runtime_.jsx((Close_default()), {
            fontSize: "small"
          })
        })]
      })
    }), variant === 'alert' && /*#__PURE__*/jsx_runtime_.jsx((Snackbar_default()), {
      TransitionComponent: animation[transition],
      anchorOrigin: anchorOrigin,
      open: open,
      autoHideDuration: 6000,
      onClose: handleClose,
      children: /*#__PURE__*/jsx_runtime_.jsx(material_.Alert, {
        variant: alert.variant,
        color: alert.color,
        action: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [actionButton !== false && /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
            size: "small",
            onClick: handleClose,
            sx: {
              color: 'background.paper'
            },
            children: "UNDO"
          }), close !== false && /*#__PURE__*/jsx_runtime_.jsx(material_.IconButton, {
            sx: {
              color: 'background.paper'
            },
            size: "small",
            "aria-label": "close",
            onClick: handleClose,
            children: /*#__PURE__*/jsx_runtime_.jsx((Close_default()), {
              fontSize: "small"
            })
          })]
        }),
        sx: _objectSpread({}, alert.variant === 'outlined' && {
          bgcolor: 'background.paper'
        }),
        children: message
      })
    })]
  });
};

/* harmony default export */ const extended_Snackbar = (Snackbar);

/***/ }),

/***/ 55216:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Customization__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(91323);
/* harmony import */ var utils_route_guard_GuestGuard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62182);
/* harmony import */ var _NavMotion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(78358);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Customization__WEBPACK_IMPORTED_MODULE_0__, _NavMotion__WEBPACK_IMPORTED_MODULE_2__]);
([_Customization__WEBPACK_IMPORTED_MODULE_0__, _NavMotion__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// project imports


 // ==============================|| MINIMAL LAYOUT ||============================== //





const GuestGuardLayout = ({
  children
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_NavMotion__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(utils_route_guard_GuestGuard__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
      children: [children, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_Customization__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {})]
    })
  })
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GuestGuardLayout);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 76330:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ MainLayout_Header)
});

// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(18442);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(65692);
// EXTERNAL MODULE: ./src/layout/MainLayout/LogoSection/index.js
var LogoSection = __webpack_require__(1684);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
;// CONCATENATED MODULE: external "material-ui-popup-state"
const external_material_ui_popup_state_namespaceObject = require("material-ui-popup-state");
// EXTERNAL MODULE: ./src/components/ui-component/extended/Transitions.js
var extended_Transitions = __webpack_require__(82977);
// EXTERNAL MODULE: external "@tabler/icons"
var icons_ = __webpack_require__(94116);
// EXTERNAL MODULE: external "@mui/system"
var system_ = __webpack_require__(97986);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Header/SearchSection/index.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // material-ui


 // third-party

 // project imports

 // assets


 // styles




const PopperStyle = (0,styles_.styled)(material_.Popper, {
  shouldForwardProp: system_.shouldForwardProp
})(({
  theme
}) => ({
  zIndex: 1100,
  width: '99%',
  top: '-55px !important',
  padding: '0 12px',
  [theme.breakpoints.down('sm')]: {
    padding: '0 10px'
  }
}));
const OutlineInputStyle = (0,styles_.styled)(material_.OutlinedInput, {
  shouldForwardProp: system_.shouldForwardProp
})(({
  theme
}) => ({
  width: 434,
  marginLeft: 16,
  paddingLeft: 16,
  paddingRight: 16,
  '& input': {
    background: 'transparent !important',
    paddingLeft: '4px !important'
  },
  [theme.breakpoints.down('lg')]: {
    width: 250
  },
  [theme.breakpoints.down('md')]: {
    width: '100%',
    marginLeft: 4,
    background: theme.palette.mode === 'dark' ? theme.palette.dark[800] : '#fff'
  }
}));
const HeaderAvatarStyle = (0,styles_.styled)(material_.Avatar, {
  shouldForwardProp: system_.shouldForwardProp
})(({
  theme
}) => _objectSpread(_objectSpread(_objectSpread({}, theme.typography.commonAvatar), theme.typography.mediumAvatar), {}, {
  background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.secondary.light,
  color: theme.palette.mode === 'dark' ? theme.palette.secondary.main : theme.palette.secondary.dark,
  '&:hover': {
    background: theme.palette.mode === 'dark' ? theme.palette.secondary.main : theme.palette.secondary.dark,
    color: theme.palette.mode === 'dark' ? theme.palette.secondary.light : theme.palette.secondary.light
  }
})); // ==============================|| SEARCH INPUT - MOBILE||============================== //

const MobileSearch = ({
  value,
  setValue,
  popupState
}) => {
  const theme = useTheme();
  return /*#__PURE__*/_jsx(OutlineInputStyle, {
    id: "input-search-header",
    value: value,
    onChange: e => setValue(e.target.value),
    placeholder: "Search",
    startAdornment: /*#__PURE__*/_jsx(InputAdornment, {
      position: "start",
      children: /*#__PURE__*/_jsx(IconSearch, {
        stroke: 1.5,
        size: "1rem",
        color: theme.palette.grey[500]
      })
    }),
    endAdornment: /*#__PURE__*/_jsxs(InputAdornment, {
      position: "end",
      children: [/*#__PURE__*/_jsx(HeaderAvatarStyle, {
        variant: "rounded",
        children: /*#__PURE__*/_jsx(IconAdjustmentsHorizontal, {
          stroke: 1.5,
          size: "1.3rem"
        })
      }), /*#__PURE__*/_jsx(Box, {
        sx: {
          ml: 2
        },
        children: /*#__PURE__*/_jsx(Avatar, _objectSpread(_objectSpread({
          variant: "rounded",
          sx: _objectSpread(_objectSpread(_objectSpread({}, theme.typography.commonAvatar), theme.typography.mediumAvatar), {}, {
            background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.orange.light,
            color: theme.palette.orange.dark,
            '&:hover': {
              background: theme.palette.orange.dark,
              color: theme.palette.orange.light
            }
          })
        }, bindToggle(popupState)), {}, {
          children: /*#__PURE__*/_jsx(IconX, {
            stroke: 1.5,
            size: "1.3rem"
          })
        }))
      })]
    }),
    "aria-describedby": "search-helper-text",
    inputProps: {
      'aria-label': 'weight'
    }
  });
};

// ==============================|| SEARCH INPUT ||============================== //
const SearchSection = () => {
  const theme = useTheme();
  const {
    0: value,
    1: setValue
  } = useState('');
  return /*#__PURE__*/_jsxs(_Fragment, {
    children: [/*#__PURE__*/_jsx(Box, {
      sx: {
        display: {
          xs: 'block',
          md: 'none'
        }
      },
      children: /*#__PURE__*/_jsx(PopupState, {
        variant: "popper",
        popupId: "demo-popup-popper",
        children: popupState => /*#__PURE__*/_jsxs(_Fragment, {
          children: [/*#__PURE__*/_jsx(Box, {
            sx: {
              ml: 2
            },
            children: /*#__PURE__*/_jsx(HeaderAvatarStyle, _objectSpread(_objectSpread({
              variant: "rounded"
            }, bindToggle(popupState)), {}, {
              children: /*#__PURE__*/_jsx(IconSearch, {
                stroke: 1.5,
                size: "1.2rem"
              })
            }))
          }), /*#__PURE__*/_jsx(PopperStyle, _objectSpread(_objectSpread({}, bindPopper(popupState)), {}, {
            transition: true,
            children: ({
              TransitionProps
            }) => /*#__PURE__*/_jsx(_Fragment, {
              children: /*#__PURE__*/_jsx(Transitions, _objectSpread(_objectSpread({
                type: "zoom"
              }, TransitionProps), {}, {
                sx: {
                  transformOrigin: 'center left'
                },
                children: /*#__PURE__*/_jsx(Card, {
                  sx: {
                    background: theme.palette.mode === 'dark' ? theme.palette.dark[900] : '#fff',
                    [theme.breakpoints.down('sm')]: {
                      border: 0,
                      boxShadow: 'none'
                    }
                  },
                  children: /*#__PURE__*/_jsx(Box, {
                    sx: {
                      p: 2
                    },
                    children: /*#__PURE__*/_jsx(Grid, {
                      container: true,
                      alignItems: "center",
                      justifyContent: "space-between",
                      children: /*#__PURE__*/_jsx(Grid, {
                        item: true,
                        xs: true,
                        children: /*#__PURE__*/_jsx(MobileSearch, {
                          value: value,
                          setValue: setValue,
                          popupState: popupState
                        })
                      })
                    })
                  })
                })
              }))
            })
          }))]
        })
      })
    }), /*#__PURE__*/_jsx(Box, {
      sx: {
        display: {
          xs: 'none',
          md: 'block'
        }
      },
      children: /*#__PURE__*/_jsx(OutlineInputStyle, {
        id: "input-search-header",
        value: value,
        onChange: e => setValue(e.target.value),
        placeholder: "Search",
        startAdornment: /*#__PURE__*/_jsx(InputAdornment, {
          position: "start",
          children: /*#__PURE__*/_jsx(IconSearch, {
            stroke: 1.5,
            size: "1rem",
            color: theme.palette.grey[500]
          })
        }),
        endAdornment: /*#__PURE__*/_jsx(InputAdornment, {
          position: "end",
          children: /*#__PURE__*/_jsx(HeaderAvatarStyle, {
            variant: "rounded",
            children: /*#__PURE__*/_jsx(IconAdjustmentsHorizontal, {
              stroke: 1.5,
              size: "1.3rem"
            })
          })
        }),
        "aria-describedby": "search-helper-text",
        inputProps: {
          'aria-label': 'weight'
        }
      })
    })]
  });
};

/* harmony default export */ const Header_SearchSection = ((/* unused pure expression or super */ null && (SearchSection)));
;// CONCATENATED MODULE: external "@mui/icons-material/TranslateTwoTone"
const TranslateTwoTone_namespaceObject = require("@mui/icons-material/TranslateTwoTone");
// EXTERNAL MODULE: ./src/hooks/useConfig.js
var hooks_useConfig = __webpack_require__(20132);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Header/LocalizationSection/index.js
function LocalizationSection_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function LocalizationSection_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { LocalizationSection_ownKeys(Object(source), true).forEach(function (key) { LocalizationSection_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { LocalizationSection_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function LocalizationSection_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // material-ui


 // project imports

 // assets


 // ==============================|| LOCALIZATION ||============================== //





const LocalizationSection_LocalizationSection = () => {
  const {
    borderRadius,
    locale,
    onChangeLocale
  } = useConfig();
  const theme = useTheme();
  const matchesXs = useMediaQuery(theme.breakpoints.down('md'));
  const {
    0: open,
    1: setOpen
  } = useState(false);
  const anchorRef = useRef(null);
  const {
    0: language,
    1: setLanguage
  } = useState(locale);

  const handleListItemClick = (event, lng) => {
    setLanguage(lng);
    onChangeLocale(lng);
    setOpen(false);
  };

  const handleToggle = () => {
    setOpen(prevOpen => !prevOpen);
  };

  const handleClose = event => {
    if (anchorRef.current && anchorRef.current.contains(event.target)) {
      return;
    }

    setOpen(false);
  };

  const prevOpen = useRef(open);
  useEffect(() => {
    if (prevOpen.current === true && open === false) {
      anchorRef.current.focus();
    }

    prevOpen.current = open;
  }, [open]);
  useEffect(() => {
    setLanguage(locale);
  }, [locale]);
  return /*#__PURE__*/_jsxs(_Fragment, {
    children: [/*#__PURE__*/_jsx(Box, {
      sx: {
        ml: 2,
        [theme.breakpoints.down('md')]: {
          ml: 1
        }
      },
      children: /*#__PURE__*/_jsxs(Avatar, {
        variant: "rounded",
        sx: LocalizationSection_objectSpread(LocalizationSection_objectSpread(LocalizationSection_objectSpread({}, theme.typography.commonAvatar), theme.typography.mediumAvatar), {}, {
          border: '1px solid',
          borderColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.primary.light,
          background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.primary.light,
          color: theme.palette.primary.dark,
          transition: 'all .2s ease-in-out',
          '&[aria-controls="menu-list-grow"],&:hover': {
            borderColor: theme.palette.primary.main,
            background: theme.palette.primary.main,
            color: theme.palette.primary.light
          }
        }),
        ref: anchorRef,
        "aria-controls": open ? 'menu-list-grow' : undefined,
        "aria-haspopup": "true",
        onClick: handleToggle,
        color: "inherit",
        children: [language !== 'en' && /*#__PURE__*/_jsx(Typography, {
          variant: "h5",
          sx: {
            textTransform: 'uppercase'
          },
          color: "inherit",
          children: language
        }), language === 'en' && /*#__PURE__*/_jsx(TranslateTwoToneIcon, {
          sx: {
            fontSize: '1.3rem'
          }
        })]
      })
    }), /*#__PURE__*/_jsx(Popper, {
      placement: matchesXs ? 'bottom-start' : 'bottom',
      open: open,
      anchorEl: anchorRef.current,
      role: undefined,
      transition: true,
      disablePortal: true,
      popperOptions: {
        modifiers: [{
          name: 'offset',
          options: {
            offset: [matchesXs ? 0 : 0, 20]
          }
        }]
      },
      children: ({
        TransitionProps
      }) => /*#__PURE__*/_jsx(ClickAwayListener, {
        onClickAway: handleClose,
        children: /*#__PURE__*/_jsx(Transitions, LocalizationSection_objectSpread(LocalizationSection_objectSpread({
          position: matchesXs ? 'top-left' : 'top',
          in: open
        }, TransitionProps), {}, {
          children: /*#__PURE__*/_jsx(Paper, {
            elevation: 16,
            children: open && /*#__PURE__*/_jsxs(List, {
              component: "nav",
              sx: {
                width: '100%',
                minWidth: 200,
                maxWidth: 280,
                bgcolor: theme.palette.background.paper,
                borderRadius: `${borderRadius}px`,
                [theme.breakpoints.down('md')]: {
                  maxWidth: 250
                }
              },
              children: [/*#__PURE__*/_jsx(ListItemButton, {
                selected: language === 'en',
                onClick: event => handleListItemClick(event, 'en'),
                children: /*#__PURE__*/_jsx(ListItemText, {
                  primary: /*#__PURE__*/_jsxs(Grid, {
                    container: true,
                    children: [/*#__PURE__*/_jsx(Typography, {
                      color: "textPrimary",
                      children: "English"
                    }), /*#__PURE__*/_jsx(Typography, {
                      variant: "caption",
                      color: "textSecondary",
                      sx: {
                        ml: '8px'
                      },
                      children: "(UK)"
                    })]
                  })
                })
              }), /*#__PURE__*/_jsx(ListItemButton, {
                selected: language === 'fr',
                onClick: event => handleListItemClick(event, 'fr'),
                children: /*#__PURE__*/_jsx(ListItemText, {
                  primary: /*#__PURE__*/_jsxs(Grid, {
                    container: true,
                    children: [/*#__PURE__*/_jsx(Typography, {
                      color: "textPrimary",
                      children: "fran\xE7ais"
                    }), /*#__PURE__*/_jsx(Typography, {
                      variant: "caption",
                      color: "textSecondary",
                      sx: {
                        ml: '8px'
                      },
                      children: "(French)"
                    })]
                  })
                })
              }), /*#__PURE__*/_jsx(ListItemButton, {
                selected: language === 'ro',
                onClick: event => handleListItemClick(event, 'ro'),
                children: /*#__PURE__*/_jsx(ListItemText, {
                  primary: /*#__PURE__*/_jsxs(Grid, {
                    container: true,
                    children: [/*#__PURE__*/_jsx(Typography, {
                      color: "textPrimary",
                      children: "Rom\xE2n\u0103"
                    }), /*#__PURE__*/_jsx(Typography, {
                      variant: "caption",
                      color: "textSecondary",
                      sx: {
                        ml: '8px'
                      },
                      children: "(Romanian)"
                    })]
                  })
                })
              }), /*#__PURE__*/_jsx(ListItemButton, {
                selected: language === 'zh',
                onClick: event => handleListItemClick(event, 'zh'),
                children: /*#__PURE__*/_jsx(ListItemText, {
                  primary: /*#__PURE__*/_jsxs(Grid, {
                    container: true,
                    children: [/*#__PURE__*/_jsx(Typography, {
                      color: "textPrimary",
                      children: "\u4E2D\u56FD\u4EBA"
                    }), /*#__PURE__*/_jsx(Typography, {
                      variant: "caption",
                      color: "textSecondary",
                      sx: {
                        ml: '8px'
                      },
                      children: "(Chinese)"
                    })]
                  })
                })
              })]
            })
          })
        }))
      })
    })]
  });
};

/* harmony default export */ const Header_LocalizationSection = ((/* unused pure expression or super */ null && (LocalizationSection_LocalizationSection)));
;// CONCATENATED MODULE: ./src/layout/MainLayout/Header/MobileSection/index.js
function MobileSection_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function MobileSection_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { MobileSection_ownKeys(Object(source), true).forEach(function (key) { MobileSection_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { MobileSection_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function MobileSection_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // material-ui


 // project imports


 // assets

 // ==============================|| MOBILE HEADER ||============================== //





const MobileSection = () => {
  const theme = useTheme();
  const matchMobile = useMediaQuery(theme.breakpoints.down('md'));
  const {
    0: open,
    1: setOpen
  } = useState(false);
  /**
   * anchorRef is used on different componets and specifying one type leads to other components throwing an error
   * */

  const anchorRef = useRef(null);

  const handleToggle = () => {
    setOpen(prevOpen => !prevOpen);
  };

  const handleClose = event => {
    if (anchorRef.current && anchorRef.current.contains(event.target)) {
      return;
    }

    setOpen(false);
  };

  const prevOpen = useRef(open);
  useEffect(() => {
    if (prevOpen.current === true && open === false) {
      anchorRef.current.focus();
    }

    prevOpen.current = open;
  }, [open]);
  return /*#__PURE__*/_jsxs(_Fragment, {
    children: [/*#__PURE__*/_jsx(Box, {
      component: "span",
      ref: anchorRef,
      sx: {
        mt: 1,
        ml: 1
      },
      children: /*#__PURE__*/_jsx(IconButton, {
        sx: {
          color: theme.palette.mode === 'dark' ? 'primary.main' : 'inherit',
          ml: 0.5,
          cursor: 'pointer'
        },
        onClick: handleToggle,
        children: /*#__PURE__*/_jsx(IconDotsVertical, {
          stroke: 1.5,
          "aria-controls": open ? 'menu-list-grow' : undefined,
          "aria-haspopup": "true",
          style: {
            fontSize: '1.5rem'
          }
        })
      })
    }), /*#__PURE__*/_jsx(Popper, {
      placement: "bottom-end",
      open: open,
      anchorEl: anchorRef.current,
      role: undefined,
      transition: true,
      disablePortal: true,
      style: {
        width: '100%',
        zIndex: 1
      },
      popperOptions: {
        modifiers: [{
          name: 'offset',
          options: {
            offset: [0, matchMobile ? 30 : 10]
          }
        }]
      },
      children: ({
        TransitionProps
      }) => /*#__PURE__*/_jsx(ClickAwayListener, {
        onClickAway: handleClose,
        children: /*#__PURE__*/_jsx(Transitions, MobileSection_objectSpread(MobileSection_objectSpread({
          type: "zoom",
          in: open
        }, TransitionProps), {}, {
          sx: {
            transformOrigin: 'top right'
          },
          children: /*#__PURE__*/_jsx(Paper, {
            children: open && /*#__PURE__*/_jsx(AppBar, {
              color: "inherit",
              sx: {
                [theme.breakpoints.down('md')]: {
                  background: theme.palette.mode === 'dark' ? theme.palette.dark[800] : '#fff'
                }
              },
              children: /*#__PURE__*/_jsx(Toolbar, {
                sx: {
                  pt: 2.75,
                  pb: 2.75
                },
                children: /*#__PURE__*/_jsx(Grid, {
                  container: true,
                  justifyContent: matchMobile ? 'space-between' : 'flex-end',
                  alignItems: "center",
                  children: /*#__PURE__*/_jsx(LocalizationSection, {})
                })
              })
            })
          })
        }))
      })
    })]
  });
};

/* harmony default export */ const Header_MobileSection = ((/* unused pure expression or super */ null && (MobileSection)));
// EXTERNAL MODULE: external "react-perfect-scrollbar"
var external_react_perfect_scrollbar_ = __webpack_require__(55162);
var external_react_perfect_scrollbar_default = /*#__PURE__*/__webpack_require__.n(external_react_perfect_scrollbar_);
// EXTERNAL MODULE: ./src/components/ui-component/cards/MainCard.js
var cards_MainCard = __webpack_require__(32107);
// EXTERNAL MODULE: ./src/hooks/useAuth.js
var useAuth = __webpack_require__(49684);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(41664);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Header/ProfileSection/index.js
function ProfileSection_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function ProfileSection_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ProfileSection_ownKeys(Object(source), true).forEach(function (key) { ProfileSection_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ProfileSection_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function ProfileSection_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // material-ui


 // third-party

 // project imports



 // assets







const User1 = '/assets/images/users/user-round.svg'; // ==============================|| PROFILE MENU ||============================== //

const ProfileSection = () => {
  const theme = (0,styles_.useTheme)();
  const {
    borderRadius
  } = (0,hooks_useConfig/* default */.Z)();
  const {
    0: selectedIndex,
    1: setSelectedIndex
  } = (0,external_react_.useState)(-1);
  const {
    logout,
    user
  } = (0,useAuth/* default */.Z)();
  const {
    0: open,
    1: setOpen
  } = (0,external_react_.useState)(false);
  /**
   * anchorRef is used on different components and specifying one type leads to other components throwing an error
   * */

  const anchorRef = (0,external_react_.useRef)(null);

  const handleLogout = async () => {
    try {
      await logout();
    } catch (err) {
      console.error(err);
    }
  };

  const handleClose = event => {
    if (anchorRef.current && anchorRef.current.contains(event.target)) {
      return;
    }

    setOpen(false);
  };

  const handleListItemClick = (event, index) => {
    setSelectedIndex(index);
    handleClose(event);
  };

  const handleToggle = () => {
    setOpen(prevOpen => !prevOpen);
  };

  const prevOpen = (0,external_react_.useRef)(open);
  (0,external_react_.useEffect)(() => {
    if (prevOpen.current === true && open === false) {
      anchorRef.current.focus();
    }

    prevOpen.current = open;
  }, [open]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Chip, {
      sx: {
        height: '48px',
        alignItems: 'center',
        borderRadius: '27px',
        transition: 'all .2s ease-in-out',
        borderColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.primary.light,
        backgroundColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.primary.light,
        '&[aria-controls="menu-list-grow"], &:hover': {
          borderColor: theme.palette.primary.main,
          background: `${theme.palette.primary.main} !important`,
          color: theme.palette.primary.light,
          '& svg': {
            stroke: theme.palette.primary.light
          }
        },
        '& .MuiChip-label': {
          lineHeight: 0
        }
      },
      icon: /*#__PURE__*/jsx_runtime_.jsx(material_.Avatar, {
        src: user === null || user === void 0 ? void 0 : user.photo,
        sx: ProfileSection_objectSpread(ProfileSection_objectSpread({}, theme.typography.mediumAvatar), {}, {
          margin: '8px 0 8px 8px !important',
          cursor: 'pointer'
        }),
        ref: anchorRef,
        "aria-controls": open ? 'menu-list-grow' : undefined,
        "aria-haspopup": "true",
        color: "inherit"
      }),
      label: /*#__PURE__*/jsx_runtime_.jsx(icons_.IconSettings, {
        stroke: 1.5,
        size: "1.5rem",
        color: theme.palette.primary.main
      }),
      variant: "outlined",
      ref: anchorRef,
      "aria-controls": open ? 'menu-list-grow' : undefined,
      "aria-haspopup": "true",
      onClick: handleToggle,
      color: "primary"
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Popper, {
      placement: "bottom-end",
      open: open,
      anchorEl: anchorRef.current,
      role: undefined,
      transition: true,
      disablePortal: true,
      popperOptions: {
        modifiers: [{
          name: 'offset',
          options: {
            offset: [0, 14]
          }
        }]
      },
      children: ({
        TransitionProps
      }) => /*#__PURE__*/jsx_runtime_.jsx(material_.ClickAwayListener, {
        onClickAway: handleClose,
        children: /*#__PURE__*/jsx_runtime_.jsx(extended_Transitions/* default */.Z, ProfileSection_objectSpread(ProfileSection_objectSpread({
          in: open
        }, TransitionProps), {}, {
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Paper, {
            children: open && /*#__PURE__*/(0,jsx_runtime_.jsxs)(cards_MainCard/* default */.Z, {
              border: false,
              elevation: 16,
              content: false,
              boxShadow: true,
              shadow: theme.shadows[16],
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                  p: 2,
                  pb: 0
                },
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Stack, {
                  children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Stack, {
                    direction: "row",
                    spacing: 0.5,
                    alignItems: "center",
                    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                      variant: "h4",
                      children: "Good Morning,"
                    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                      component: "span",
                      variant: "h4",
                      sx: {
                        wordWrap: 'break-word',
                        fontWeight: 400
                      },
                      children: user ? user.firstName.slice(0, 10) + '..cle' : 'OD'
                    })]
                  }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                    variant: "subtitle2",
                    children: "Project Admin"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.Divider, {
                  sx: {
                    pb: 1
                  }
                })]
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_perfect_scrollbar_default()), {
                style: {
                  height: '100%',
                  maxHeight: 'calc(100vh - 250px)',
                  overflowX: 'hidden'
                },
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
                  sx: {
                    p: 2,
                    pt: 0
                  },
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.List, {
                    component: "nav",
                    sx: {
                      width: '100%',
                      maxWidth: 350,
                      minWidth: 300,
                      backgroundColor: theme.palette.background.paper,
                      borderRadius: '10px',
                      [theme.breakpoints.down('md')]: {
                        minWidth: '100%'
                      },
                      '& .MuiListItemButton-root': {
                        mt: 0.5
                      }
                    },
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItemButton, {
                      sx: {
                        borderRadius: `${borderRadius}px`
                      },
                      selected: selectedIndex === 0,
                      onClick: event => handleListItemClick(event, 0),
                      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
                        children: /*#__PURE__*/jsx_runtime_.jsx(icons_.IconSettings, {
                          stroke: 1.5,
                          size: "1.3rem"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
                        primary: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                          href: "/app/user/account-profile/profile",
                          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                            variant: "body2",
                            children: "Account Settings"
                          })
                        })
                      })]
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItemButton, {
                      sx: {
                        borderRadius: `${borderRadius}px`
                      },
                      selected: selectedIndex === 1,
                      onClick: event => handleListItemClick(event, 1),
                      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
                        children: /*#__PURE__*/jsx_runtime_.jsx(icons_.IconUser, {
                          stroke: 1.5,
                          size: "1.3rem"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
                        primary: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                          href: "/app/user/social-profile/posts",
                          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                            variant: "body2",
                            children: "User Profile"
                          })
                        })
                      })]
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItemButton, {
                      sx: {
                        borderRadius: `${borderRadius}px`
                      },
                      selected: selectedIndex === 4,
                      onClick: handleLogout,
                      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
                        children: /*#__PURE__*/jsx_runtime_.jsx(icons_.IconLogout, {
                          stroke: 1.5,
                          size: "1.3rem"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
                        primary: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                          variant: "body2",
                          children: "Logout"
                        })
                      })]
                    })]
                  })
                })
              })]
            })
          })
        }))
      })
    })]
  });
};

/* harmony default export */ const Header_ProfileSection = (ProfileSection);
// EXTERNAL MODULE: ./src/Link.js + 1 modules
var src_Link = __webpack_require__(91931);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Header/NotificationSection/NotificationList.js
function NotificationList_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function NotificationList_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { NotificationList_ownKeys(Object(source), true).forEach(function (key) { NotificationList_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { NotificationList_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function NotificationList_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// material-ui

 // assets




const NotificationList_User1 = '/assets/images/users/user-round.svg'; // styles

const ListItemWrapper = (0,styles_.styled)('div')(({
  theme
}) => ({
  cursor: 'pointer',
  padding: 16,
  '&:hover': {
    background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.primary.light
  },
  '& .MuiListItem-root': {
    padding: 0
  }
})); // ==============================|| NOTIFICATION LIST ITEM ||============================== //

const NotificationList_NotificationList = () => {
  const theme = useTheme();
  const chipSX = {
    height: 24,
    padding: '0 6px'
  };

  const chipErrorSX = NotificationList_objectSpread(NotificationList_objectSpread({}, chipSX), {}, {
    color: theme.palette.orange.dark,
    backgroundColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.orange.light,
    marginRight: '5px'
  });

  const chipWarningSX = NotificationList_objectSpread(NotificationList_objectSpread({}, chipSX), {}, {
    color: theme.palette.warning.dark,
    backgroundColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.warning.light
  });

  const chipSuccessSX = NotificationList_objectSpread(NotificationList_objectSpread({}, chipSX), {}, {
    color: theme.palette.success.dark,
    backgroundColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.success.light,
    height: 28
  });

  return /*#__PURE__*/_jsxs(List, {
    sx: {
      width: '100%',
      maxWidth: 330,
      py: 0,
      borderRadius: '10px',
      [theme.breakpoints.down('md')]: {
        maxWidth: 300
      },
      '& .MuiListItemSecondaryAction-root': {
        top: 22
      },
      '& .MuiDivider-root': {
        my: 0
      },
      '& .list-container': {
        pl: 7
      }
    },
    children: [/*#__PURE__*/_jsxs(ListItemWrapper, {
      children: [/*#__PURE__*/_jsxs(ListItem, {
        alignItems: "center",
        children: [/*#__PURE__*/_jsx(ListItemAvatar, {
          children: /*#__PURE__*/_jsx(Avatar, {
            alt: "John Doe",
            src: NotificationList_User1
          })
        }), /*#__PURE__*/_jsx(ListItemText, {
          primary: "John Doe"
        }), /*#__PURE__*/_jsx(ListItemSecondaryAction, {
          children: /*#__PURE__*/_jsx(Grid, {
            container: true,
            justifyContent: "flex-end",
            children: /*#__PURE__*/_jsx(Grid, {
              item: true,
              xs: 12,
              children: /*#__PURE__*/_jsx(Typography, {
                variant: "caption",
                display: "block",
                gutterBottom: true,
                children: "2 min ago"
              })
            })
          })
        })]
      }), /*#__PURE__*/_jsxs(Grid, {
        container: true,
        direction: "column",
        className: "list-container",
        children: [/*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          sx: {
            pb: 2
          },
          children: /*#__PURE__*/_jsx(Typography, {
            variant: "subtitle2",
            children: "It is a long established fact that a reader will be distracted"
          })
        }), /*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/_jsxs(Grid, {
            container: true,
            children: [/*#__PURE__*/_jsx(Grid, {
              item: true,
              children: /*#__PURE__*/_jsx(Chip, {
                label: "Unread",
                sx: chipErrorSX
              })
            }), /*#__PURE__*/_jsx(Grid, {
              item: true,
              children: /*#__PURE__*/_jsx(Chip, {
                label: "New",
                sx: chipWarningSX
              })
            })]
          })
        })]
      })]
    }), /*#__PURE__*/_jsx(Divider, {}), /*#__PURE__*/_jsxs(ListItemWrapper, {
      children: [/*#__PURE__*/_jsxs(ListItem, {
        alignItems: "center",
        children: [/*#__PURE__*/_jsx(ListItemAvatar, {
          children: /*#__PURE__*/_jsx(Avatar, {
            sx: {
              color: theme.palette.success.dark,
              backgroundColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.success.light,
              border: theme.palette.mode === 'dark' ? '1px solid' : 'none',
              borderColor: theme.palette.success.main
            },
            children: /*#__PURE__*/_jsx(IconBuildingStore, {
              stroke: 1.5,
              size: "1.3rem"
            })
          })
        }), /*#__PURE__*/_jsx(ListItemText, {
          primary: /*#__PURE__*/_jsx(Typography, {
            variant: "subtitle1",
            children: "Store Verification Done"
          })
        }), /*#__PURE__*/_jsx(ListItemSecondaryAction, {
          children: /*#__PURE__*/_jsx(Grid, {
            container: true,
            justifyContent: "flex-end",
            children: /*#__PURE__*/_jsx(Grid, {
              item: true,
              xs: 12,
              children: /*#__PURE__*/_jsx(Typography, {
                variant: "caption",
                display: "block",
                gutterBottom: true,
                children: "2 min ago"
              })
            })
          })
        })]
      }), /*#__PURE__*/_jsxs(Grid, {
        container: true,
        direction: "column",
        className: "list-container",
        children: [/*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          sx: {
            pb: 2
          },
          children: /*#__PURE__*/_jsx(Typography, {
            variant: "subtitle2",
            children: "We have successfully received your request."
          })
        }), /*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/_jsx(Grid, {
            container: true,
            children: /*#__PURE__*/_jsx(Grid, {
              item: true,
              children: /*#__PURE__*/_jsx(Chip, {
                label: "Unread",
                sx: chipErrorSX
              })
            })
          })
        })]
      })]
    }), /*#__PURE__*/_jsx(Divider, {}), /*#__PURE__*/_jsxs(ListItemWrapper, {
      children: [/*#__PURE__*/_jsxs(ListItem, {
        alignItems: "center",
        children: [/*#__PURE__*/_jsx(ListItemAvatar, {
          children: /*#__PURE__*/_jsx(Avatar, {
            sx: {
              color: theme.palette.primary.dark,
              backgroundColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.primary.light,
              border: theme.palette.mode === 'dark' ? '1px solid' : 'none',
              borderColor: theme.palette.primary.main
            },
            children: /*#__PURE__*/_jsx(IconMailbox, {
              stroke: 1.5,
              size: "1.3rem"
            })
          })
        }), /*#__PURE__*/_jsx(ListItemText, {
          primary: /*#__PURE__*/_jsx(Typography, {
            variant: "subtitle1",
            children: "Check Your Mail."
          })
        }), /*#__PURE__*/_jsx(ListItemSecondaryAction, {
          children: /*#__PURE__*/_jsx(Grid, {
            container: true,
            justifyContent: "flex-end",
            children: /*#__PURE__*/_jsx(Grid, {
              item: true,
              children: /*#__PURE__*/_jsx(Typography, {
                variant: "caption",
                display: "block",
                gutterBottom: true,
                children: "2 min ago"
              })
            })
          })
        })]
      }), /*#__PURE__*/_jsxs(Grid, {
        container: true,
        direction: "column",
        className: "list-container",
        children: [/*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          sx: {
            pb: 2
          },
          children: /*#__PURE__*/_jsx(Typography, {
            variant: "subtitle2",
            children: "All done! Now check your inbox as you're in for a sweet treat!"
          })
        }), /*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/_jsx(Grid, {
            container: true,
            children: /*#__PURE__*/_jsx(Grid, {
              item: true,
              children: /*#__PURE__*/_jsx(Button, {
                variant: "contained",
                disableElevation: true,
                endIcon: /*#__PURE__*/_jsx(IconBrandTelegram, {
                  stroke: 1.5,
                  size: "1.3rem"
                }),
                children: "Mail"
              })
            })
          })
        })]
      })]
    }), /*#__PURE__*/_jsx(Divider, {}), /*#__PURE__*/_jsxs(ListItemWrapper, {
      children: [/*#__PURE__*/_jsxs(ListItem, {
        alignItems: "center",
        children: [/*#__PURE__*/_jsx(ListItemAvatar, {
          children: /*#__PURE__*/_jsx(Avatar, {
            alt: "John Doe",
            src: NotificationList_User1
          })
        }), /*#__PURE__*/_jsx(ListItemText, {
          primary: /*#__PURE__*/_jsx(Typography, {
            variant: "subtitle1",
            children: "John Doe"
          })
        }), /*#__PURE__*/_jsx(ListItemSecondaryAction, {
          children: /*#__PURE__*/_jsx(Grid, {
            container: true,
            justifyContent: "flex-end",
            children: /*#__PURE__*/_jsx(Grid, {
              item: true,
              xs: 12,
              children: /*#__PURE__*/_jsx(Typography, {
                variant: "caption",
                display: "block",
                gutterBottom: true,
                children: "2 min ago"
              })
            })
          })
        })]
      }), /*#__PURE__*/_jsxs(Grid, {
        container: true,
        direction: "column",
        className: "list-container",
        children: [/*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          sx: {
            pb: 2
          },
          children: /*#__PURE__*/_jsxs(Typography, {
            component: "span",
            variant: "subtitle2",
            children: ["Uploaded two file on \xA0", /*#__PURE__*/_jsx(Typography, {
              component: "span",
              variant: "h6",
              children: "21 Jan 2020"
            })]
          })
        }), /*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/_jsx(Grid, {
            container: true,
            children: /*#__PURE__*/_jsx(Grid, {
              item: true,
              xs: 12,
              children: /*#__PURE__*/_jsx(Card, {
                sx: {
                  backgroundColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.secondary.light
                },
                children: /*#__PURE__*/_jsx(CardContent, {
                  children: /*#__PURE__*/_jsx(Grid, {
                    container: true,
                    direction: "column",
                    children: /*#__PURE__*/_jsx(Grid, {
                      item: true,
                      xs: 12,
                      children: /*#__PURE__*/_jsxs(Stack, {
                        direction: "row",
                        spacing: 2,
                        children: [/*#__PURE__*/_jsx(IconPhoto, {
                          stroke: 1.5,
                          size: "1.3rem"
                        }), /*#__PURE__*/_jsx(Typography, {
                          variant: "subtitle1",
                          children: "demo.jpg"
                        })]
                      })
                    })
                  })
                })
              })
            })
          })
        })]
      })]
    }), /*#__PURE__*/_jsx(Divider, {}), /*#__PURE__*/_jsxs(ListItemWrapper, {
      children: [/*#__PURE__*/_jsxs(ListItem, {
        alignItems: "center",
        children: [/*#__PURE__*/_jsx(ListItemAvatar, {
          children: /*#__PURE__*/_jsx(Avatar, {
            alt: "John Doe",
            src: NotificationList_User1
          })
        }), /*#__PURE__*/_jsx(ListItemText, {
          primary: /*#__PURE__*/_jsx(Typography, {
            variant: "subtitle1",
            children: "John Doe"
          })
        }), /*#__PURE__*/_jsx(ListItemSecondaryAction, {
          children: /*#__PURE__*/_jsx(Grid, {
            container: true,
            justifyContent: "flex-end",
            children: /*#__PURE__*/_jsx(Grid, {
              item: true,
              xs: 12,
              children: /*#__PURE__*/_jsx(Typography, {
                variant: "caption",
                display: "block",
                gutterBottom: true,
                children: "2 min ago"
              })
            })
          })
        })]
      }), /*#__PURE__*/_jsxs(Grid, {
        container: true,
        direction: "column",
        className: "list-container",
        children: [/*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          sx: {
            pb: 2
          },
          children: /*#__PURE__*/_jsx(Typography, {
            variant: "subtitle2",
            children: "It is a long established fact that a reader will be distracted"
          })
        }), /*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/_jsx(Grid, {
            container: true,
            children: /*#__PURE__*/_jsx(Grid, {
              item: true,
              children: /*#__PURE__*/_jsx(Chip, {
                label: "Confirmation of Account.",
                sx: chipSuccessSX
              })
            })
          })
        })]
      })]
    })]
  });
};

/* harmony default export */ const NotificationSection_NotificationList = ((/* unused pure expression or super */ null && (NotificationList_NotificationList)));
;// CONCATENATED MODULE: ./src/layout/MainLayout/Header/NotificationSection/index.js
function NotificationSection_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function NotificationSection_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { NotificationSection_ownKeys(Object(source), true).forEach(function (key) { NotificationSection_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { NotificationSection_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function NotificationSection_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


 // material-ui


 // third-party

 // project imports



 // assets

 // notification status options




const NotificationSection_status = [{
  value: 'all',
  label: 'All Notification'
}, {
  value: 'new',
  label: 'New'
}, {
  value: 'unread',
  label: 'Unread'
}, {
  value: 'other',
  label: 'Other'
}]; // ==============================|| NOTIFICATION ||============================== //

const NotificationSection = () => {
  const theme = useTheme();
  const matchesXs = useMediaQuery(theme.breakpoints.down('md'));
  const {
    0: open,
    1: setOpen
  } = useState(false);
  const {
    0: value,
    1: setValue
  } = useState('');
  /**
   * anchorRef is used on different componets and specifying one type leads to other components throwing an error
   * */

  const anchorRef = useRef(null);

  const handleToggle = () => {
    setOpen(prevOpen => !prevOpen);
  };

  const handleClose = event => {
    if (anchorRef.current && anchorRef.current.contains(event.target)) {
      return;
    }

    setOpen(false);
  };

  const prevOpen = useRef(open);
  useEffect(() => {
    if (prevOpen.current === true && open === false) {
      anchorRef.current.focus();
    }

    prevOpen.current = open;
  }, [open]);

  const handleChange = event => {
    if (event.target.value) setValue(event.target.value);
  };

  return /*#__PURE__*/_jsxs(_Fragment, {
    children: [/*#__PURE__*/_jsx(Box, {
      sx: {
        ml: 2,
        mr: 3,
        [theme.breakpoints.down('md')]: {
          mr: 2
        }
      },
      children: /*#__PURE__*/_jsx(Avatar, {
        variant: "rounded",
        sx: NotificationSection_objectSpread(NotificationSection_objectSpread(NotificationSection_objectSpread({}, theme.typography.commonAvatar), theme.typography.mediumAvatar), {}, {
          transition: 'all .2s ease-in-out',
          background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.secondary.light,
          color: theme.palette.mode === 'dark' ? theme.palette.warning.dark : theme.palette.secondary.dark,
          '&[aria-controls="menu-list-grow"],&:hover': {
            background: theme.palette.mode === 'dark' ? theme.palette.warning.dark : theme.palette.secondary.dark,
            color: theme.palette.mode === 'dark' ? theme.palette.grey[800] : theme.palette.secondary.light
          }
        }),
        ref: anchorRef,
        "aria-controls": open ? 'menu-list-grow' : undefined,
        "aria-haspopup": "true",
        onClick: handleToggle,
        color: "inherit",
        children: /*#__PURE__*/_jsx(IconBell, {
          stroke: 1.5,
          size: "1.3rem"
        })
      })
    }), /*#__PURE__*/_jsx(Popper, {
      placement: matchesXs ? 'bottom' : 'bottom-end',
      open: open,
      anchorEl: anchorRef.current,
      role: undefined,
      transition: true,
      disablePortal: true,
      popperOptions: {
        modifiers: [{
          name: 'offset',
          options: {
            offset: [matchesXs ? 5 : 0, 20]
          }
        }]
      },
      children: ({
        TransitionProps
      }) => /*#__PURE__*/_jsx(ClickAwayListener, {
        onClickAway: handleClose,
        children: /*#__PURE__*/_jsx(Transitions, NotificationSection_objectSpread(NotificationSection_objectSpread({
          position: matchesXs ? 'top' : 'top-right',
          in: open
        }, TransitionProps), {}, {
          children: /*#__PURE__*/_jsx(Paper, {
            children: open && /*#__PURE__*/_jsxs(MainCard, {
              border: false,
              elevation: 16,
              content: false,
              boxShadow: true,
              shadow: theme.shadows[16],
              children: [/*#__PURE__*/_jsxs(Grid, {
                container: true,
                direction: "column",
                spacing: 2,
                children: [/*#__PURE__*/_jsx(Grid, {
                  item: true,
                  xs: 12,
                  children: /*#__PURE__*/_jsxs(Grid, {
                    container: true,
                    alignItems: "center",
                    justifyContent: "space-between",
                    sx: {
                      pt: 2,
                      px: 2
                    },
                    children: [/*#__PURE__*/_jsx(Grid, {
                      item: true,
                      children: /*#__PURE__*/_jsxs(Stack, {
                        direction: "row",
                        spacing: 2,
                        children: [/*#__PURE__*/_jsx(Typography, {
                          variant: "subtitle1",
                          children: "All Notification"
                        }), /*#__PURE__*/_jsx(Chip, {
                          size: "small",
                          label: "01",
                          sx: {
                            color: theme.palette.background.default,
                            bgcolor: theme.palette.warning.dark
                          }
                        })]
                      })
                    }), /*#__PURE__*/_jsx(Grid, {
                      item: true,
                      children: /*#__PURE__*/_jsx(Typography, {
                        component: Link,
                        href: "#",
                        variant: "subtitle2",
                        color: "primary",
                        children: "Mark as all read"
                      })
                    })]
                  })
                }), /*#__PURE__*/_jsx(Grid, {
                  item: true,
                  xs: 12,
                  children: /*#__PURE__*/_jsxs(PerfectScrollbar, {
                    style: {
                      height: '100%',
                      maxHeight: 'calc(100vh - 205px)',
                      overflowX: 'hidden'
                    },
                    children: [/*#__PURE__*/_jsxs(Grid, {
                      container: true,
                      direction: "column",
                      spacing: 2,
                      children: [/*#__PURE__*/_jsx(Grid, {
                        item: true,
                        xs: 12,
                        children: /*#__PURE__*/_jsx(Box, {
                          sx: {
                            px: 2,
                            pt: 0.25
                          },
                          children: /*#__PURE__*/_jsx(TextField, {
                            id: "outlined-select-currency-native",
                            select: true,
                            fullWidth: true,
                            value: value,
                            onChange: handleChange,
                            SelectProps: {
                              native: true
                            },
                            children: NotificationSection_status.map(option => /*#__PURE__*/_jsx("option", {
                              value: option.value,
                              children: option.label
                            }, option.value))
                          })
                        })
                      }), /*#__PURE__*/_jsx(Grid, {
                        item: true,
                        xs: 12,
                        p: 0,
                        children: /*#__PURE__*/_jsx(Divider, {
                          sx: {
                            my: 0
                          }
                        })
                      })]
                    }), /*#__PURE__*/_jsx(NotificationList, {})]
                  })
                })]
              }), /*#__PURE__*/_jsx(Divider, {}), /*#__PURE__*/_jsx(CardActions, {
                sx: {
                  p: 1.25,
                  justifyContent: 'center'
                },
                children: /*#__PURE__*/_jsx(Button, {
                  size: "small",
                  disableElevation: true,
                  children: "View All"
                })
              })]
            })
          })
        }))
      })
    })]
  });
};

/* harmony default export */ const Header_NotificationSection = ((/* unused pure expression or super */ null && (NotificationSection)));
// EXTERNAL MODULE: ./src/store/index.js + 2 modules
var store = __webpack_require__(95394);
// EXTERNAL MODULE: ./src/store/slices/menu.js
var menu = __webpack_require__(22361);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Header/index.js
function Header_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Header_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Header_ownKeys(Object(source), true).forEach(function (key) { Header_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Header_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Header_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// material-ui

 // project imports








 // assets

 // ==============================|| MAIN NAVBAR / HEADER ||============================== //





const Header = () => {
  const theme = (0,styles_.useTheme)();
  const dispatch = (0,store/* useDispatch */.I0)();
  const {
    drawerOpen
  } = (0,store/* useSelector */.v9)(state => state.menu);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      sx: {
        width: 228,
        display: 'flex',
        [theme.breakpoints.down('md')]: {
          width: 'auto'
        }
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        component: "span",
        sx: {
          display: {
            xs: 'none',
            md: 'flex'
          },
          flexGrow: 1,
          justifyContent: 'center',
          alignItems: 'center'
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(LogoSection/* default */.Z, {})
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Avatar, {
        variant: "rounded",
        sx: Header_objectSpread(Header_objectSpread(Header_objectSpread({}, theme.typography.commonAvatar), theme.typography.mediumAvatar), {}, {
          overflow: 'hidden',
          transition: 'all .2s ease-in-out',
          background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.secondary.light,
          color: theme.palette.mode === 'dark' ? theme.palette.secondary.main : theme.palette.secondary.dark,
          '&:hover': {
            background: theme.palette.mode === 'dark' ? theme.palette.secondary.main : theme.palette.secondary.dark,
            color: theme.palette.mode === 'dark' ? theme.palette.secondary.light : theme.palette.secondary.light
          }
        }),
        onClick: () => dispatch((0,menu/* openDrawer */.FJ)(!drawerOpen)),
        color: "inherit",
        children: /*#__PURE__*/jsx_runtime_.jsx(icons_.IconMenu2, {
          stroke: 1.5,
          size: "1.3rem"
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      sx: {
        flexGrow: 1
      }
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      sx: {
        flexGrow: 1
      }
    }), /*#__PURE__*/jsx_runtime_.jsx(Header_ProfileSection, {})]
  });
};

/* harmony default export */ const MainLayout_Header = (Header);

/***/ }),

/***/ 1684:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var Link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(91931);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7878);
/* harmony import */ var components_ui_component_Logo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5482);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
 // material-ui

 // project imports


 // ==============================|| MAIN LOGO ||============================== //



const LogoSection = () => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Link, {
  component: Link__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z,
  href: config__WEBPACK_IMPORTED_MODULE_2__/* .DASHBOARD_PATH */ .tu,
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_ui_component_Logo__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LogoSection);

/***/ }),

/***/ 84197:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ MainLayout_Sidebar)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(18442);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(65692);
// EXTERNAL MODULE: external "react-perfect-scrollbar"
var external_react_perfect_scrollbar_ = __webpack_require__(55162);
var external_react_perfect_scrollbar_default = /*#__PURE__*/__webpack_require__.n(external_react_perfect_scrollbar_);
// EXTERNAL MODULE: ./src/Link.js + 1 modules
var Link = __webpack_require__(91931);
// EXTERNAL MODULE: ./src/hooks/useConfig.js
var useConfig = __webpack_require__(20132);
// EXTERNAL MODULE: ./src/store/index.js + 2 modules
var store = __webpack_require__(95394);
// EXTERNAL MODULE: ./src/store/slices/menu.js
var menu = __webpack_require__(22361);
// EXTERNAL MODULE: external "@mui/icons-material/FiberManualRecord"
var FiberManualRecord_ = __webpack_require__(77943);
var FiberManualRecord_default = /*#__PURE__*/__webpack_require__.n(FiberManualRecord_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Sidebar/MenuList/NavItem/index.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


 // material-ui


 // project imports



 // assets

 // ==============================|| SIDEBAR MENU LIST ITEMS ||============================== //




const NavItem = ({
  item,
  level
}) => {
  const theme = (0,styles_.useTheme)();
  const matchesSM = (0,material_.useMediaQuery)(theme.breakpoints.down('lg'));
  const {
    borderRadius
  } = (0,useConfig/* default */.Z)();
  const dispatch = (0,store/* useDispatch */.I0)();
  const {
    openItem
  } = (0,store/* useSelector */.v9)(state => state.menu);
  const Icon = item.icon;
  const itemIcon = item.icon ? /*#__PURE__*/jsx_runtime_.jsx(Icon, {
    stroke: 1.5,
    size: "1.3rem"
  }) : /*#__PURE__*/jsx_runtime_.jsx((FiberManualRecord_default()), {
    sx: {
      width: openItem.findIndex(id => id === item.id) > -1 ? 8 : 6,
      height: openItem.findIndex(id => id === item.id) > -1 ? 8 : 6
    },
    fontSize: level > 0 ? 'inherit' : 'medium'
  });
  let itemTarget = '_self';

  if (item.target) {
    itemTarget = '_blank';
  }

  let listItemProps = {
    component: /*#__PURE__*/(0,external_react_.forwardRef)((props, ref) => /*#__PURE__*/jsx_runtime_.jsx(Link/* default */.Z, _objectSpread(_objectSpread({
      ref: ref
    }, props), {}, {
      href: `${item.url}`,
      target: itemTarget
    })))
  };

  if (item.external) {
    listItemProps = {
      component: 'a',
      href: item.url,
      target: itemTarget
    };
  }

  const itemHandler = id => {
    dispatch((0,menu/* activeItem */.zw)([id]));
    if (matchesSM) dispatch((0,menu/* openDrawer */.FJ)(false));
  }; // active menu item on page load


  (0,external_react_.useEffect)(() => {
    const currentIndex = document.location.pathname.toString().split('/').findIndex(id => id === item.id);

    if (currentIndex > -1) {
      dispatch((0,menu/* activeItem */.zw)([item.id]));
    } // eslint-disable-next-line

  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItemButton, _objectSpread(_objectSpread({}, listItemProps), {}, {
    disabled: item.disabled,
    sx: {
      borderRadius: `${borderRadius}px`,
      mb: 0.5,
      alignItems: 'flex-start',
      backgroundColor: level > 1 ? 'transparent !important' : 'inherit',
      py: level > 1 ? 1 : 1.25,
      pl: `${level * 24}px`
    },
    selected: openItem.findIndex(id => id === item.id) > -1,
    onClick: () => itemHandler(item.id),
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
      sx: {
        my: 'auto',
        minWidth: !item.icon ? 18 : 36
      },
      children: itemIcon
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
      primary: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
        variant: openItem.findIndex(id => id === item.id) > -1 ? 'h5' : 'body1',
        color: "inherit",
        children: item.title
      }),
      secondary: item.caption && /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
        variant: "caption",
        sx: _objectSpread({}, theme.typography.subMenuCaption),
        display: "block",
        gutterBottom: true,
        children: item.caption
      })
    }), item.chip && /*#__PURE__*/jsx_runtime_.jsx(material_.Chip, {
      color: item.chip.color,
      variant: item.chip.variant,
      size: item.chip.size,
      label: item.chip.label,
      avatar: item.chip.avatar && /*#__PURE__*/jsx_runtime_.jsx(material_.Avatar, {
        children: item.chip.avatar
      })
    })]
  }));
};

/* harmony default export */ const MenuList_NavItem = (NavItem);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(71853);
// EXTERNAL MODULE: external "@tabler/icons"
var icons_ = __webpack_require__(94116);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Sidebar/MenuList/NavCollapse/index.js
function NavCollapse_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function NavCollapse_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { NavCollapse_ownKeys(Object(source), true).forEach(function (key) { NavCollapse_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { NavCollapse_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function NavCollapse_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


 // material-ui



 // project imports


 // assets

 // ==============================|| SIDEBAR MENU LIST COLLAPSE ITEMS ||============================== //





const NavCollapse = ({
  menu,
  level
}) => {
  const theme = (0,styles_.useTheme)();
  const {
    borderRadius
  } = (0,useConfig/* default */.Z)();
  const {
    0: open,
    1: setOpen
  } = (0,external_react_.useState)(false);
  const {
    0: selected,
    1: setSelected
  } = (0,external_react_.useState)(null);

  const handleClick = () => {
    setOpen(!open);
    setSelected(!selected ? menu.id : null);
  }; // const { pathname } = useLocation();


  const {
    pathname
  } = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    const childrens = menu.children ? menu.children : [];
    childrens.forEach(item => {
      if (pathname && pathname.includes('product-details')) {
        if (item.url && item.url.includes('product-details')) {
          setOpen(true);
        }
      }

      if (item.url === pathname) {
        setOpen(true);
      }
    });
  }, [pathname, menu.children]); // menu collapse & item

  const menus = menu.children.map(item => {
    switch (item.type) {
      case 'collapse':
        return /*#__PURE__*/jsx_runtime_.jsx(NavCollapse, {
          menu: item,
          level: level + 1
        }, item.id);

      case 'item':
        return /*#__PURE__*/jsx_runtime_.jsx(MenuList_NavItem, {
          item: item,
          level: level + 1
        }, item.id);

      default:
        return /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h6",
          color: "error",
          align: "center",
          children: "Menu Items Error"
        }, item.id);
    }
  });
  const Icon = menu.icon;
  const menuIcon = menu.icon ? /*#__PURE__*/jsx_runtime_.jsx(Icon, {
    strokeWidth: 1.5,
    size: "1.3rem",
    style: {
      marginTop: 'auto',
      marginBottom: 'auto'
    }
  }) : /*#__PURE__*/jsx_runtime_.jsx((FiberManualRecord_default()), {
    sx: {
      width: selected === menu.id ? 8 : 6,
      height: selected === menu.id ? 8 : 6
    },
    fontSize: level > 0 ? 'inherit' : 'medium'
  });
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItemButton, {
      sx: {
        borderRadius: `${borderRadius}px`,
        mb: 0.5,
        alignItems: 'flex-start',
        backgroundColor: level > 1 ? 'transparent !important' : 'inherit',
        py: level > 1 ? 1 : 1.25,
        pl: `${level * 24}px`
      },
      selected: selected === menu.id,
      onClick: handleClick,
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
        sx: {
          my: 'auto',
          minWidth: !menu.icon ? 18 : 36
        },
        children: menuIcon
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
        primary: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: selected === menu.id ? 'h5' : 'body1',
          color: "inherit",
          sx: {
            my: 'auto'
          },
          children: menu.title
        }),
        secondary: menu.caption && /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "caption",
          sx: NavCollapse_objectSpread({}, theme.typography.subMenuCaption),
          display: "block",
          gutterBottom: true,
          children: menu.caption
        })
      }), open ? /*#__PURE__*/jsx_runtime_.jsx(icons_.IconChevronUp, {
        stroke: 1.5,
        size: "1rem",
        style: {
          marginTop: 'auto',
          marginBottom: 'auto'
        }
      }) : /*#__PURE__*/jsx_runtime_.jsx(icons_.IconChevronDown, {
        stroke: 1.5,
        size: "1rem",
        style: {
          marginTop: 'auto',
          marginBottom: 'auto'
        }
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Collapse, {
      in: open,
      timeout: "auto",
      unmountOnExit: true,
      children: open && /*#__PURE__*/jsx_runtime_.jsx(material_.List, {
        component: "div",
        disablePadding: true,
        sx: {
          position: 'relative',
          '&:after': {
            content: "''",
            position: 'absolute',
            left: '32px',
            top: 0,
            height: '100%',
            width: '1px',
            opacity: theme.palette.mode === 'dark' ? 0.2 : 1,
            background: theme.palette.mode === 'dark' ? theme.palette.dark.light : theme.palette.primary.light
          }
        },
        children: menus
      })
    })]
  });
};

/* harmony default export */ const MenuList_NavCollapse = (NavCollapse);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Sidebar/MenuList/NavGroup/index.js
function NavGroup_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function NavGroup_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { NavGroup_ownKeys(Object(source), true).forEach(function (key) { NavGroup_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { NavGroup_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function NavGroup_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// material-ui

 // project imports


 // ==============================|| SIDEBAR MENU LIST GROUP ||============================== //





const NavGroup = ({
  item
}) => {
  const theme = (0,styles_.useTheme)(); // menu list collapse & items

  const items = item.children.map(menu => {
    switch (menu.type) {
      case 'collapse':
        return /*#__PURE__*/jsx_runtime_.jsx(MenuList_NavCollapse, {
          menu: menu,
          level: 1
        }, menu.id);

      case 'item':
        return /*#__PURE__*/jsx_runtime_.jsx(MenuList_NavItem, {
          item: menu,
          level: 1
        }, menu.id);

      default:
        return /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h6",
          color: "error",
          align: "center",
          children: "Menu Items Error"
        }, menu.id);
    }
  });
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.List, {
      subheader: item.title && /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Typography, {
        variant: "caption",
        sx: NavGroup_objectSpread({}, theme.typography.menuCaption),
        display: "block",
        gutterBottom: true,
        children: [item.title, item.caption && /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "caption",
          sx: NavGroup_objectSpread({}, theme.typography.subMenuCaption),
          display: "block",
          gutterBottom: true,
          children: item.caption
        })]
      }),
      children: items
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Divider, {
      sx: {
        mt: 0.25,
        mb: 1.25
      }
    })]
  });
};

/* harmony default export */ const MenuList_NavGroup = (NavGroup);
// EXTERNAL MODULE: ./src/menu-items/index.js + 3 modules
var menu_items = __webpack_require__(67509);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Sidebar/MenuList/index.js
 // material-ui

 // project imports


 // ==============================|| SIDEBAR MENU LIST ||============================== //




const MenuList = () => {
  const navItems = menu_items/* default.items.map */.Z.items.map(item => {
    switch (item.type) {
      case 'group':
        return /*#__PURE__*/jsx_runtime_.jsx(MenuList_NavGroup, {
          item: item
        }, item.id);

      default:
        return /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h6",
          color: "error",
          align: "center",
          children: "Menu Items Error"
        }, item.id);
    }
  });
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: navItems
  });
};

/* harmony default export */ const Sidebar_MenuList = (/*#__PURE__*/(0,external_react_.memo)(MenuList));
// EXTERNAL MODULE: ./src/layout/MainLayout/LogoSection/index.js
var LogoSection = __webpack_require__(1684);
// EXTERNAL MODULE: ./src/store/constant.js
var constant = __webpack_require__(49514);
;// CONCATENATED MODULE: ./src/layout/MainLayout/Sidebar/index.js
 // material-ui


 // third-party

 // project imports





 // ==============================|| SIDEBAR DRAWER ||============================== //




const Sidebar = ({
  window
}) => {
  const theme = (0,styles_.useTheme)();
  const matchUpMd = (0,material_.useMediaQuery)(theme.breakpoints.up('md'));
  const dispatch = (0,store/* useDispatch */.I0)();
  const {
    drawerOpen
  } = (0,store/* useSelector */.v9)(state => state.menu);
  const logo = (0,external_react_.useMemo)(() => /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    sx: {
      display: {
        xs: 'block',
        md: 'none'
      }
    },
    children: /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      sx: {
        display: 'flex',
        p: 2,
        mx: 'auto'
      },
      children: /*#__PURE__*/jsx_runtime_.jsx(LogoSection/* default */.Z, {})
    })
  }), []);
  const drawer = (0,external_react_.useMemo)(() => /*#__PURE__*/jsx_runtime_.jsx((external_react_perfect_scrollbar_default()), {
    component: "div",
    style: {
      height: !matchUpMd ? 'calc(100vh - 56px)' : 'calc(100vh - 88px)',
      paddingLeft: '16px',
      paddingRight: '16px'
    },
    children: /*#__PURE__*/jsx_runtime_.jsx(Sidebar_MenuList, {})
  }), // eslint-disable-next-line react-hooks/exhaustive-deps
  [matchUpMd]);
  const container = window !== undefined ? () => window.document.body : undefined;
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    component: "nav",
    sx: {
      flexShrink: {
        md: 0
      },
      width: matchUpMd ? constant/* drawerWidth */.RK : 'auto'
    },
    "aria-label": "mailbox folders",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Drawer, {
      container: container,
      variant: matchUpMd ? 'persistent' : 'temporary',
      anchor: "left",
      open: drawerOpen,
      onClose: () => dispatch((0,menu/* openDrawer */.FJ)(!drawerOpen)),
      sx: {
        alignItems: 'center',
        '& .MuiDrawer-paper': {
          width: constant/* drawerWidth */.RK,
          background: theme.palette.background.default,
          color: theme.palette.text.primary,
          borderRight: 'none',
          [theme.breakpoints.up('md')]: {
            top: '88px'
          }
        }
      },
      ModalProps: {
        keepMounted: true
      },
      color: "inherit",
      children: [drawerOpen && logo, drawerOpen && drawer]
    })
  });
};

/* harmony default export */ const MainLayout_Sidebar = (/*#__PURE__*/(0,external_react_.memo)(Sidebar));

/***/ }),

/***/ 25881:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_ui_component_extended_Breadcrumbs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18995);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(76330);
/* harmony import */ var _Sidebar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(84197);
/* harmony import */ var _Customization__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(91323);
/* harmony import */ var menu_items__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(67509);
/* harmony import */ var hooks_useConfig__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20132);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(49514);
/* harmony import */ var store_slices_menu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(22361);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(95394);
/* harmony import */ var utils_route_guard_AuthGuard__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57178);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(94116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Customization__WEBPACK_IMPORTED_MODULE_6__]);
_Customization__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // material-ui


 // project imports










 // assets

 // styles




const Main = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.styled)('main', {
  shouldForwardProp: prop => prop !== 'open'
})(({
  theme,
  open
}) => _objectSpread(_objectSpread(_objectSpread({}, theme.typography.mainContent), !open && {
  borderBottomLeftRadius: 0,
  borderBottomRightRadius: 0,
  transition: theme.transitions.create('margin', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.shorter
  }),
  [theme.breakpoints.up('md')]: {
    marginLeft: -(store_constant__WEBPACK_IMPORTED_MODULE_14__/* .drawerWidth */ .RK - 20),
    width: `calc(100% - ${store_constant__WEBPACK_IMPORTED_MODULE_14__/* .drawerWidth */ .RK}px)`
  },
  [theme.breakpoints.down('md')]: {
    marginLeft: '20px',
    width: `calc(100% - ${store_constant__WEBPACK_IMPORTED_MODULE_14__/* .drawerWidth */ .RK}px)`,
    padding: '16px'
  },
  [theme.breakpoints.down('sm')]: {
    marginLeft: '10px',
    width: `calc(100% - ${store_constant__WEBPACK_IMPORTED_MODULE_14__/* .drawerWidth */ .RK}px)`,
    padding: '16px',
    marginRight: '10px'
  }
}), open && {
  transition: theme.transitions.create('margin', {
    easing: theme.transitions.easing.easeOut,
    duration: theme.transitions.duration.shorter
  }),
  marginLeft: 0,
  borderBottomLeftRadius: 0,
  borderBottomRightRadius: 0,
  width: `calc(100% - ${store_constant__WEBPACK_IMPORTED_MODULE_14__/* .drawerWidth */ .RK}px)`,
  [theme.breakpoints.down('md')]: {
    marginLeft: '20px'
  },
  [theme.breakpoints.down('sm')]: {
    marginLeft: '10px'
  }
})); // ==============================|| MAIN LAYOUT ||============================== //

const MainLayout = ({
  children
}) => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
  const matchDownMd = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)(theme.breakpoints.down('lg'));
  const dispatch = (0,store__WEBPACK_IMPORTED_MODULE_10__/* .useDispatch */ .I0)();
  const {
    drawerOpen
  } = (0,store__WEBPACK_IMPORTED_MODULE_10__/* .useSelector */ .v9)(state => state.menu);
  const {
    container
  } = (0,hooks_useConfig__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
  react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
    dispatch((0,store_slices_menu__WEBPACK_IMPORTED_MODULE_9__/* .openDrawer */ .FJ)(!matchDownMd)); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matchDownMd]);
  const header = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Toolbar, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Header__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
  }), []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(utils_route_guard_AuthGuard__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
      sx: {
        display: 'flex'
      },
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CssBaseline, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.AppBar, {
        enableColorOnDark: true,
        position: "fixed",
        color: "inherit",
        elevation: 0,
        sx: {
          bgcolor: theme.palette.background.default,
          transition: drawerOpen ? theme.transitions.create('width') : 'none'
        },
        children: header
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Sidebar__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(Main, {
        theme: theme,
        open: drawerOpen,
        children: [container && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Container, {
          maxWidth: "lg",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components_ui_component_extended_Breadcrumbs__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            separator: _tabler_icons__WEBPACK_IMPORTED_MODULE_12__.IconChevronRight,
            navigation: menu_items__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
            icon: true,
            title: true,
            rightAlign: true
          }), children]
        }), !container && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.Fragment, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components_ui_component_extended_Breadcrumbs__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            separator: _tabler_icons__WEBPACK_IMPORTED_MODULE_12__.IconChevronRight,
            navigation: menu_items__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
            icon: true,
            title: true,
            rightAlign: true
          }), children]
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Customization__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainLayout);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 73934:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Customization__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(91323);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Customization__WEBPACK_IMPORTED_MODULE_0__]);
_Customization__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// project imports
 // ==============================|| MINIMAL LAYOUT ||============================== //





const MinimalLayout = ({
  children
}) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
  children: [children, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_Customization__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {})]
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MinimalLayout);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 78358:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(66197);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_0__]);
framer_motion__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// third-party
 // ==============================|| ANIMATION FOR CONTENT ||============================== //



const NavMotion = ({
  children
}) => {
  const motionVariants = {
    initial: {
      opacity: 0,
      scale: 0.99
    },
    in: {
      opacity: 1,
      scale: 1
    },
    out: {
      opacity: 0,
      scale: 1.01
    }
  };
  const motionTransition = {
    type: 'tween',
    ease: 'anticipate',
    duration: 0.4
  };
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_0__.motion.div, {
    initial: "initial",
    animate: "in",
    exit: "out",
    variants: motionVariants,
    transition: motionTransition,
    children: children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavMotion);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

 // ==============================|| NAVIGATION SCROLL TO TOP ||============================== //

const NavigationScroll = ({
  children
}) => {
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }, []);
  return children || null;
};

NavigationScroll.propTypes = {
  children: (prop_types__WEBPACK_IMPORTED_MODULE_0___default().node)
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavigationScroll);

/***/ }),

/***/ 36927:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(40968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(61127);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var layout_NavigationScroll__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9881);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(95394);
/* harmony import */ var themes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(98626);
/* harmony import */ var layout_MainLayout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(25881);
/* harmony import */ var layout_GuestGuard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(55216);
/* harmony import */ var layout_MinimalLayout__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(73934);
/* harmony import */ var components_ui_component_RTLLayout__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(27476);
/* harmony import */ var components_ui_component_Locales__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(66267);
/* harmony import */ var components_ui_component_extended_Snackbar__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(67880);
/* harmony import */ var contexts_ConfigContext__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(63653);
/* harmony import */ var contexts_JWTContext__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(37762);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([layout_MainLayout__WEBPACK_IMPORTED_MODULE_7__, layout_GuestGuard__WEBPACK_IMPORTED_MODULE_8__, layout_MinimalLayout__WEBPACK_IMPORTED_MODULE_9__]);
([layout_MainLayout__WEBPACK_IMPORTED_MODULE_7__, layout_GuestGuard__WEBPACK_IMPORTED_MODULE_8__, layout_MinimalLayout__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



 // third-party

 // styles





 // project import










 // import { FirebaseProvider as AuthProvider } from '../contexts/FirebaseContext';
// import { Auth0Provider as AuthProvider } from '../contexts/Auth0Context';

 // import { AWSCognitoProvider as AuthProvider } from 'contexts/AWSCognitoContext';





const Noop = ({
  children
}) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.Fragment, {
  children: [" ", children, " "]
});

Noop.propTypes = {
  children: (prop_types__WEBPACK_IMPORTED_MODULE_0___default().node)
}; // ==============================|| APP ||============================== //

function App({
  Component,
  pageProps
}) {
  let Layout;

  switch (Component.Layout) {
    case 'authGuard':
      Layout = layout_MainLayout__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z;
      break;

    case 'guestGuard':
      Layout = layout_GuestGuard__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z;
      break;

    case 'minimalLayout':
      Layout = layout_MinimalLayout__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z;
      break;

    default:
      Layout = Noop;
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("title", {
        children: "MOST PROFESSIONAL REAL ESTATE AGENCY"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("link", {
        rel: "icon",
        href: "/favicon.svg"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_1__.Provider, {
      store: store__WEBPACK_IMPORTED_MODULE_5__/* .store */ .h,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_3__.PersistGate, {
        loading: null,
        persistor: store__WEBPACK_IMPORTED_MODULE_5__/* .persister */ .yT,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(contexts_ConfigContext__WEBPACK_IMPORTED_MODULE_13__/* .ConfigProvider */ .i, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(themes__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(components_ui_component_RTLLayout__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(components_ui_component_Locales__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(layout_NavigationScroll__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(contexts_JWTContext__WEBPACK_IMPORTED_MODULE_14__/* .JWTProvider */ .C, {
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(Layout, {
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(Component, _objectSpread({}, pageProps)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(components_ui_component_extended_Snackbar__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})]
                    })
                  })
                })
              })
            })
          })
        })
      })
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 98626:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ThemeCustomization)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(65692);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(18442);
// EXTERNAL MODULE: ./src/hooks/useConfig.js
var useConfig = __webpack_require__(20132);
// EXTERNAL MODULE: ./src/scss/_themes-vars.module.scss
var _themes_vars_module = __webpack_require__(70045);
var _themes_vars_module_default = /*#__PURE__*/__webpack_require__.n(_themes_vars_module);
// EXTERNAL MODULE: ./src/scss/_theme1.module.scss
var _theme1_module = __webpack_require__(85546);
var _theme1_module_default = /*#__PURE__*/__webpack_require__.n(_theme1_module);
// EXTERNAL MODULE: ./src/scss/_theme2.module.scss
var _theme2_module = __webpack_require__(12694);
var _theme2_module_default = /*#__PURE__*/__webpack_require__.n(_theme2_module);
// EXTERNAL MODULE: ./src/scss/_theme3.module.scss
var _theme3_module = __webpack_require__(9253);
var _theme3_module_default = /*#__PURE__*/__webpack_require__.n(_theme3_module);
// EXTERNAL MODULE: ./src/scss/_theme4.module.scss
var _theme4_module = __webpack_require__(39428);
var _theme4_module_default = /*#__PURE__*/__webpack_require__.n(_theme4_module);
// EXTERNAL MODULE: ./src/scss/_theme5.module.scss
var _theme5_module = __webpack_require__(41133);
var _theme5_module_default = /*#__PURE__*/__webpack_require__.n(_theme5_module);
// EXTERNAL MODULE: ./src/scss/_theme6.module.scss
var _theme6_module = __webpack_require__(18742);
var _theme6_module_default = /*#__PURE__*/__webpack_require__.n(_theme6_module);
;// CONCATENATED MODULE: ./src/themes/palette.js
// material-ui
 // assets







 // ==============================|| DEFAULT THEME - PALETTE  ||============================== //

const Palette = (navType, presetColor) => {
  let colors;

  switch (presetColor) {
    case 'theme1':
      colors = (_theme1_module_default());
      break;

    case 'theme2':
      colors = (_theme2_module_default());
      break;

    case 'theme3':
      colors = (_theme3_module_default());
      break;

    case 'theme4':
      colors = (_theme4_module_default());
      break;

    case 'theme5':
      colors = (_theme5_module_default());
      break;

    case 'theme6':
      colors = (_theme6_module_default());
      break;

    case 'default':
    default:
      colors = (_themes_vars_module_default());
  }

  return (0,styles_.createTheme)({
    palette: {
      mode: navType,
      common: {
        black: colors.darkPaper
      },
      primary: {
        light: navType === 'dark' ? colors.darkPrimaryLight : colors.primaryLight,
        main: navType === 'dark' ? colors.darkPrimaryMain : colors.primaryMain,
        dark: navType === 'dark' ? colors.darkPrimaryDark : colors.primaryDark,
        200: navType === 'dark' ? colors.darkPrimary200 : colors.primary200,
        800: navType === 'dark' ? colors.darkPrimary800 : colors.primary800
      },
      secondary: {
        light: navType === 'dark' ? colors.darkSecondaryLight : colors.secondaryLight,
        main: navType === 'dark' ? colors.darkSecondaryMain : colors.secondaryMain,
        dark: navType === 'dark' ? colors.darkSecondaryDark : colors.secondaryDark,
        200: navType === 'dark' ? colors.darkSecondary200 : colors.secondary200,
        800: navType === 'dark' ? colors.darkSecondary800 : colors.secondary800
      },
      error: {
        light: colors.errorLight,
        main: colors.errorMain,
        dark: colors.errorDark
      },
      orange: {
        light: colors.orangeLight,
        main: colors.orangeMain,
        dark: colors.orangeDark
      },
      warning: {
        light: colors.warningLight,
        main: colors.warningMain,
        dark: colors.warningDark
      },
      success: {
        light: colors.successLight,
        200: colors.success200,
        main: colors.successMain,
        dark: colors.successDark
      },
      grey: {
        50: colors.grey50,
        100: colors.grey100,
        500: navType === 'dark' ? colors.darkTextSecondary : colors.grey500,
        600: navType === 'dark' ? colors.darkTextTitle : colors.grey900,
        700: navType === 'dark' ? colors.darkTextPrimary : colors.grey700,
        900: navType === 'dark' ? colors.darkTextPrimary : colors.grey900
      },
      dark: {
        light: colors.darkTextPrimary,
        main: colors.darkLevel1,
        dark: colors.darkLevel2,
        800: colors.darkBackground,
        900: colors.darkPaper
      },
      text: {
        primary: navType === 'dark' ? colors.darkTextPrimary : colors.grey700,
        secondary: navType === 'dark' ? colors.darkTextSecondary : colors.grey500,
        dark: navType === 'dark' ? colors.darkTextPrimary : colors.grey900,
        hint: colors.grey100
      },
      divider: navType === 'dark' ? colors.darkTextPrimary : colors.grey200,
      background: {
        paper: navType === 'dark' ? colors.darkLevel2 : colors.paper,
        default: navType === 'dark' ? colors.darkPaper : colors.paper
      }
    }
  });
};

/* harmony default export */ const palette = (Palette);
;// CONCATENATED MODULE: ./src/themes/typography.js
const Typography = (theme, borderRadius, fontFamily) => ({
  fontFamily,
  h6: {
    fontWeight: 500,
    color: theme.palette.grey[600],
    fontSize: '0.75rem'
  },
  h5: {
    fontSize: '0.875rem',
    color: theme.palette.grey[600],
    fontWeight: 500
  },
  h4: {
    fontSize: '1rem',
    color: theme.palette.grey[600],
    fontWeight: 600
  },
  h3: {
    fontSize: '1.25rem',
    color: theme.palette.grey[600],
    fontWeight: 600
  },
  h2: {
    fontSize: '1.5rem',
    color: theme.palette.grey[600],
    fontWeight: 700
  },
  h1: {
    fontSize: '2.125rem',
    color: theme.palette.grey[600],
    fontWeight: 700
  },
  subtitle1: {
    fontSize: '0.875rem',
    fontWeight: 500,
    color: theme.palette.text.dark
  },
  subtitle2: {
    fontSize: '0.75rem',
    fontWeight: 400,
    color: theme.palette.text.secondary
  },
  caption: {
    fontSize: '0.75rem',
    color: theme.palette.text.secondary,
    fontWeight: 400
  },
  body1: {
    fontSize: '0.875rem',
    fontWeight: 400,
    lineHeight: '1.334em'
  },
  body2: {
    letterSpacing: '0em',
    fontWeight: 400,
    lineHeight: '1.5em',
    color: theme.palette.text.primary
  },
  button: {
    textTransform: 'capitalize'
  },
  customInput: {
    marginTop: 1,
    marginBottom: 1,
    '& > label': {
      top: 23,
      left: 0,
      color: theme.palette.grey[500],
      '&[data-shrink="false"]': {
        top: 5
      }
    },
    '& > div > input': {
      padding: '30.5px 14px 11.5px !important'
    },
    '& legend': {
      display: 'none'
    },
    '& fieldset': {
      top: 0
    }
  },
  mainContent: {
    backgroundColor: theme.palette.mode === 'dark' ? theme.palette.dark[800] : theme.palette.primary.light,
    width: '100%',
    minHeight: 'calc(100vh - 88px)',
    flexGrow: 1,
    padding: '20px',
    marginTop: '88px',
    marginRight: '20px',
    borderRadius: `${borderRadius}px`
  },
  menuCaption: {
    fontSize: '0.875rem',
    fontWeight: 500,
    color: theme.palette.grey[600],
    padding: '6px',
    textTransform: 'capitalize',
    marginTop: '10px'
  },
  subMenuCaption: {
    fontSize: '0.6875rem',
    fontWeight: 500,
    color: theme.palette.text.secondary,
    textTransform: 'capitalize'
  },
  commonAvatar: {
    cursor: 'pointer',
    borderRadius: '8px'
  },
  smallAvatar: {
    width: '22px',
    height: '22px',
    fontSize: '1rem'
  },
  mediumAvatar: {
    width: '34px',
    height: '34px',
    fontSize: '1.2rem'
  },
  largeAvatar: {
    width: '44px',
    height: '44px',
    fontSize: '1.5rem'
  }
});

/* harmony default export */ const typography = (Typography);
;// CONCATENATED MODULE: ./src/themes/compStyleOverride.js
function componentStyleOverrides(theme, borderRadius, outlinedFilled) {
  const mode = theme.palette.mode;
  const bgColor = mode === 'dark' ? theme.palette.dark[800] : theme.palette.grey[50];
  const menuSelectedBack = mode === 'dark' ? theme.palette.secondary.main + 15 : theme.palette.secondary.light;
  const menuSelected = mode === 'dark' ? theme.palette.secondary.main : theme.palette.secondary.dark;
  return {
    MuiButton: {
      styleOverrides: {
        root: {
          fontWeight: 500,
          borderRadius: '4px'
        }
      }
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          color: bgColor
        }
      }
    },
    MuiPaper: {
      defaultProps: {
        elevation: 0
      },
      styleOverrides: {
        root: {
          backgroundImage: 'none'
        },
        rounded: {
          borderRadius: `${borderRadius}px`
        }
      }
    },
    MuiCardHeader: {
      styleOverrides: {
        root: {
          color: theme.palette.text.dark,
          padding: '24px'
        },
        title: {
          fontSize: '1.125rem'
        }
      }
    },
    MuiCardContent: {
      styleOverrides: {
        root: {
          padding: '24px'
        }
      }
    },
    MuiCardActions: {
      styleOverrides: {
        root: {
          padding: '24px'
        }
      }
    },
    MuiAlert: {
      styleOverrides: {
        root: {
          alignItems: 'center'
        },
        outlined: {
          border: '1px dashed'
        }
      }
    },
    MuiListItemButton: {
      styleOverrides: {
        root: {
          color: theme.palette.text.primary,
          paddingTop: '10px',
          paddingBottom: '10px',
          '&.Mui-selected': {
            color: menuSelected,
            backgroundColor: menuSelectedBack,
            '&:hover': {
              backgroundColor: menuSelectedBack
            },
            '& .MuiListItemIcon-root': {
              color: menuSelected
            }
          },
          '&:hover': {
            backgroundColor: menuSelectedBack,
            color: menuSelected,
            '& .MuiListItemIcon-root': {
              color: menuSelected
            }
          }
        }
      }
    },
    MuiListItemIcon: {
      styleOverrides: {
        root: {
          color: theme.palette.text.primary,
          minWidth: '36px'
        }
      }
    },
    MuiListItemText: {
      styleOverrides: {
        primary: {
          color: theme.palette.text.dark
        }
      }
    },
    MuiInputBase: {
      styleOverrides: {
        input: {
          color: theme.palette.text.dark,
          '&::placeholder': {
            color: theme.palette.text.secondary,
            fontSize: '0.875rem'
          }
        }
      }
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          background: outlinedFilled ? bgColor : 'transparent',
          borderRadius: `${borderRadius}px`,
          '& .MuiOutlinedInput-notchedOutline': {
            borderColor: mode === 'dark' ? theme.palette.text.primary + 28 : theme.palette.grey[400]
          },
          '&:hover $notchedOutline': {
            borderColor: theme.palette.primary.light
          },
          '&.MuiInputBase-multiline': {
            padding: 1
          }
        },
        input: {
          fontWeight: 500,
          background: outlinedFilled ? bgColor : 'transparent',
          padding: '15.5px 14px',
          borderRadius: `${borderRadius}px`,
          '&.MuiInputBase-inputSizeSmall': {
            padding: '10px 14px',
            '&.MuiInputBase-inputAdornedStart': {
              paddingLeft: 0
            }
          }
        },
        inputAdornedStart: {
          paddingLeft: 4
        },
        notchedOutline: {
          borderRadius: `${borderRadius}px`
        }
      }
    },
    MuiSlider: {
      styleOverrides: {
        root: {
          '&.Mui-disabled': {
            color: mode === 'dark' ? theme.palette.text.primary + 50 : theme.palette.grey[300]
          }
        },
        mark: {
          backgroundColor: theme.palette.background.paper,
          width: '4px'
        },
        valueLabel: {
          color: mode === 'dark' ? theme.palette.primary.main : theme.palette.primary.light
        }
      }
    },
    MuiAutocomplete: {
      styleOverrides: {
        root: {
          '& .MuiAutocomplete-tag': {
            background: mode === 'dark' ? theme.palette.text.primary + 20 : theme.palette.secondary.light,
            borderRadius: 4,
            color: theme.palette.text.dark,
            '.MuiChip-deleteIcon': {
              color: mode === 'dark' ? theme.palette.text.primary + 80 : theme.palette.secondary[200]
            }
          }
        },
        popper: {
          borderRadius: `${borderRadius}px`,
          boxShadow: '0px 8px 10px -5px rgb(0 0 0 / 20%), 0px 16px 24px 2px rgb(0 0 0 / 14%), 0px 6px 30px 5px rgb(0 0 0 / 12%)'
        }
      }
    },
    MuiDivider: {
      styleOverrides: {
        root: {
          borderColor: theme.palette.divider,
          opacity: mode === 'dark' ? 0.2 : 1
        }
      }
    },
    MuiSelect: {
      styleOverrides: {
        select: {
          '&:focus': {
            backgroundColor: 'transparent'
          }
        }
      }
    },
    MuiAvatar: {
      styleOverrides: {
        root: {
          color: mode === 'dark' ? theme.palette.dark.main : theme.palette.primary.dark,
          background: mode === 'dark' ? theme.palette.text.primary : theme.palette.primary[200]
        }
      }
    },
    MuiChip: {
      styleOverrides: {
        root: {
          '&.MuiChip-deletable .MuiChip-deleteIcon': {
            color: 'inherit'
          }
        }
      }
    },
    MuiTimelineContent: {
      styleOverrides: {
        root: {
          color: theme.palette.text.dark,
          fontSize: '16px'
        }
      }
    },
    MuiTreeItem: {
      styleOverrides: {
        label: {
          marginTop: 14,
          marginBottom: 14
        }
      }
    },
    MuiTimelineDot: {
      styleOverrides: {
        root: {
          boxShadow: 'none'
        }
      }
    },
    MuiInternalDateTimePickerTabs: {
      styleOverrides: {
        tabs: {
          backgroundColor: mode === 'dark' ? theme.palette.dark[900] : theme.palette.primary.light,
          '& .MuiTabs-flexContainer': {
            borderColor: mode === 'dark' ? theme.palette.text.primary + 20 : theme.palette.primary[200]
          },
          '& .MuiTab-root': {
            color: mode === 'dark' ? theme.palette.text.secondary : theme.palette.grey[900]
          },
          '& .MuiTabs-indicator': {
            backgroundColor: theme.palette.primary.dark
          },
          '& .Mui-selected': {
            color: theme.palette.primary.dark
          }
        }
      }
    },
    MuiTabs: {
      styleOverrides: {
        flexContainer: {
          borderBottom: '1px solid',
          borderColor: mode === 'dark' ? theme.palette.text.primary + 20 : theme.palette.grey[200]
        }
      }
    },
    MuiDialog: {
      styleOverrides: {
        paper: {
          padding: '12px 0 12px 0'
        }
      }
    },
    MuiTableCell: {
      styleOverrides: {
        root: {
          borderColor: mode === 'dark' ? theme.palette.text.primary + 15 : theme.palette.grey[200],
          '&.MuiTableCell-head': {
            fontSize: '0.875rem',
            color: theme.palette.grey[600],
            fontWeight: 500
          }
        }
      }
    },
    MuiTooltip: {
      styleOverrides: {
        tooltip: {
          color: theme.palette.background.paper,
          background: theme.palette.text.primary
        }
      }
    },
    MuiDialogTitle: {
      styleOverrides: {
        root: {
          fontSize: '1.25rem'
        }
      }
    },
    MuiFormHelperText: {
      styleOverrides: {
        root: {
          color: theme.palette.primary.light
        }
      }
    }
  };
}
;// CONCATENATED MODULE: ./src/themes/shadows.js


const createCustomShadow = (theme, color) => {
  const transparent = (0,styles_.alpha)(color, 0.24);
  return {
    z1: `0 1px 2px 0 ${transparent}`,
    z8: `0 8px 16px 0 ${transparent}`,
    z12: `0 12px 24px 0 ${transparent} 0 10px 20px 0 ${transparent}`,
    z16: `0 0 3px 0 ${transparent} 0 14px 28px -5px ${transparent}`,
    z20: `0 0 3px 0 ${transparent} 0 18px 36px -5px ${transparent}`,
    z24: `0 0 6px 0 ${transparent} 0 21px 44px 0 ${transparent}`,
    primary: `0px 12px 14px 0px ${(0,styles_.alpha)(theme.palette.primary.main, 0.3)}`,
    secondary: `0px 12px 14px 0px ${(0,styles_.alpha)(theme.palette.secondary.main, 0.3)}`,
    orange: `0px 12px 14px 0px ${(0,styles_.alpha)(theme.palette.orange.main, 0.3)}`,
    success: `0px 12px 14px 0px ${(0,styles_.alpha)(theme.palette.success.main, 0.3)}`,
    warning: `0px 12px 14px 0px ${(0,styles_.alpha)(theme.palette.warning.main, 0.3)}`,
    error: `0px 12px 14px 0px ${(0,styles_.alpha)(theme.palette.error.main, 0.3)}`
  };
};

function customShadows(navType, theme) {
  return navType === 'dark' ? createCustomShadow(theme, theme.palette.dark.main) : createCustomShadow(theme, theme.palette.grey[600]);
}
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/themes/index.js
 // material-ui


 // project import





 // assets










function ThemeCustomization({
  children
}) {
  const config = (0,useConfig/* default */.Z)();
  const {
    borderRadius,
    fontFamily,
    navType,
    outlinedFilled,
    presetColor,
    rtlLayout
  } = (0,useConfig/* default */.Z)();
  const theme = (0,external_react_.useMemo)(() => palette(navType, presetColor), [navType, presetColor]); // eslint-disable-next-line react-hooks/exhaustive-deps

  const themeTypography = (0,external_react_.useMemo)(() => typography(theme, borderRadius, fontFamily), [theme, borderRadius, fontFamily]);
  const themeCustomShadows = (0,external_react_.useMemo)(() => customShadows(navType, theme), [navType, theme]);
  let color;

  switch (config.presetColor) {
    case 'theme1':
      color = (_theme1_module_default());
      break;

    case 'theme2':
      color = (_theme2_module_default());
      break;

    case 'theme3':
      color = (_theme3_module_default());
      break;

    case 'theme4':
      color = (_theme4_module_default());
      break;

    case 'theme5':
      color = (_theme5_module_default());
      break;

    case 'theme6':
      color = (_theme6_module_default());
      break;

    case 'default':
    default:
      color = (_themes_vars_module_default());
  }

  const themeOption = {
    colors: color,
    heading: '',
    paper: '',
    backgroundDefault: '',
    background: '',
    darkTextPrimary: '',
    darkTextSecondary: '',
    textDark: '',
    menuSelected: '',
    menuSelectedBack: '',
    divider: '',
    customization: config
  };

  switch (config.navType) {
    case 'dark':
      themeOption.paper = color.darkLevel2;
      themeOption.backgroundDefault = color.darkPaper;
      themeOption.background = color.darkBackground;
      themeOption.darkTextPrimary = color.darkTextPrimary;
      themeOption.darkTextSecondary = color.darkTextSecondary;
      themeOption.textDark = color.darkTextPrimary;
      themeOption.menuSelected = color.darkSecondaryMain;
      themeOption.menuSelectedBack = color.darkSecondaryMain + 15;
      themeOption.divider = color.darkTextPrimary;
      themeOption.heading = color.darkTextTitle;
      break;

    case 'light':
    default:
      themeOption.paper = color.paper;
      themeOption.backgroundDefault = color.paper;
      themeOption.background = color.primaryLight;
      themeOption.darkTextPrimary = color.grey700;
      themeOption.darkTextSecondary = color.grey500;
      themeOption.textDark = color.grey900;
      themeOption.menuSelected = color.secondaryDark;
      themeOption.menuSelectedBack = color.secondaryLight;
      themeOption.divider = color.grey200;
      themeOption.heading = color.grey900;
      break;
  }

  const themeOptions = (0,external_react_.useMemo)(() => ({
    direction: rtlLayout ? 'rtl' : 'ltr',
    palette: theme.palette,
    mixins: {
      toolbar: {
        minHeight: '48px',
        padding: '16px',
        '@media (min-width: 600px)': {
          minHeight: '48px'
        }
      }
    },
    typography: themeTypography,
    customShadows: themeCustomShadows
  }), [rtlLayout, theme, themeCustomShadows, themeTypography]);
  const themes = (0,styles_.createTheme)(themeOptions);
  themes.components = (0,external_react_.useMemo)(() => componentStyleOverrides(themes, borderRadius, outlinedFilled), [themes, borderRadius, outlinedFilled]);
  return /*#__PURE__*/jsx_runtime_.jsx(material_.StyledEngineProvider, {
    injectFirst: true,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(styles_.ThemeProvider, {
      theme: themes,
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.CssBaseline, {}), children]
    })
  });
}

/***/ }),

/***/ 57178:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks_useAuth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49684);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);

 // project imports


 // ==============================|| AUTH GUARD ||============================== //

/**
 * Authentication guard for routes
 * @param {PropTypes.node} children children element/node
 */

const AuthGuard = ({
  children
}) => {
  const {
    isLoggedIn
  } = (0,hooks_useAuth__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    if (!isLoggedIn) {
      router.push('/login');
    } // eslint-disable-next-line

  }, [isLoggedIn]);
  return children;
};

AuthGuard.propTypes = {
  children: (prop_types__WEBPACK_IMPORTED_MODULE_0___default().node)
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthGuard);

/***/ }),

/***/ 62182:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks_useAuth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49684);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7878);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);

 // project imports



 // ==============================|| GUEST GUARD ||============================== //

/**
 * Guest guard for routes having no auth required
 * @param {PropTypes.node} children children element/node
 */

const GuestGuard = ({
  children
}) => {
  const {
    isLoggedIn
  } = (0,hooks_useAuth__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(() => {
    if (isLoggedIn) {
      router.push(config__WEBPACK_IMPORTED_MODULE_3__/* .DASHBOARD_PATH */ .tu);
    } // eslint-disable-next-line

  }, [isLoggedIn]);
  return children;
};

GuestGuard.propTypes = {
  children: (prop_types__WEBPACK_IMPORTED_MODULE_0___default().node)
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GuestGuard);

/***/ }),

/***/ 84118:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountTreeTwoTone");

/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 77943:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FiberManualRecord");

/***/ }),

/***/ 73467:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 76942:
/***/ ((module) => {

module.exports = require("@mui/icons-material/HomeTwoTone");

/***/ }),

/***/ 65692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 87185:
/***/ ((module) => {

module.exports = require("@mui/material/Breadcrumbs");

/***/ }),

/***/ 25545:
/***/ ((module) => {

module.exports = require("@mui/material/LinearProgress");

/***/ }),

/***/ 85246:
/***/ ((module) => {

module.exports = require("@mui/material/Link");

/***/ }),

/***/ 18442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 97986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 75184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 94116:
/***/ ((module) => {

module.exports = require("@tabler/icons");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 40306:
/***/ ((module) => {

module.exports = require("chance");

/***/ }),

/***/ 68103:
/***/ ((module) => {

module.exports = require("clsx");

/***/ }),

/***/ 99344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 45567:
/***/ ((module) => {

module.exports = require("jwt-decode");

/***/ }),

/***/ 60562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 78028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 13126:
/***/ ((module) => {

module.exports = require("react-intl");

/***/ }),

/***/ 55162:
/***/ ((module) => {

module.exports = require("react-perfect-scrollbar");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 86695:
/***/ ((module) => {

module.exports = require("redux");

/***/ }),

/***/ 14161:
/***/ ((module) => {

module.exports = require("redux-persist");

/***/ }),

/***/ 61127:
/***/ ((module) => {

module.exports = require("redux-persist/integration/react");

/***/ }),

/***/ 98936:
/***/ ((module) => {

module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ 66197:
/***/ ((module) => {

module.exports = import("framer-motion");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [639,676,1664,5675,2107,7878,2278,1588,5394,1931,5482,132,9684,45,1323,1137,9898], () => (__webpack_exec__(36927)));
module.exports = __webpack_exports__;

})();