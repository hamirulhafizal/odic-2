"use strict";
(() => {
var exports = {};
exports.id = 6959;
exports.ids = [6959];
exports.modules = {

/***/ 40306:
/***/ ((module) => {

module.exports = require("chance");

/***/ }),

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 68001:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var chance__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(40306);
/* harmony import */ var chance__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(chance__WEBPACK_IMPORTED_MODULE_1__);


const chance = new chance__WEBPACK_IMPORTED_MODULE_1__.Chance();
const productReviews = [{
  id: '1',
  rating: chance.floating({
    min: 0.2,
    max: 5.0
  }),
  review: chance.paragraph({
    sentences: 2
  }),
  date: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 0,
    hours: 1,
    minutes: 45
  }),
  profile: {
    avatar: 'user-1.png',
    name: chance.name({
      nationality: 'en'
    }),
    status: chance.bool()
  }
}, {
  id: '2',
  rating: chance.floating({
    min: 0.1,
    max: 5.0
  }),
  review: chance.paragraph({
    sentences: 2
  }),
  date: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 5,
    hours: 12,
    minutes: 55
  }),
  profile: {
    avatar: 'user-2.png',
    name: chance.name({
      nationality: 'en'
    }),
    status: chance.bool()
  }
}, {
  id: '3',
  rating: chance.floating({
    min: 0.1,
    max: 5.0
  }),
  review: chance.paragraph({
    sentences: 2
  }),
  date: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 8,
    hours: 6,
    minutes: 20
  }),
  profile: {
    avatar: 'user-3.png',
    name: chance.name({
      nationality: 'en'
    }),
    status: chance.bool()
  }
}];
function handler(req, res) {
  res.status(200).json({
    productReviews
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(68001));
module.exports = __webpack_exports__;

})();