"use strict";
(() => {
var exports = {};
exports.id = 8068;
exports.ids = [8068];
exports.modules = {

/***/ 40306:
/***/ ((module) => {

module.exports = require("chance");

/***/ }),

/***/ 46555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 11926:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var chance__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(40306);
/* harmony import */ var chance__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(chance__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(46555);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_1__]);
uuid__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const chance = new chance__WEBPACK_IMPORTED_MODULE_0__.Chance();
let address = [{
  id: 1,
  name: chance.name(),
  destination: 'home',
  building: chance.address({
    short_suffix: true
  }),
  street: chance.address({
    short_suffix: false
  }),
  city: chance.city(),
  state: chance.state({
    full: true
  }),
  country: chance.country({
    full: true
  }),
  post: chance.postcode(),
  phone: chance.phone(),
  isDefault: true
}, {
  id: 2,
  name: chance.name(),
  destination: 'office',
  building: chance.address({
    short_suffix: true
  }),
  street: chance.address({
    short_suffix: false
  }),
  city: chance.city(),
  state: chance.state({
    full: true
  }),
  country: chance.country({
    full: true
  }),
  post: chance.postcode(),
  phone: chance.phone(),
  isDefault: false
}];
function handler(req, res) {
  const {
    name,
    destination,
    building,
    street,
    city,
    state,
    country,
    post,
    phone,
    isDefault
  } = req.body;
  const newAddress = {
    id: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
    name,
    destination,
    building,
    street,
    city,
    state,
    country,
    post,
    phone,
    isDefault
  };

  if (isDefault) {
    address = address.map(item => {
      if (item.isDefault === true) {
        return _objectSpread(_objectSpread({}, item), {}, {
          isDefault: false
        });
      }

      return item;
    });
  }

  address = [...address, newAddress];
  res.status(200).json({
    address
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(11926));
module.exports = __webpack_exports__;

})();