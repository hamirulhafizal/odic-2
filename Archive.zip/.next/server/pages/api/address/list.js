"use strict";
(() => {
var exports = {};
exports.id = 4773;
exports.ids = [4773];
exports.modules = {

/***/ 40306:
/***/ ((module) => {

module.exports = require("chance");

/***/ }),

/***/ 75415:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var chance__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(40306);
/* harmony import */ var chance__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(chance__WEBPACK_IMPORTED_MODULE_0__);

const chance = new chance__WEBPACK_IMPORTED_MODULE_0__.Chance();
const address = [{
  id: 1,
  name: chance.name(),
  destination: 'home',
  building: chance.address({
    short_suffix: true
  }),
  street: chance.address({
    short_suffix: false
  }),
  city: chance.city(),
  state: chance.state({
    full: true
  }),
  country: chance.country({
    full: true
  }),
  post: chance.postcode(),
  phone: chance.phone(),
  isDefault: true
}, {
  id: 2,
  name: chance.name(),
  destination: 'office',
  building: chance.address({
    short_suffix: true
  }),
  street: chance.address({
    short_suffix: false
  }),
  city: chance.city(),
  state: chance.state({
    full: true
  }),
  country: chance.country({
    full: true
  }),
  post: chance.postcode(),
  phone: chance.phone(),
  isDefault: false
}];
function handler(req, res) {
  res.status(200).json({
    address
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(75415));
module.exports = __webpack_exports__;

})();