"use strict";
(() => {
var exports = {};
exports.id = 9239;
exports.ids = [9239];
exports.modules = {

/***/ 99344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 23182:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(99344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(85401);
 // project imports

 // constant

const JWT_SECRET = config__WEBPACK_IMPORTED_MODULE_1__/* .JWT_API.secret */ .Sk.secret;
let users = [{
  id: '5e86809283e28b96d2d38537',
  email: 'info@codedthemes.com',
  password: '123456',
  name: 'JWT User'
}];
async function handler(req, res) {
  const {
    Authorization
  } = req.headers;

  if (!Authorization) {
    res.status(401).json({
      message: 'Token Missing'
    });
  }

  if (window.localStorage.getItem('users') !== undefined && window.localStorage.getItem('users') !== null) {
    const localUsers = window.localStorage.getItem('users');
    users = JSON.parse(localUsers);
  }

  const serviceToken = Authorization.toString();
  const jwData = jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default().verify(serviceToken, JWT_SECRET);
  const {
    userId
  } = jwData;
  const user = users.find(_user => _user.id === userId);

  if (!user) {
    return res.status(401).json({
      message: 'Invalid Token'
    });
  }

  return res.status(200).json({
    user: {
      id: user.id,
      email: user.email
    }
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5401], () => (__webpack_exec__(23182)));
module.exports = __webpack_exports__;

})();