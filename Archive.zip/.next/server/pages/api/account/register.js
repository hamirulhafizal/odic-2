"use strict";
(() => {
var exports = {};
exports.id = 1502;
exports.ids = [1502];
exports.modules = {

/***/ 72640:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
const delay = timeout => new Promise(res => setTimeout(res, timeout));

let users = [{
  id: '5e86809283e28b96d2d38537',
  email: 'info@codedthemes.com',
  password: '123456',
  name: 'JWT User'
}];
async function handler(req, res) {
  await delay(500);
  const {
    id,
    email,
    password,
    firstName,
    lastName
  } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      message: 'Enter Your Email & Password'
    });
  }

  if (!firstName || !lastName) {
    return res.status(400).json({
      message: 'Enter Your Name'
    });
  }

  users = [...users, {
    id,
    email,
    password,
    name: `${firstName} ${lastName}`
  }];
  return res.status(200).json(users);
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(72640));
module.exports = __webpack_exports__;

})();