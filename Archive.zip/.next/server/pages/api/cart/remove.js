"use strict";
(() => {
var exports = {};
exports.id = 2435;
exports.ids = [2435];
exports.modules = {

/***/ 46517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 7622:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(46517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);

let subtotal;
let result;
function handler(req, res) {
  const {
    id,
    products
  } = req.body;
  result = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.filter)(products, {
    itemId: id
  });
  subtotal = result[0].quantity * result[0].offerPrice;
  const newProducts = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.filter)(products, item => item.itemId !== id);
  return res.status(200).json({
    products: newProducts,
    subtotal
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7622));
module.exports = __webpack_exports__;

})();