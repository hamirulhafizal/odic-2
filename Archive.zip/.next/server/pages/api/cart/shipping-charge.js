"use strict";
(() => {
var exports = {};
exports.id = 2108;
exports.ids = [2108];
exports.modules = {

/***/ 42161:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
let newShipping;
function handler(req, res) {
  const {
    shipping,
    charge
  } = req.body;
  newShipping = 0;

  if (shipping > 0 && charge === 'free') {
    newShipping = -5;
  }

  if (charge === 'fast') {
    newShipping = 5;
  }

  return res.status(200).json({
    shipping: charge === 'fast' ? 5 : 0,
    newShipping,
    type: charge
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(42161));
module.exports = __webpack_exports__;

})();