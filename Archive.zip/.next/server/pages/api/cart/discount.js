"use strict";
(() => {
var exports = {};
exports.id = 3249;
exports.ids = [3249];
exports.modules = {

/***/ 40306:
/***/ ((module) => {

module.exports = require("chance");

/***/ }),

/***/ 32398:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var chance__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(40306);
/* harmony import */ var chance__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(chance__WEBPACK_IMPORTED_MODULE_0__);

const chance = new chance__WEBPACK_IMPORTED_MODULE_0__.Chance();
let amount;
function handler(req, res) {
  const {
    total,
    code
  } = req.body;
  amount = 0;

  if (total > 0) {
    switch (code) {
      case 'BERRY50':
        amount = chance.integer({
          min: 1,
          max: total < 49 ? total : 49
        });
        break;

      case 'FLAT05':
        amount = total < 5 ? total : 5;
        break;

      case 'SUB150':
        amount = total < 150 ? total : 150;
        break;

      case 'UPTO200':
        amount = chance.integer({
          min: 1,
          max: total < 199 ? total : 199
        });
        break;

      default:
        amount = 0;
    }
  }

  return res.status(200).json({
    amount
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(32398));
module.exports = __webpack_exports__;

})();