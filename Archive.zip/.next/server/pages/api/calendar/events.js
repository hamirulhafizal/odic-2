"use strict";
(() => {
var exports = {};
exports.id = 4464;
exports.ids = [4464];
exports.modules = {

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 66725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52093);
/* harmony import */ var scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1__);


const events = [{
  id: '5e8882f1f0c9216397e05a9b',
  allDay: false,
  color: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().secondaryMain),
  description: 'SCRUM Planning',
  start: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 12,
    hours: 0,
    minutes: 45
  }),
  end: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 12,
    hours: 0,
    minutes: 30
  }),
  title: 'Repeating Event'
}, {
  id: '5e8882fcd525e076b3c1542c',
  allDay: true,
  color: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().orangeLight),
  textColor: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().orangeDark),
  description: 'Sorry, John!',
  start: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 8,
    hours: 0,
    minutes: 45
  }),
  end: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 8,
    hours: 0,
    minutes: 30
  }),
  title: 'Conference'
}, {
  id: '5e8882e440f6322fa399eeb8',
  allDay: true,
  color: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().successLight),
  textColor: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().successDark),
  description: 'Inform about new contract',
  start: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 6,
    hours: 6,
    minutes: 30
  }),
  end: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 7,
    hours: 4,
    minutes: 30
  }),
  title: 'All Day Event'
}, {
  id: '5e88830672d089c53c46ece3',
  allDay: false,
  color: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().primaryMain),
  description: 'Get a new quote for the payment processor',
  start: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.set)(new Date(), {
    hours: 10,
    minutes: 30
  }),
  end: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.set)(new Date(), {
    hours: 13,
    minutes: 30
  }),
  title: 'Lunch'
}, {
  id: '5e888302e62149e4b49aa609',
  allDay: false,
  textColor: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().grey900),
  color: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().warningMain),
  description: 'Discuss about the new project',
  start: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 2,
    hours: 3,
    minutes: 30
  }),
  end: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 2,
    hours: 3,
    minutes: 20
  }),
  title: 'Meeting'
}, {
  id: '5e888302e62149e4b49aa709',
  allDay: false,
  color: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().errorDark),
  description: "Let's Go",
  start: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 2,
    hours: 2,
    minutes: 30
  }),
  end: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 2,
    hours: 3,
    minutes: 30
  }),
  title: 'Birthday Party'
}, {
  id: '5e8882f1f0c9216396e05a9b',
  allDay: false,
  color: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().secondaryMain),
  description: 'SCRUM Planning',
  start: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 2,
    hours: 3,
    minutes: 30
  }),
  end: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 2,
    hours: 4,
    minutes: 30
  }),
  title: 'Repeating Event'
}, {
  id: '5e888302e62149e4b49aa610',
  allDay: false,
  color: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().grey500),
  description: "Let's Go",
  start: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 2,
    hours: 3,
    minutes: 45
  }),
  end: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 2,
    hours: 4,
    minutes: 50
  }),
  title: 'Dinner'
}, {
  id: '5e8882eb5f8ec686220ff131',
  allDay: true,
  color: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().secondaryLight),
  textColor: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().secondaryDark),
  description: 'Discuss about new partnership',
  start: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 5,
    hours: 0,
    minutes: 0
  }),
  end: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 8,
    hours: 1,
    minutes: 0
  }),
  title: 'Long Event'
}, {
  id: '5e888302e62349e4b49aa609',
  allDay: false,
  color: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().primaryLight),
  textColor: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().primary800),
  description: 'Discuss about the project launch',
  start: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 6,
    hours: 0,
    minutes: 15
  }),
  end: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 6,
    hours: 0,
    minutes: 20
  }),
  title: 'Meeting'
}, {
  id: '5e888302e62149e4b49ab609',
  allDay: false,
  color: (scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_1___default().successMain),
  description: 'Discuss about the tour',
  start: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 12,
    hours: 3,
    minutes: 45
  }),
  end: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 12,
    hours: 4,
    minutes: 50
  }),
  title: 'Happy Hour'
}];
function handler(req, res) {
  res.status(200).json({
    events
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2093], () => (__webpack_exec__(66725)));
module.exports = __webpack_exports__;

})();