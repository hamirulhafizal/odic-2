"use strict";
(() => {
var exports = {};
exports.id = 5473;
exports.ids = [5473];
exports.modules = {

/***/ 19157:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
const userStoryIdsData = {
  userStory1: `1`,
  userStory2: `2`,
  userStory3: `3`,
  userStory4: `4`
};
const userStoryOrderData = [userStoryIdsData.userStory1, userStoryIdsData.userStory2, userStoryIdsData.userStory3, userStoryIdsData.userStory4];
function handler(req, res) {
  return res.status(200).json({
    userStoryOrder: userStoryOrderData
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(19157));
module.exports = __webpack_exports__;

})();