"use strict";
(() => {
var exports = {};
exports.id = 5634;
exports.ids = [5634];
exports.modules = {

/***/ 86973:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
const profileIdsData = {
  profile1: 'profile-1',
  profile2: 'profile-2',
  profile3: 'profile-3'
};
const profilesData = [{
  id: profileIdsData.profile1,
  avatar: 'avatar-3.png',
  name: 'Barney Thea',
  time: '2 min ago'
}, {
  id: profileIdsData.profile2,
  avatar: 'avatar-1.png',
  name: 'Maddison Wilber',
  time: '1 day ago'
}, {
  id: profileIdsData.profile3,
  avatar: 'avatar-2.png',
  name: 'John Doe',
  time: 'now'
}];
function handler(req, res) {
  return res.status(200).json({
    profiles: profilesData
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(86973));
module.exports = __webpack_exports__;

})();