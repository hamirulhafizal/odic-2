"use strict";
(() => {
var exports = {};
exports.id = 167;
exports.ids = [167];
exports.modules = {

/***/ 51526:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
const columnIdsData = {
  column1: 'column-1',
  column2: 'column-2',
  column3: 'column-3',
  column4: 'column-4'
};
const columnsOrderData = [columnIdsData.column1, columnIdsData.column2, columnIdsData.column3, columnIdsData.column4];
function handler(req, res) {
  return res.status(200).json({
    columnsOrder: columnsOrderData
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(51526));
module.exports = __webpack_exports__;

})();