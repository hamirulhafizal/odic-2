"use strict";
(() => {
var exports = {};
exports.id = 1617;
exports.ids = [1617];
exports.modules = {

/***/ 74146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 41528:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_0__);

const itemIdsData = {
  item1: `1`,
  item2: `2`,
  item3: `3`,
  item4: `4`,
  item5: `5`,
  item6: `6`,
  item7: `7`,
  item8: `8`,
  item9: `9`,
  item10: `10`
};
const profileIdsData = {
  profile1: 'profile-1',
  profile2: 'profile-2',
  profile3: 'profile-3'
};
const commentIdsData = {
  comment1: 'comment-1',
  comment2: 'comment-2',
  comment3: 'comment-3',
  comment4: 'comment-4',
  comment5: 'comment-5'
};
const itemsData = [{
  assign: profileIdsData.profile1,
  attachments: [],
  commentIds: [commentIdsData.comment1],
  description: 'Content of item 1',
  dueDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 12
  }),
  id: itemIdsData.item1,
  image: 'profile-back-1.png',
  priority: 'low',
  title: 'Online fees payment & instant announcements'
}, {
  assign: profileIdsData.profile2,
  attachments: [],
  commentIds: [commentIdsData.comment2, commentIdsData.comment5],
  description: 'Content of item 2',
  dueDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 18
  }),
  id: itemIdsData.item2,
  image: false,
  priority: 'high',
  title: 'Creation and Maintenance of Inventory Objects'
}, {
  assign: profileIdsData.profile3,
  attachments: [],
  description: 'Content of item 3',
  dueDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 8
  }),
  id: itemIdsData.item3,
  image: false,
  priority: 'low',
  title: 'Update React & TypeScript version'
}, {
  assign: profileIdsData.profile2,
  attachments: [],
  commentIds: [commentIdsData.comment4],
  description: 'Content of item 4',
  dueDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 6
  }),
  id: itemIdsData.item4,
  image: 'profile-back-2.png',
  priority: 'low',
  title: 'Set allowing rules for trusted applications.'
}, {
  assign: profileIdsData.profile2,
  attachments: [],
  commentIds: [commentIdsData.comment1, commentIdsData.comment2, commentIdsData.comment5],
  description: 'Content of item 5',
  dueDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.sub)(new Date(), {
    days: 9
  }),
  id: itemIdsData.item5,
  image: 'profile-back-3.png',
  priority: 'medium',
  title: 'Managing Applications Launch Control'
}, {
  assign: profileIdsData.profile3,
  attachments: [],
  commentIds: [commentIdsData.comment3, commentIdsData.comment4],
  description: 'Content of item 6',
  dueDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.set)(new Date(), {
    hours: 10,
    minutes: 30
  }),
  id: itemIdsData.item6,
  image: false,
  priority: 'medium',
  title: 'Run codemods'
}, {
  assign: profileIdsData.profile1,
  attachments: [],
  description: 'Content of item 7',
  dueDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 5
  }),
  id: itemIdsData.item7,
  image: 'profile-back-4.png',
  priority: 'low',
  title: 'Purchase Requisitions, Adjustments, and Transfers.'
}, {
  assign: profileIdsData.profile1,
  attachments: [],
  description: 'Content of item 8',
  dueDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 17
  }),
  id: itemIdsData.item8,
  image: false,
  priority: 'low',
  title: 'Attendance checking & homework details'
}, {
  assign: profileIdsData.profile3,
  attachments: [],
  commentIds: [commentIdsData.comment3],
  description: 'Content of item 9',
  dueDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 8
  }),
  id: itemIdsData.item9,
  image: false,
  priority: 'high',
  title: 'Admission, Staff & Schedule management'
}, {
  assign: profileIdsData.profile2,
  attachments: [],
  commentIds: [commentIdsData.comment5],
  description: 'Content of item 10',
  dueDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_0__.add)(new Date(), {
    days: 12
  }),
  id: itemIdsData.item10,
  image: false,
  priority: 'low',
  title: 'Handling breaking changes'
}];
function handler(req, res) {
  return res.status(200).json({
    items: itemsData
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(41528));
module.exports = __webpack_exports__;

})();