"use strict";
(() => {
var exports = {};
exports.id = 3831;
exports.ids = [3831];
exports.modules = {

/***/ 23509:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function handler(req, res) {
  const {
    items,
    item,
    userStory,
    storyId,
    columns,
    columnId
  } = req.body;
  items.splice(items.findIndex(i => i.id === item.id), 1, item);
  let newUserStory = userStory;

  if (storyId) {
    const currentStory = userStory.filter(story => story.itemIds.filter(itemId => itemId === item.id)[0])[0];

    if (currentStory !== undefined && currentStory.id !== storyId) {
      newUserStory = userStory.map(story => {
        if (story.itemIds.filter(itemId => itemId === item.id)[0]) {
          return _objectSpread(_objectSpread({}, story), {}, {
            itemIds: story.itemIds.filter(itemId => itemId !== item.id)
          });
        }

        if (story.id === storyId) {
          return _objectSpread(_objectSpread({}, story), {}, {
            itemIds: story.itemIds ? [...story.itemIds, item.id] : [item.id]
          });
        }

        return story;
      });
    }

    if (currentStory === undefined) {
      newUserStory = userStory.map(story => {
        if (story.id === storyId) {
          return _objectSpread(_objectSpread({}, story), {}, {
            itemIds: story.itemIds ? [...story.itemIds, item.id] : [item.id]
          });
        }

        return story;
      });
    }
  }

  let newColumn = columns;

  if (columnId) {
    const currentColumn = columns.filter(column => column.itemIds.filter(itemId => itemId === item.id)[0])[0];

    if (currentColumn !== undefined && currentColumn.id !== columnId) {
      newColumn = columns.map(column => {
        if (column.itemIds.filter(itemId => itemId === item.id)[0]) {
          return _objectSpread(_objectSpread({}, column), {}, {
            itemIds: column.itemIds.filter(itemId => itemId !== item.id)
          });
        }

        if (column.id === columnId) {
          return _objectSpread(_objectSpread({}, column), {}, {
            itemIds: column.itemIds ? [...column.itemIds, item.id] : [item.id]
          });
        }

        return column;
      });
    }

    if (currentColumn === undefined) {
      newColumn = columns.map(column => {
        if (column.id === columnId) {
          return _objectSpread(_objectSpread({}, column), {}, {
            itemIds: column.itemIds ? [...column.itemIds, item.id] : [item.id]
          });
        }

        return column;
      });
    }
  }

  const result = {
    items,
    columns: newColumn,
    userStory: newUserStory
  };
  return res.status(200).json(_objectSpread({}, result));
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(23509));
module.exports = __webpack_exports__;

})();