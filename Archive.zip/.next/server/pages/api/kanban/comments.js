"use strict";
(() => {
var exports = {};
exports.id = 672;
exports.ids = [672];
exports.modules = {

/***/ 58466:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
const profileIdsData = {
  profile1: 'profile-1',
  profile2: 'profile-2',
  profile3: 'profile-3'
};
const commentIdsData = {
  comment1: 'comment-1',
  comment2: 'comment-2',
  comment3: 'comment-3',
  comment4: 'comment-4',
  comment5: 'comment-5'
};
const commentsData = [{
  id: commentIdsData.comment1,
  comment: 'Comment 1',
  profileId: profileIdsData.profile1
}, {
  id: commentIdsData.comment2,
  comment: 'Comment 2',
  profileId: profileIdsData.profile2
}, {
  id: commentIdsData.comment3,
  comment: 'Comment 3',
  profileId: profileIdsData.profile3
}, {
  id: commentIdsData.comment4,
  comment: 'Comment 4',
  profileId: profileIdsData.profile2
}, {
  id: commentIdsData.comment5,
  comment: 'Comment 5',
  profileId: profileIdsData.profile3
}];
function handler(req, res) {
  return res.status(200).json({
    comments: commentsData
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(58466));
module.exports = __webpack_exports__;

})();