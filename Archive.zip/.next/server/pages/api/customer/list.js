"use strict";
(() => {
var exports = {};
exports.id = 8264;
exports.ids = [8264];
exports.modules = {

/***/ 73676:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
const customers = [{
  name: 'Joseph William 1',
  email: 'Joseph@mail.com',
  location: 'Hong Kong, China',
  orders: 263,
  date: '12.07.2018',
  status: 1
}, {
  name: 'Ashy Handgun 2',
  email: 'Akshay@mail.com',
  location: 'New York, USA',
  orders: 750,
  date: '12.07.2018',
  status: 2
}, {
  name: 'Larry Doe 3',
  email: 'larry@mail.com',
  location: 'Hong Kong, China',
  orders: 1120,
  date: '12.07.2018',
  status: 2
}, {
  name: 'Sara Soudan 4',
  email: 'Sara@mail.com',
  location: 'New York, USA',
  orders: 975,
  date: '12.07.2018',
  status: 3
}, {
  name: 'Joseph William 5',
  email: 'Joseph@mail.com',
  location: 'Hong Kong, China',
  orders: 263,
  date: '12.07.2018',
  status: 1
}, {
  name: 'Aisha Handgun 6',
  email: 'Akshay@mail.com',
  location: 'New York, USA',
  orders: 750,
  date: '12.07.2018',
  status: 3
}, {
  name: 'Larky Doe 7',
  email: 'larry@mail.com',
  location: 'Hong Kong, China',
  orders: 1120,
  date: '12.07.2018',
  status: 2
}, {
  name: 'Sara Soupier 8',
  email: 'Sara@mail.com',
  location: 'New York, USA',
  orders: 975,
  date: '12.07.2018',
  status: 1
}, {
  name: 'Joseph William 9',
  email: 'Joseph@mail.com',
  location: 'Hong Kong, China',
  orders: 263,
  date: '12.07.2018',
  status: 3
}, {
  name: 'Anshan Handgun 10',
  email: 'Akshay@mail.com',
  location: 'New York, USA',
  orders: 750,
  date: '12.07.2018',
  status: 1
}, {
  name: 'Lardy Doe 11',
  email: 'larry@mail.com',
  location: 'Hong Kong, China',
  orders: 1120,
  date: '12.07.2018',
  status: 1
}, {
  name: 'Sara Soudan 12',
  email: 'Sara@mail.com',
  location: 'New York, USA',
  orders: 975,
  date: '12.07.2018',
  status: 3
}, {
  name: 'Joseph William 13',
  email: 'Joseph@mail.com',
  location: 'Hong Kong, China',
  orders: 263,
  date: '12.07.2018',
  status: 2
}, {
  name: 'Ashy Handgun 14',
  email: 'Akshay@mail.com',
  location: 'New York, USA',
  orders: 750,
  date: '12.07.2018',
  status: 2
}, {
  name: 'Lars Doe 15',
  email: 'larry@mail.com',
  location: 'Hong Kong, China',
  orders: 1120,
  date: '12.07.2018',
  status: 1
}, {
  name: 'Sara Souvenir 16',
  email: 'Sara@mail.com',
  location: 'New York, USA',
  orders: 975,
  date: '12.07.2018',
  status: 2
}];
function handler(req, res) {
  return res.status(200).json({
    customers
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(73676));
module.exports = __webpack_exports__;

})();