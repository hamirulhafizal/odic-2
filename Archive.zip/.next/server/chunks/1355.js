"use strict";
exports.id = 1355;
exports.ids = [1355];
exports.modules = {

/***/ 11355:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(95394);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(91588);
/* harmony import */ var hooks_useAuth__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(49684);
/* harmony import */ var hooks_useScriptRef__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(32953);
/* harmony import */ var store_slices_snackbar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(12686);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_5__]);
components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// material-ui


 // third party


 // project imports




 // ========================|| FIREBASE - FORGOT PASSWORD ||======================== //




const AuthForgotPassword = _ref => {
  let others = Object.assign({}, _ref);
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  const scriptedRef = (0,hooks_useScriptRef__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
  const dispatch = (0,store__WEBPACK_IMPORTED_MODULE_2__/* .useDispatch */ .I0)();
  const {
    resetPassword
  } = (0,hooks_useAuth__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(formik__WEBPACK_IMPORTED_MODULE_4__.Formik, {
    initialValues: {
      email: '',
      password: '',
      submit: null
    },
    validationSchema: yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
      email: yup__WEBPACK_IMPORTED_MODULE_3__.string().email('Must be a valid email').max(255).required('Email is required')
    }),
    onSubmit: async (values, {
      setErrors,
      setStatus,
      setSubmitting
    }) => {
      try {
        await resetPassword(values.email);

        if (scriptedRef.current) {
          setStatus({
            success: true
          });
          setSubmitting(false);
          dispatch((0,store_slices_snackbar__WEBPACK_IMPORTED_MODULE_8__/* .openSnackbar */ .ss)({
            open: true,
            message: 'Check mail for reset password link',
            variant: 'alert',
            alert: {
              color: 'success'
            },
            close: false
          }));
          setTimeout(() => {
            window.location.replace('/login');
          }, 1500);
        }
      } catch (err) {
        console.error(err);

        if (scriptedRef.current) {
          setStatus({
            success: false
          });
          setErrors({
            submit: err.message
          });
          setSubmitting(false);
        }
      }
    },
    children: ({
      errors,
      handleBlur,
      handleChange,
      handleSubmit,
      isSubmitting,
      touched,
      values
    }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("form", _objectSpread(_objectSpread({
      noValidate: true,
      onSubmit: handleSubmit
    }, others), {}, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
        fullWidth: true,
        error: Boolean(touched.email && errors.email),
        sx: _objectSpread({}, theme.typography.customInput),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, {
          htmlFor: "outlined-adornment-email-forgot",
          children: "Email Address / Username"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.OutlinedInput, {
          id: "outlined-adornment-email-forgot",
          type: "email",
          value: values.email,
          name: "email",
          onBlur: handleBlur,
          onChange: handleChange,
          label: "Email Address / Username",
          inputProps: {}
        }), touched.email && errors.email && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormHelperText, {
          error: true,
          id: "standard-weight-helper-text-email-forgot",
          children: errors.email
        })]
      }), errors.submit && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
          mt: 3
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormHelperText, {
          error: true,
          children: errors.submit
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
          mt: 2
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
            disableElevation: true,
            disabled: isSubmitting,
            fullWidth: true,
            size: "large",
            type: "submit",
            variant: "contained",
            color: "secondary",
            children: "Send Mail"
          })
        })
      })]
    }))
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthForgotPassword);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 32953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
 // ==============================|| ELEMENT REFERENCE HOOKS  ||============================== //

const useScriptRef = () => {
  const scripted = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(true);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => () => {
    scripted.current = false;
  }, []);
  return scripted;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useScriptRef);

/***/ })

};
;