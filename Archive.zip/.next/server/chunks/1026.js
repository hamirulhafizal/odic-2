"use strict";
exports.id = 1026;
exports.ids = [1026];
exports.modules = {

/***/ 82651:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(46517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95394);
/* harmony import */ var Link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(91931);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_ShoppingCartTwoTone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(98369);
/* harmony import */ var _mui_icons_material_ShoppingCartTwoTone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ShoppingCartTwoTone__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);


 // material-ui


 // assets



const StyledBadge = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Badge)(({
  theme
}) => ({
  '& .MuiBadge-badge': {
    right: 0,
    top: 3,
    border: `2px solid ${theme.palette.background.paper}`,
    padding: '0 4px'
  }
})); // ==============================|| CART ITEMS - FLOATING BUTTON ||============================== //

const FloatingCart = () => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
  const cart = (0,store__WEBPACK_IMPORTED_MODULE_1__/* .useSelector */ .v9)(state => state.cart);
  const totalQuantity = (0,lodash__WEBPACK_IMPORTED_MODULE_0__.sum)(cart.checkout.products.map(item => item.quantity));
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Fab, {
    component: Link__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
    href: "/app/e-commerce/checkout",
    size: "large",
    sx: {
      top: '50%',
      position: 'fixed',
      right: 0,
      zIndex: theme.zIndex.speedDial,
      boxShadow: theme.customShadows.warning,
      bgcolor: 'warning.main',
      color: 'warning.light',
      borderRadius: '8px',
      borderTopRightRadius: 0,
      borderBottomRightRadius: 0,
      '&:hover': {
        bgcolor: 'warning.dark',
        color: 'warning.light'
      }
    },
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
      disableRipple: true,
      "aria-label": "cart",
      sx: {
        '&:hover': {
          bgcolor: 'transparent'
        }
      },
      size: "large",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(StyledBadge, {
        showZero: true,
        badgeContent: totalQuantity,
        color: "error",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx((_mui_icons_material_ShoppingCartTwoTone__WEBPACK_IMPORTED_MODULE_5___default()), {
          sx: {
            color: 'grey.800'
          }
        })
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FloatingCart);

/***/ }),

/***/ 90411:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91931);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(95394);
/* harmony import */ var store_slices_cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(96504);
/* harmony import */ var _MainCard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(32107);
/* harmony import */ var components_ui_component_cards_Skeleton_ProductPlaceholder__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(31545);
/* harmony import */ var store_slices_snackbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(12686);
/* harmony import */ var _mui_icons_material_ShoppingCartTwoTone__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(98369);
/* harmony import */ var _mui_icons_material_ShoppingCartTwoTone__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ShoppingCartTwoTone__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);

 // material-ui

 // redux


 // project import



 // assets





const prodImage = '/assets/images/e-commerce'; // ==============================|| PRODUCT CARD ||============================== //

const ProductCard = ({
  id,
  color,
  name,
  image,
  description,
  offerPrice,
  salePrice,
  rating
}) => {
  const dispatch = (0,store__WEBPACK_IMPORTED_MODULE_3__/* .useDispatch */ .I0)();
  const prodProfile = image && `${prodImage}/${image}`;
  const {
    0: productRating
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(rating);
  const cart = (0,store__WEBPACK_IMPORTED_MODULE_3__/* .useSelector */ .v9)(state => state.cart);

  const addCart = () => {
    dispatch((0,store_slices_cart__WEBPACK_IMPORTED_MODULE_4__/* .addProduct */ .gK)({
      id,
      name,
      image,
      salePrice,
      offerPrice,
      color,
      size: 8,
      quantity: 1
    }, cart.checkout.products));
    dispatch((0,store_slices_snackbar__WEBPACK_IMPORTED_MODULE_7__/* .openSnackbar */ .ss)({
      open: true,
      message: 'Add To Cart Success',
      variant: 'alert',
      alert: {
        color: 'success'
      },
      close: false
    }));
  };

  const {
    0: isLoading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    setLoading(false);
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
    children: isLoading ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(components_ui_component_cards_Skeleton_ProductPlaceholder__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_MainCard__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      content: false,
      boxShadow: true,
      sx: {
        '&:hover': {
          transform: 'scale3d(1.02, 1.02, 1)',
          transition: 'all .4s ease-in-out'
        }
      },
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CardMedia, {
        sx: {
          height: 220
        },
        image: prodProfile,
        title: "Contemplative Reptile",
        component: Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
        href: `/app/e-commerce/product-details/${id}`
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CardContent, {
        sx: {
          p: 2
        },
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          container: true,
          spacing: 2,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
              component: Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
              href: `/app/e-commerce/product-details/${id}`,
              variant: "subtitle1",
              sx: {
                textDecoration: 'none'
              },
              children: name
            })
          }), description && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
              variant: "body2",
              sx: {
                overflow: 'hidden',
                height: 45
              },
              children: description
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            sx: {
              pt: '8px !important'
            },
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
              direction: "row",
              alignItems: "center",
              spacing: 1,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Rating, {
                precision: 0.5,
                name: "size-small",
                value: productRating,
                size: "small",
                readOnly: true
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "caption",
                children: ["(", offerPrice, "+)"]
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
              direction: "row",
              justifyContent: "space-between",
              alignItems: "center",
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                container: true,
                spacing: 1,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                  item: true,
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                    variant: "h4",
                    children: ["$", offerPrice]
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                  item: true,
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                    variant: "h6",
                    sx: {
                      color: 'grey.500',
                      textDecoration: 'line-through'
                    },
                    children: ["$", salePrice]
                  })
                })]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "contained",
                sx: {
                  minWidth: 0
                },
                onClick: addCart,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((_mui_icons_material_ShoppingCartTwoTone__WEBPACK_IMPORTED_MODULE_8___default()), {
                  fontSize: "small"
                })
              })]
            })
          })]
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductCard);

/***/ }),

/***/ 31545:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _MainCard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(32107);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
// material-ui
 // project import

 // ===========================|| SKELETON TOTAL GROWTH BAR CHART ||=========================== //




const ProductPlaceholder = () => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(_MainCard__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
  content: false,
  boxShadow: true,
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Skeleton, {
    variant: "rectangular",
    height: 220
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.CardContent, {
    sx: {
      p: 2
    },
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
      container: true,
      spacing: 2,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Skeleton, {
          variant: "rectangular",
          height: 20
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Skeleton, {
          variant: "rectangular",
          height: 45
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
        item: true,
        xs: 12,
        sx: {
          pt: '8px !important'
        },
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack, {
          direction: "row",
          alignItems: "center",
          spacing: 1,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Skeleton, {
            variant: "rectangular",
            height: 20,
            width: 90
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Skeleton, {
            variant: "rectangular",
            height: 20,
            width: 38
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack, {
          direction: "row",
          justifyContent: "space-between",
          alignItems: "center",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
            container: true,
            spacing: 1,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Skeleton, {
                variant: "rectangular",
                height: 20,
                width: 40
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Skeleton, {
                variant: "rectangular",
                height: 17,
                width: 20
              })
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Skeleton, {
            variant: "rectangular",
            height: 32,
            width: 47
          })]
        })
      })]
    })
  })]
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductPlaceholder);

/***/ })

};
;