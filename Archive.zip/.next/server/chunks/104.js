"use strict";
exports.id = 104;
exports.ids = [104];
exports.modules = {

/***/ 70104:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95394);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var Link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91931);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(91588);
/* harmony import */ var hooks_useAuth__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(49684);
/* harmony import */ var hooks_useScriptRef__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(32953);
/* harmony import */ var utils_password_strength__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(41577);
/* harmony import */ var store_slices_snackbar__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(12686);
/* harmony import */ var _mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(50773);
/* harmony import */ var _mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(77749);
/* harmony import */ var _mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_8__]);
components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




 // material-ui


 // third party


 // project imports





 // assets


 // ===========================|| FIREBASE - REGISTER ||=========================== //





const JWTRegister = _ref => {
  let others = Object.assign({}, _ref);
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__.useTheme)();
  const scriptedRef = (0,hooks_useScriptRef__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
  const dispatch = (0,store__WEBPACK_IMPORTED_MODULE_1__/* .useDispatch */ .I0)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const matchDownSM = (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.useMediaQuery)(theme.breakpoints.down('md'));
  const [showPassword, setShowPassword] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
  const [checked, setChecked] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(true);
  const [strength, setStrength] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(0);
  const [level, setLevel] = react__WEBPACK_IMPORTED_MODULE_0___default().useState();
  const {
    register
  } = (0,hooks_useAuth__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleMouseDownPassword = event => {
    event.preventDefault();
  };

  const changePassword = value => {
    const temp = (0,utils_password_strength__WEBPACK_IMPORTED_MODULE_15__/* .strengthIndicator */ .X)(value);
    setStrength(temp);
    setLevel((0,utils_password_strength__WEBPACK_IMPORTED_MODULE_15__/* .strengthColor */ .V)(temp));
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    changePassword('123456');
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
      container: true,
      direction: "column",
      justifyContent: "center",
      spacing: 2,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
        item: true,
        xs: 12,
        container: true,
        alignItems: "center",
        justifyContent: "center",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {
          sx: {
            mb: 2
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
            variant: "subtitle1",
            children: "Sign up with Email address"
          })
        })
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(formik__WEBPACK_IMPORTED_MODULE_7__.Formik, {
      initialValues: {
        email: '',
        password: '',
        firstName: '',
        lastName: '',
        submit: null
      },
      validationSchema: yup__WEBPACK_IMPORTED_MODULE_6__.object().shape({
        email: yup__WEBPACK_IMPORTED_MODULE_6__.string().email('Must be a valid email').max(255).required('Email is required'),
        password: yup__WEBPACK_IMPORTED_MODULE_6__.string().max(255).required('Password is required')
      }),
      onSubmit: async (values, {
        setErrors,
        setStatus,
        setSubmitting
      }) => {
        try {
          await register(values.email, values.password, values.firstName, values.lastName).then(res => {
            if (scriptedRef.current) {
              setStatus({
                success: true
              });
              setSubmitting(false);
              dispatch((0,store_slices_snackbar__WEBPACK_IMPORTED_MODULE_11__/* .openSnackbar */ .ss)({
                open: true,
                message: 'Your registration has been successfully completed.',
                variant: 'alert',
                alert: {
                  color: 'success'
                },
                close: false
              }));
              setTimeout(() => {
                router.push('/login');
              }, 1500);
            }
          });
        } catch (err) {
          if (scriptedRef.current === false) {
            setStatus({
              success: false
            });

            if (err.password[0] !== null) {
              setErrors({
                submit: 'try stronger password'
              });
            }

            if (err.email[0] !== null) {
              setErrors({
                submit: 'email must be unique'
              });
            }

            setSubmitting(false);
          }
        }
      },
      children: ({
        errors,
        status,
        handleBlur,
        handleChange,
        handleSubmit,
        isSubmitting,
        touched,
        values
      }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)("form", _objectSpread(_objectSpread({
        noValidate: true,
        onSubmit: handleSubmit
      }, others), {}, {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
          container: true,
          spacing: matchDownSM ? 0 : 2,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
            item: true,
            xs: 12,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.TextField, {
              fullWidth: true,
              label: "First Name",
              margin: "normal",
              name: "firstName",
              type: "text",
              value: values.firstName,
              onBlur: handleBlur,
              onChange: handleChange,
              sx: _objectSpread({}, theme.typography.customInput)
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
            item: true,
            xs: 12,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.TextField, {
              fullWidth: true,
              label: "Last Name",
              margin: "normal",
              name: "lastName",
              type: "text",
              value: values.lastName,
              onBlur: handleBlur,
              onChange: handleChange,
              sx: _objectSpread({}, theme.typography.customInput)
            })
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.FormControl, {
          fullWidth: true,
          error: Boolean(touched.email && errors.email),
          sx: _objectSpread({}, theme.typography.customInput),
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.InputLabel, {
            htmlFor: "outlined-adornment-email-register",
            children: "Email Address / Username"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.OutlinedInput, {
            id: "outlined-adornment-email-register",
            type: "email",
            value: values.email,
            name: "email",
            onBlur: handleBlur,
            onChange: handleChange,
            inputProps: {}
          }), touched.email && errors.email && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.FormHelperText, {
            error: true,
            id: "standard-weight-helper-text--register",
            children: errors.email
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.FormControl, {
          fullWidth: true,
          error: Boolean(touched.password && errors.password),
          sx: _objectSpread({}, theme.typography.customInput),
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.InputLabel, {
            htmlFor: "outlined-adornment-password-register",
            children: "Password"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.OutlinedInput, {
            id: "outlined-adornment-password-register",
            type: showPassword ? 'text' : 'password',
            value: values.password,
            name: "password",
            label: "Password",
            onBlur: handleBlur,
            onChange: e => {
              handleChange(e);
              changePassword(e.target.value);
            },
            endAdornment: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.InputAdornment, {
              position: "end",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.IconButton, {
                "aria-label": "toggle password visibility",
                onClick: handleClickShowPassword,
                onMouseDown: handleMouseDownPassword,
                edge: "end",
                size: "large",
                children: showPassword ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_12___default()), {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_13___default()), {})
              })
            }),
            inputProps: {}
          }), touched.password && errors.password && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.FormHelperText, {
            error: true,
            id: "standard-weight-helper-text-password-register",
            children: errors.password
          })]
        }), strength !== 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.FormControl, {
          fullWidth: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {
            sx: {
              mb: 2
            },
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
              container: true,
              spacing: 2,
              alignItems: "center",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
                item: true,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {
                  style: {
                    backgroundColor: level.color
                  },
                  sx: {
                    width: 85,
                    height: 8,
                    borderRadius: '7px'
                  }
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
                item: true,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                  variant: "subtitle1",
                  fontSize: "0.75rem",
                  children: level.label
                })
              })]
            })
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
          container: true,
          alignItems: "center",
          justifyContent: "space-between",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
            item: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.FormControlLabel, {
              control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Checkbox, {
                checked: checked,
                onChange: event => setChecked(event.target.checked),
                name: "checked",
                color: "primary"
              }),
              label: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                variant: "subtitle1",
                children: ["Agree with \xA0", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                  variant: "subtitle1",
                  component: Link__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                  href: "/",
                  children: "Terms & Condition."
                })]
              })
            })
          })
        }), errors.submit && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {
          sx: {
            mt: 3
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.FormHelperText, {
            error: true,
            children: errors.submit
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {
          sx: {
            mt: 2
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Button, {
              disableElevation: true,
              disabled: isSubmitting,
              fullWidth: true,
              size: "large",
              type: "submit",
              variant: "contained",
              color: "secondary",
              children: "Sign up"
            })
          })
        })]
      }))
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (JWTRegister);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;