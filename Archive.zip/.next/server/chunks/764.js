"use strict";
exports.id = 764;
exports.ids = [764];
exports.modules = {

/***/ 51562:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_intersection_observer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19785);
/* harmony import */ var react_intersection_observer__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_intersection_observer__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(66197);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
 // third party


 // =============================|| LANDING - FADE IN ANIMATION ||============================= //



function FadeInWhenVisible({
  children
}) {
  const controls = (0,framer_motion__WEBPACK_IMPORTED_MODULE_2__.useAnimation)();
  const [ref, inView] = (0,react_intersection_observer__WEBPACK_IMPORTED_MODULE_1__.useInView)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (inView) {
      controls.start('visible');
    }
  }, [controls, inView]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
    ref: ref,
    animate: controls,
    initial: "hidden",
    transition: {
      duration: 0.3
    },
    variants: {
      visible: {
        opacity: 1,
        translateY: 0
      },
      hidden: {
        opacity: 0,
        translateY: 275
      }
    },
    children: children
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FadeInWhenVisible);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 77132:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25675);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var Link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(91931);
/* harmony import */ var _Animation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(51562);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91588);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(49514);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Animation__WEBPACK_IMPORTED_MODULE_3__, components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_4__]);
([_Animation__WEBPACK_IMPORTED_MODULE_3__, components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
 // material-ui


 // project imports



 // ==============================|| LANDING - DEMOS PAGE ||============================== //




const DemosPage = () => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
    container: true,
    spacing: store_constant__WEBPACK_IMPORTED_MODULE_6__/* .gridSpacing */ .dv,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      item: true,
      xs: 12,
      lg: 5,
      md: 10,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        container: true,
        spacing: 2,
        sx: {
          mb: 2
        },
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            container: true,
            spacing: 1,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "h5",
                color: "primary",
                children: "Demos"
              })
            })
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
            variant: "h2",
            component: "div",
            children: "Pre-build Dashboard & Apps"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
            variant: "body2",
            children: "Berry has customized pages with Material-UI components, Apps, Forms and lots more to explore."
          })
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      item: true,
      xs: 12,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        container: true,
        justifyContent: "center",
        spacing: store_constant__WEBPACK_IMPORTED_MODULE_6__/* .gridSpacing */ .dv,
        sx: {
          textAlign: 'center'
        },
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          md: 4,
          sm: 6,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ButtonBase, {
              component: Link__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
              href: "/dashboard/",
              sx: {
                width: '100%',
                height: {
                  xs: '220px',
                  sm: '250px',
                  md: '300px'
                },
                position: 'relative'
              },
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__["default"], {
                src: "/assets/images/landing/img-demo-1.jpg",
                alt: "Berry Dashboard",
                layout: "fill",
                width: "100%",
                height: "100%"
              })
            })
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          md: 4,
          sm: 6,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ButtonBase, {
              sx: {
                width: '100%',
                height: {
                  xs: '220px',
                  sm: '250px',
                  md: '300px'
                },
                position: 'relative'
              },
              component: Link__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
              href: "/app/user/social-profile/posts",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__["default"], {
                src: "/assets/images/landing/img-demo-2.jpg",
                alt: "Berry Social App",
                width: "100%",
                height: "100%",
                layout: "fill"
              })
            })
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          md: 4,
          sm: 6,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ButtonBase, {
              component: Link__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
              href: "/dashboard/",
              sx: {
                width: '100%',
                height: {
                  xs: '220px',
                  sm: '250px',
                  md: '300px'
                },
                position: 'relative'
              },
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__["default"], {
                src: "/assets/images/landing/img-demo-3.jpg",
                alt: "Berry Mail App",
                layout: "fill",
                width: "100%",
                height: "100%"
              })
            })
          })
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      item: true,
      xs: 12,
      sx: {
        textAlign: 'center',
        mt: 3
      },
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
          component: Link__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
          href: "/forms/components/autocomplete",
          variant: "outlined",
          children: "Explore Components"
        })
      })
    })]
  })
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DemosPage);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9702:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Animation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(51562);
/* harmony import */ var components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(22278);
/* harmony import */ var components_ui_component_extended_Avatar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(74202);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(49514);
/* harmony import */ var _mui_icons_material_PaletteTwoTone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57505);
/* harmony import */ var _mui_icons_material_PaletteTwoTone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PaletteTwoTone__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_ReorderTwoTone__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6245);
/* harmony import */ var _mui_icons_material_ReorderTwoTone__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ReorderTwoTone__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_SpeedTwoTone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(24912);
/* harmony import */ var _mui_icons_material_SpeedTwoTone__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_SpeedTwoTone__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Animation__WEBPACK_IMPORTED_MODULE_2__]);
_Animation__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// material-ui

 // project imports




 // assets



 // =============================|| LANDING - FEATURE PAGE ||============================= //




const FeaturePage = () => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      container: true,
      spacing: store_constant__WEBPACK_IMPORTED_MODULE_9__/* .gridSpacing */ .dv,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        lg: 5,
        md: 10,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          container: true,
          spacing: 2,
          sx: {
            mb: 2
          },
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              container: true,
              spacing: 1,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  variant: "h5",
                  color: "primary",
                  children: "Top Features"
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
              variant: "h2",
              component: "div",
              children: "What Berry brings to you?"
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
              variant: "body2",
              children: "Berry is a solid dashboard template for your next project, with the following top features."
            })
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          container: true,
          justifyContent: "center",
          spacing: store_constant__WEBPACK_IMPORTED_MODULE_9__/* .gridSpacing */ .dv,
          sx: {
            textAlign: 'center'
          },
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            md: 4,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  justifyContent: "center",
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(components_ui_component_extended_Avatar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                      size: "xl",
                      variant: "rounded",
                      sx: {
                        background: theme.palette.mode === 'dark' ? theme.palette.dark[900] : theme.palette.primary.light,
                        color: theme.palette.primary.main
                      },
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx((_mui_icons_material_PaletteTwoTone__WEBPACK_IMPORTED_MODULE_5___default()), {
                        fontSize: "large"
                      })
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "h3",
                      children: "Beautiful User Interface"
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "body2",
                      children: "Warm color palates and minimally designed interfaces make the user experience more comfortable."
                    })
                  })]
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            md: 4,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  justifyContent: "center",
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(components_ui_component_extended_Avatar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                      size: "xl",
                      variant: "rounded",
                      sx: {
                        background: theme.palette.mode === 'dark' ? theme.palette.dark[900] : theme.palette.secondary.light,
                        color: theme.palette.secondary.main
                      },
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx((_mui_icons_material_ReorderTwoTone__WEBPACK_IMPORTED_MODULE_6___default()), {
                        fontSize: "large"
                      })
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "h3",
                      children: "Modern Technology Stack"
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "body2",
                      children: "Technology behind Berry is less complicated so you can focus on creating the actual web applications."
                    })
                  })]
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            md: 4,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  justifyContent: "center",
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(components_ui_component_extended_Avatar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                      size: "xl",
                      variant: "rounded",
                      sx: {
                        background: theme.palette.mode === 'dark' ? theme.palette.dark[900] : theme.palette.success.light,
                        color: theme.palette.success.dark
                      },
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx((_mui_icons_material_SpeedTwoTone__WEBPACK_IMPORTED_MODULE_7___default()), {
                        fontSize: "large"
                      })
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "h3",
                      children: "Performance Centric"
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "body2",
                      children: "Code that makes it easier and faster to render the page for your web applications."
                    })
                  })]
                })
              })
            })
          })]
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FeaturePage);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 94209:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(66197);
/* harmony import */ var Link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(91931);
/* harmony import */ var components_ui_component_extended_Avatar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(74202);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(91588);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(49514);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__, components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_5__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_2__, components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// material-ui

 // third party


 // project imports
// project imports



 // styles



const HeaderImage = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)('img')(({
  theme
}) => ({
  maxWidth: '100%',
  borderRadius: '20px',
  transform: 'scale(1.7)',
  transformOrigin: theme.direction === 'rtl' ? '100% 50%' : '0 50%',
  [theme.breakpoints.down('lg')]: {
    transform: 'scale(1.2)'
  }
}));
const HeaderAnimationImage = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)('img')({
  maxWidth: '100%',
  filter: 'drop-shadow(0px 0px 50px rgb(33 150 243 / 30%))'
}); // ==============================|| LANDING - HEADER PAGE ||============================== //

const HeaderPage = () => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      container: true,
      alignItems: "center",
      justifyContent: "space-between",
      spacing: store_constant__WEBPACK_IMPORTED_MODULE_7__/* .gridSpacing */ .dv,
      sx: {
        mt: {
          xs: 10,
          sm: 6,
          md: 18.75
        },
        mb: {
          xs: 2.5,
          md: 10
        }
      },
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        md: 5,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          container: true,
          spacing: store_constant__WEBPACK_IMPORTED_MODULE_7__/* .gridSpacing */ .dv,
          sx: {
            pr: 10,
            [theme.breakpoints.down('lg')]: {
              pr: 0,
              textAlign: 'center'
            }
          },
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
              initial: {
                opacity: 0,
                translateY: 550
              },
              animate: {
                opacity: 1,
                translateY: 0
              },
              transition: {
                type: 'spring',
                stiffness: 150,
                damping: 30
              },
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "h1",
                sx: {
                  fontSize: {
                    xs: '2.25rem',
                    sm: '3rem',
                    md: '4rem'
                  },
                  fontWeight: 900,
                  lineHeight: 1.4
                },
                children: ["One Dream Property", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                  component: "span",
                  sx: {
                    ml: 2,
                    color: theme.palette.primary.main
                  },
                  children: "Legacy"
                })]
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
              initial: {
                opacity: 0,
                translateY: 550
              },
              animate: {
                opacity: 1,
                translateY: 0
              },
              transition: {
                type: 'spring',
                stiffness: 150,
                damping: 30,
                delay: 0.2
              },
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "h4",
                component: "div",
                color: "inherit",
                sx: {
                  fontSize: {
                    xs: '1rem',
                    md: '1.125rem'
                  },
                  fontWeight: 400,
                  lineHeight: 1.4
                },
                children: "Berry is React based admin template which helps you to build faster and beautiful web applications."
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: 12,
            sx: {
              my: 3.25
            },
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
              initial: {
                opacity: 0,
                translateY: 550
              },
              animate: {
                opacity: 1,
                translateY: 0
              },
              transition: {
                type: 'spring',
                stiffness: 150,
                damping: 30,
                delay: 0.4
              },
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                container: true,
                spacing: 2,
                sx: {
                  justifyContent: {
                    xs: 'center',
                    md: 'flex-start'
                  }
                },
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  item: true,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                      component: Link__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                      href: "/dashboard/",
                      size: "large",
                      variant: "contained",
                      color: "secondary",
                      children: "Live Preview"
                    })
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  item: true,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                    component: Link__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                    href: "/login",
                    size: "large",
                    variant: "text",
                    children: "Login"
                  })
                })]
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
              initial: {
                opacity: 0,
                translateY: 550
              },
              animate: {
                opacity: 1,
                translateY: 0
              },
              transition: {
                type: 'spring',
                stiffness: 150,
                damping: 30,
                delay: 0.6
              },
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                container: true,
                alignItems: "center",
                spacing: 2,
                sx: {
                  [theme.breakpoints.down('lg')]: {
                    display: 'inline-flex',
                    width: 'auto'
                  }
                },
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  item: true,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(components_ui_component_extended_Avatar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    alt: "MUI Logo",
                    color: "primary",
                    sx: {
                      width: 50,
                      height: 50,
                      padding: 0.5,
                      background: theme.palette.mode === 'dark' ? theme.palette.dark.light : theme.palette.primary.light
                    },
                    variant: "rounded",
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("svg", {
                      width: "50",
                      height: "50",
                      viewBox: "0 0 500 500",
                      fill: "none",
                      xmlns: "http://www.w3.org/2000/svg",
                      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("g", {
                        clipPath: "url(#clip0)",
                        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("path", {
                          d: "M100 260.9V131L212.5 195.95V239.25L137.5 195.95V282.55L100 260.9Z",
                          fill: theme.palette.primary[800]
                        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("path", {
                          d: "M212.5 195.95L325 131V260.9L250 304.2L212.5 282.55L287.5 239.25V195.95L212.5 239.25V195.95Z",
                          fill: theme.palette.primary.main
                        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("path", {
                          d: "M212.5 282.55V325.85L287.5 369.15V325.85L212.5 282.55Z",
                          fill: theme.palette.primary[800]
                        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("path", {
                          d: "M287.5 369.15L400 304.2V217.6L362.5 239.25V282.55L287.5 325.85V369.15ZM362.5 195.95V152.65L400 131V174.3L362.5 195.95Z",
                          fill: theme.palette.primary.main
                        })]
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("defs", {
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("clipPath", {
                          id: "clip0",
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("rect", {
                            width: "300",
                            height: "238.3",
                            fill: "white",
                            transform: "translate(100 131)"
                          })
                        })
                      })]
                    })
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  item: true,
                  xs: true,
                  zeroMinWidth: true,
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                    variant: "h4",
                    component: "div",
                    color: "inherit",
                    sx: {
                      fontWeight: 400,
                      lineHeight: 1.4
                    },
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("b", {
                      children: "Built with Material-UI \xA9"
                    }), " - The most popular React Component Library."]
                  })
                })]
              })
            })
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        md: 7,
        sx: {
          display: {
            xs: 'none',
            md: 'flex'
          }
        },
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
          sx: {
            position: 'relative',
            mt: 8.75
          },
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(HeaderImage, {
            src: "/assets/images/landing/dashboard.png",
            alt: "Berry"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
            sx: {
              position: 'absolute',
              top: '-110px',
              right: theme.direction === 'rtl' ? '170px' : '-170px',
              width: '290px',
              animation: '10s slideY linear infinite'
            },
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
              initial: {
                opacity: 0,
                scale: 0
              },
              animate: {
                opacity: 1,
                scale: 1
              },
              transition: {
                type: 'spring',
                stiffness: 150,
                damping: 30,
                delay: 0.2
              },
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(HeaderAnimationImage, {
                src: "/assets/images/landing/widget-1.png",
                alt: "Berry"
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
            sx: {
              position: 'absolute',
              bottom: -90,
              left: 300,
              width: 280,
              animation: '10s slideY linear infinite',
              animationDelay: '2s'
            },
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
              initial: {
                opacity: 0,
                scale: 0
              },
              animate: {
                opacity: 1,
                scale: 1
              },
              transition: {
                type: 'spring',
                stiffness: 150,
                damping: 30,
                delay: 0.4
              },
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(HeaderAnimationImage, {
                src: "/assets/images/landing/widget-2.png",
                alt: "Berry"
              })
            })
          })]
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderPage);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 28020:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Animation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(51562);
/* harmony import */ var components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(22278);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91588);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(49514);
/* harmony import */ var _mui_icons_material_FolderTwoTone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(47862);
/* harmony import */ var _mui_icons_material_FolderTwoTone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FolderTwoTone__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_CodeTwoTone__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(68420);
/* harmony import */ var _mui_icons_material_CodeTwoTone__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CodeTwoTone__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_EmojiEmotionsTwoTone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7453);
/* harmony import */ var _mui_icons_material_EmojiEmotionsTwoTone__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_EmojiEmotionsTwoTone__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_LockOpenTwoTone__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57097);
/* harmony import */ var _mui_icons_material_LockOpenTwoTone__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LockOpenTwoTone__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_AttachmentTwoTone__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(98661);
/* harmony import */ var _mui_icons_material_AttachmentTwoTone__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AttachmentTwoTone__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_CallSplitTwoTone__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(95130);
/* harmony import */ var _mui_icons_material_CallSplitTwoTone__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CallSplitTwoTone__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_TextFields__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(33107);
/* harmony import */ var _mui_icons_material_TextFields__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_TextFields__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_DesignServices__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(151);
/* harmony import */ var _mui_icons_material_DesignServices__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_DesignServices__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Animation__WEBPACK_IMPORTED_MODULE_2__, components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_4__]);
([_Animation__WEBPACK_IMPORTED_MODULE_2__, components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// material-ui

 // project imports




 // assets








 // ============================|| LANDING - KEY FEATURE PAGE ||============================ //




const KeyFeaturePage = () => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();

  const avatarIconSx = _objectSpread(_objectSpread({}, theme.typography.commonAvatar), {}, {
    cursor: 'initial',
    width: 72,
    height: 72
  });

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      container: true,
      spacing: store_constant__WEBPACK_IMPORTED_MODULE_14__/* .gridSpacing */ .dv,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        lg: 5,
        md: 10,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          container: true,
          spacing: 2,
          sx: {
            mb: 2
          },
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              container: true,
              spacing: 1,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  variant: "h5",
                  color: "primary",
                  children: "Key Features"
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
              variant: "h2",
              component: "div",
              children: "Know more about Berry"
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
              variant: "body2",
              children: "If you're in need of a web app that is both user-friendly and scalable, this is the template for you."
            })
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          container: true,
          justifyContent: "center",
          spacing: store_constant__WEBPACK_IMPORTED_MODULE_14__/* .gridSpacing */ .dv,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            lg: 3,
            md: 4,
            xs: 12,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  alignItems: "center",
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                      variant: "rounded",
                      sx: _objectSpread(_objectSpread({}, avatarIconSx), {}, {
                        bgcolor: theme.palette.mode === 'dark' ? theme.palette.dark[800] : 'primary.light',
                        color: theme.palette.primary.main
                      }),
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_FolderTwoTone__WEBPACK_IMPORTED_MODULE_5___default()), {})
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: true,
                    zeroMinWidth: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "h5",
                      children: "Easy Folder Structure"
                    })
                  })]
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            lg: 3,
            md: 4,
            xs: 12,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  alignItems: "center",
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                      variant: "rounded",
                      sx: _objectSpread(_objectSpread({}, avatarIconSx), {}, {
                        bgcolor: theme.palette.mode === 'dark' ? theme.palette.dark[900] : 'secondary.light',
                        color: theme.palette.secondary.main
                      }),
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_CodeTwoTone__WEBPACK_IMPORTED_MODULE_6___default()), {})
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: true,
                    zeroMinWidth: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "h5",
                      children: "Organized Code Structure"
                    })
                  })]
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            lg: 3,
            md: 4,
            xs: 12,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  alignItems: "center",
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                      variant: "rounded",
                      sx: _objectSpread(_objectSpread({}, avatarIconSx), {}, {
                        bgcolor: theme.palette.mode === 'dark' ? theme.palette.dark[800] : 'primary.light',
                        color: theme.palette.primary.main
                      }),
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_EmojiEmotionsTwoTone__WEBPACK_IMPORTED_MODULE_7___default()), {})
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: true,
                    zeroMinWidth: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "h5",
                      children: "The Hassle-free Setup Process"
                    })
                  })]
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            lg: 3,
            md: 4,
            xs: 12,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  alignItems: "center",
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                      variant: "rounded",
                      sx: _objectSpread(_objectSpread({}, avatarIconSx), {}, {
                        bgcolor: theme.palette.mode === 'dark' ? theme.palette.dark[900] : 'secondary.light',
                        color: theme.palette.secondary.main
                      }),
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_LockOpenTwoTone__WEBPACK_IMPORTED_MODULE_8___default()), {})
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: true,
                    zeroMinWidth: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "h5",
                      children: "3 Auth Methods"
                    })
                  })]
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            lg: 3,
            md: 4,
            xs: 12,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  alignItems: "center",
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                      variant: "rounded",
                      sx: _objectSpread(_objectSpread({}, avatarIconSx), {}, {
                        bgcolor: theme.palette.mode === 'dark' ? theme.palette.dark[900] : 'secondary.light',
                        color: theme.palette.secondary.main
                      }),
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_AttachmentTwoTone__WEBPACK_IMPORTED_MODULE_9___default()), {})
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: true,
                    zeroMinWidth: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "h5",
                      children: "React Hooks"
                    })
                  })]
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            lg: 3,
            md: 4,
            xs: 12,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  alignItems: "center",
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                      variant: "rounded",
                      sx: _objectSpread(_objectSpread({}, avatarIconSx), {}, {
                        bgcolor: theme.palette.mode === 'dark' ? theme.palette.dark[800] : 'primary.light',
                        color: theme.palette.primary.main
                      }),
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_CallSplitTwoTone__WEBPACK_IMPORTED_MODULE_10___default()), {})
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: true,
                    zeroMinWidth: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "h5",
                      children: "Code Splitting"
                    })
                  })]
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            lg: 3,
            md: 4,
            xs: 12,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  alignItems: "center",
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                      variant: "rounded",
                      sx: _objectSpread(_objectSpread({}, avatarIconSx), {}, {
                        bgcolor: theme.palette.mode === 'dark' ? theme.palette.dark[900] : 'secondary.light',
                        color: theme.palette.secondary.main
                      }),
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_TextFields__WEBPACK_IMPORTED_MODULE_11___default()), {})
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: true,
                    zeroMinWidth: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "h5",
                      children: "Google Fonts"
                    })
                  })]
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            lg: 3,
            md: 4,
            xs: 12,
            sm: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_Animation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  alignItems: "center",
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                      variant: "rounded",
                      sx: _objectSpread(_objectSpread({}, avatarIconSx), {}, {
                        background: theme.palette.mode === 'dark' ? theme.palette.dark[800] : 'primary.light',
                        color: theme.palette.primary.main
                      }),
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_DesignServices__WEBPACK_IMPORTED_MODULE_12___default()), {})
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: true,
                    zeroMinWidth: true,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                      variant: "h5",
                      children: "Figma Design Files"
                    })
                  })]
                })
              })
            })
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        sx: {
          mt: 3
        },
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          container: true,
          justifyContent: "center",
          spacing: store_constant__WEBPACK_IMPORTED_MODULE_14__/* .gridSpacing */ .dv,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                component: _mui_material__WEBPACK_IMPORTED_MODULE_1__.Link,
                href: "https://material-ui.com/store/items/berry-react-material-admin/",
                target: "_blank",
                variant: "contained",
                children: "Get Berry"
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
              component: _mui_material__WEBPACK_IMPORTED_MODULE_1__.Link,
              href: "https://blog.berrydashboard.io",
              target: "_blank",
              variant: "text",
              children: "Know More"
            })
          })]
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (KeyFeaturePage);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 42309:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layouts)
});

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(25675);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(18442);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(65692);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(38096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/landingpage/Slider.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // material-ui


 // third party

 // assets
// styles



const LayoutImage = (0,styles_.styled)('img')({
  position: 'absolute',
  top: 0,
  left: 0,
  width: '100%',
  height: '100%',
  animation: '5s wings ease-in-out infinite'
});
const imgLayout1 = '/assets/images/landing/demo-dark.png';
const imgLayout2 = '/assets/images/landing/demo-rtl.png';
const imgLayout3 = '/assets/images/landing/demo-multi.png';
const imgLayoutGrid = '/assets/images/landing/img-lay-grid.png'; // =============================|| SLIDER ITEMS ||============================= //

const Item = ({
  item
}) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
  container: true,
  alignItems: "center",
  justifyContent: "center",
  spacing: 3,
  textAlign: "center",
  children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
    item: true,
    xs: 11,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      sx: {
        width: '100%',
        position: 'relative'
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
        src: item.bg,
        alt: "Berry",
        width: "100%",
        height: 100
      }), /*#__PURE__*/jsx_runtime_.jsx(LayoutImage, {
        src: item.image,
        alt: "Berry"
      })]
    })
  }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
    item: true,
    xs: 10,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
      container: true,
      direction: "column",
      alignItems: "center",
      spacing: 3,
      textAlign: "center",
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        sm: 12,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h4",
          component: "div",
          children: item.title
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        sm: 12,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "body2",
          children: item.content
        })
      })]
    })
  })]
});

// ==============================|| LANDING - SLIDER PAGE ||============================== //
const SliderPage = () => {
  const settings = {
    autoplay: true,
    arrows: false,
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };
  const items = [{
    bg: imgLayoutGrid,
    image: imgLayout1,
    title: 'Dark Layout',
    content: 'Modern, sleek and elegant dark color scheme that looks great in a dark variant.'
  }, {
    bg: imgLayoutGrid,
    image: imgLayout2,
    title: 'RTL',
    content: 'Fully Support Right-to-left (RTL) design variant.'
  }, {
    bg: imgLayoutGrid,
    image: imgLayout3,
    title: 'Multi-language Support',
    content: 'Support Multi-language. Added 4 pre-filled language.'
  }];
  return /*#__PURE__*/jsx_runtime_.jsx((external_react_slick_default()), _objectSpread(_objectSpread({}, settings), {}, {
    children: items.map((item, index) => /*#__PURE__*/jsx_runtime_.jsx(Item, {
      item: item
    }, index))
  }));
};

/* harmony default export */ const Slider = (SliderPage);
// EXTERNAL MODULE: ./src/store/constant.js
var constant = __webpack_require__(49514);
;// CONCATENATED MODULE: ./src/components/landingpage/Layouts.js
 // material-ui


 // project imports


 // assets



const Layouts_imgLayout1 = '/assets/images/landing/demo-dark.png';
const Layouts_imgLayout2 = '/assets/images/landing/demo-rtl.png';
const Layouts_imgLayout3 = '/assets/images/landing/demo-multi.png';
const Layouts_imgLayoutGrid = '/assets/images/landing/img-lay-grid.png';
const imgLayoutDarkGrid = '/assets/images/landing/img-bg-grid-dark.svg'; // styles

const LayoutImageWrapper = (0,styles_.styled)(material_.Box)(({
  theme
}) => ({
  width: '100%',
  position: 'relative',
  margin: '-70px 0px',
  [theme.breakpoints.down('lg')]: {
    margin: '-30px 0px'
  }
}));
const Layouts_LayoutImage = (0,styles_.styled)('img')({
  position: 'relative',
  top: 0,
  left: 0,
  width: '100%',
  height: '100%',
  animation: '5s wings ease-in-out infinite'
});
const LayoutContent = (0,styles_.styled)(material_.Grid)(({
  theme
}) => ({
  maxWidth: 400,
  position: 'relative',
  '&:after': {
    content: '""',
    position: 'absolute',
    background: theme.palette.mode === 'dark' ? theme.palette.dark.dark : '#FFFFFF',
    border: `6px solid${theme.palette.secondary.main}`,
    width: 25,
    height: 25,
    borderRadius: '50%',
    top: 13,
    left: -20
  },
  '&:before': {
    content: '""',
    position: 'absolute',
    background: theme.palette.mode === 'dark' ? theme.palette.dark.main : '#9E9E9E',
    width: 1,
    height: 390,
    top: 13,
    left: -8
  },
  [theme.breakpoints.down('md')]: {
    '&:before': {
      height: 290
    }
  },
  [theme.breakpoints.down('lg')]: {
    '&:after': {
      left: -12
    },
    '&:before': {
      left: 0,
      height: 290
    }
  }
}));
const LayoutRightContent = (0,styles_.styled)(material_.Grid)(({
  theme
}) => ({
  maxWidth: 400,
  textAlign: 'right',
  marginLeft: 'auto',
  position: 'relative',
  paddingRight: 24,
  '&:after': {
    content: '""',
    position: 'absolute',
    background: theme.palette.mode === 'dark' ? theme.palette.dark.dark : '#FFFFFF',
    border: `6px solid${theme.palette.secondary.main}`,
    width: 25,
    height: 25,
    borderRadius: '50%',
    top: 13,
    right: -12
  },
  '&:before': {
    content: '""',
    position: 'absolute',
    background: theme.palette.mode === 'dark' ? theme.palette.dark.main : '#9E9E9E',
    width: 1,
    height: 300,
    top: 13,
    right: -1
  },
  [theme.breakpoints.down('md')]: {
    '&:before': {
      height: '400%'
    }
  },
  [theme.breakpoints.down('lg')]: {
    '&:after': {
      right: -4
    },
    '&:before': {
      right: 7
    }
  },
  [theme.breakpoints.down('md')]: {
    '&:after': {
      right: 'auto',
      left: -12
    },
    '&:before': {
      right: 'auto',
      left: 0,
      height: 160
    }
  }
})); // =============================|| LANDING - LAYOUTS PAGE ||============================= //

const LayoutsPage = () => {
  const theme = (0,styles_.useTheme)();
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Container, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
      container: true,
      spacing: constant/* gridSpacing */.dv,
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        sx: {
          display: {
            xs: 'block',
            md: 'none'
          }
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(Slider, {})
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
          display: {
            xs: 'none',
            md: 'block'
          },
          m: '0 auto'
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            container: true,
            alignItems: "center",
            spacing: constant/* gridSpacing */.dv,
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
              item: true,
              sm: 6,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(LayoutImageWrapper, {
                children: [/*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                  src: theme.palette.mode === 'dark' ? imgLayoutDarkGrid : Layouts_imgLayoutGrid,
                  alt: "Berry Dashboard",
                  layout: "fill",
                  width: "100%",
                  height: "100%"
                }), /*#__PURE__*/jsx_runtime_.jsx(Layouts_LayoutImage, {
                  src: Layouts_imgLayout1,
                  alt: "Berry"
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
              item: true,
              sm: 6,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(LayoutContent, {
                container: true,
                spacing: 2,
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                  item: true,
                  sm: 12,
                  children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                    variant: "h4",
                    component: "div",
                    children: "Dark Layout"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                  item: true,
                  sm: 12,
                  children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                    variant: "body2",
                    children: "Modern, sleek and elegant dark color scheme that looks great in a dark variant."
                  })
                })]
              })
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            container: true,
            alignItems: "center",
            spacing: constant/* gridSpacing */.dv,
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
              item: true,
              sm: 6,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(LayoutRightContent, {
                container: true,
                spacing: 2,
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                  item: true,
                  sm: 12,
                  children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                    variant: "h4",
                    component: "div",
                    children: "RTL"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                  item: true,
                  sm: 12,
                  children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                    variant: "body2",
                    children: "Fully Support Right-to-left (RTL) design variant."
                  })
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
              item: true,
              sm: 6,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(LayoutImageWrapper, {
                children: [/*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                  src: theme.palette.mode === 'dark' ? imgLayoutDarkGrid : Layouts_imgLayoutGrid,
                  alt: "Berry Dashboard",
                  layout: "fill",
                  width: "100%",
                  height: "100%"
                }), /*#__PURE__*/jsx_runtime_.jsx(Layouts_LayoutImage, {
                  src: Layouts_imgLayout2,
                  alt: "Berry",
                  style: {
                    animationDelay: '1.5s'
                  }
                })]
              })
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            container: true,
            alignItems: "center",
            spacing: constant/* gridSpacing */.dv,
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
              item: true,
              sm: 6,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(LayoutImageWrapper, {
                children: [/*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                  src: theme.palette.mode === 'dark' ? imgLayoutDarkGrid : Layouts_imgLayoutGrid,
                  alt: "Berry Dashboard",
                  layout: "fill",
                  width: "100%",
                  height: "100%"
                }), /*#__PURE__*/jsx_runtime_.jsx(Layouts_LayoutImage, {
                  src: Layouts_imgLayout3,
                  alt: "Berry",
                  style: {
                    animationDelay: '3s'
                  }
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
              item: true,
              sm: 6,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(LayoutContent, {
                container: true,
                spacing: 2,
                sx: {
                  '&:before': {
                    background: theme.palette.mode === 'dark' ? theme.palette.dark[900] : '#fff !important'
                  }
                },
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                  item: true,
                  sm: 12,
                  children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                    variant: "h4",
                    component: "div",
                    children: "Multi-language Support"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                  item: true,
                  sm: 12,
                  children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                    variant: "body2",
                    children: "Support Multi-language. Added 4 pre-filled language."
                  })
                })]
              })
            })]
          })
        })]
      })]
    })
  });
};

/* harmony default export */ const Layouts = (LayoutsPage);

/***/ }),

/***/ 47156:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _maintenance_ComingSoon_ComingSoon1_MailerSubscriber__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(39678);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(49514);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_maintenance_ComingSoon_ComingSoon1_MailerSubscriber__WEBPACK_IMPORTED_MODULE_2__]);
_maintenance_ComingSoon_ComingSoon1_MailerSubscriber__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// material-ui

 // project imports


 // assets



const imgMail = '/assets/images/landing/img-groupmail.png'; // styles

const SubscribeWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({
  theme
}) => {
  const darkColorRTL = theme.palette.mode === 'dark' ? `linear-gradient(270deg, ${theme.palette.dark.main} 65%, ${theme.palette.dark.dark} 65%)` : `linear-gradient(270deg, ${theme.palette.primary.light} 65%, #fff 65%)`;
  const darkColor = theme.palette.mode === 'dark' ? `linear-gradient(90deg, ${theme.palette.dark.main} 65%, ${theme.palette.dark.dark} 65%)` : `linear-gradient(90deg, ${theme.palette.primary.light} 65%, #fff 65%)`;
  const darkColorRTL0 = theme.palette.mode === 'dark' ? `linear-gradient(0deg, ${theme.palette.dark.main} 65%, ${theme.palette.dark.dark} 65%)` : `linear-gradient(0deg, ${theme.palette.primary.light} 65%, #fff 65%)`;
  const darkColor0 = theme.palette.mode === 'dark' ? `linear-gradient(0deg, ${theme.palette.dark.main} 65%, ${theme.palette.dark.dark} 65%)` : `linear-gradient(0deg, ${theme.palette.primary.light} 65%, #fff 65%)`;
  return {
    padding: '100px 0',
    background: theme.direction === 'rtl' ? darkColorRTL : darkColor,
    [theme.breakpoints.down('lg')]: {
      padding: '50px 0',
      background: theme.direction === 'rtl' ? darkColorRTL0 : darkColor0
    }
  };
});
const SubscribeCard = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({
  theme
}) => ({
  background: theme.palette.mode === 'dark' ? theme.palette.dark.dark : '#FFFFFF',
  boxShadow: '0px 0px 50px rgba(33, 150, 243, 0.2)',
  borderRadius: '20px',
  padding: '100px 75px',
  [theme.breakpoints.down('md')]: {
    padding: '40px 25px'
  }
}));
const SubscribeImage = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)('img')({
  width: 330,
  animation: '5s wings ease-in-out infinite',
  maxWidth: '100%'
}); // ============================|| LANDING - SUBSCRIBE PAGE ||============================ //

const Subscribe = () => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(SubscribeWrapper, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        container: true,
        alignItems: "center",
        spacing: store_constant__WEBPACK_IMPORTED_MODULE_4__/* .gridSpacing */ .dv,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          md: 5,
          sx: {
            display: {
              xs: 'none',
              md: 'block'
            },
            textAlign: 'right',
            [theme.breakpoints.down('lg')]: {
              textAlign: 'center'
            }
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(SubscribeImage, {
            src: imgMail,
            alt: "Berry"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          md: 7,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(SubscribeCard, {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              container: true,
              spacing: store_constant__WEBPACK_IMPORTED_MODULE_4__/* .gridSpacing */ .dv,
              sx: {
                mb: '1rem'
              },
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                sm: 12,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  variant: "h1",
                  component: "div",
                  sx: {
                    [theme.breakpoints.down('md')]: {
                      fontSize: '1.125rem'
                    }
                  },
                  children: "Subscribe"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                sm: 12,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  variant: "body2",
                  children: "Subscribe for the latest news & updates of Berry admin template. We never send spam newsletters."
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                sm: 12,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_maintenance_ComingSoon_ComingSoon1_MailerSubscriber__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
              })]
            })
          })
        })]
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Subscribe);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 764:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_landingpage_Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(94209);
/* harmony import */ var components_landingpage_Feature__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9702);
/* harmony import */ var components_landingpage_Demos__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77132);
/* harmony import */ var components_landingpage_Layouts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(42309);
/* harmony import */ var components_landingpage_KeyFeature__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(28020);
/* harmony import */ var components_landingpage_Subscribe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(47156);
/* harmony import */ var components_landingpage_Footer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(20574);
/* harmony import */ var layout_Customization__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(91323);
/* harmony import */ var components_ui_component_extended_AppBar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(41222);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_landingpage_Header__WEBPACK_IMPORTED_MODULE_1__, components_landingpage_Feature__WEBPACK_IMPORTED_MODULE_2__, components_landingpage_Demos__WEBPACK_IMPORTED_MODULE_3__, components_landingpage_KeyFeature__WEBPACK_IMPORTED_MODULE_5__, components_landingpage_Subscribe__WEBPACK_IMPORTED_MODULE_6__, layout_Customization__WEBPACK_IMPORTED_MODULE_8__]);
([components_landingpage_Header__WEBPACK_IMPORTED_MODULE_1__, components_landingpage_Feature__WEBPACK_IMPORTED_MODULE_2__, components_landingpage_Demos__WEBPACK_IMPORTED_MODULE_3__, components_landingpage_KeyFeature__WEBPACK_IMPORTED_MODULE_5__, components_landingpage_Subscribe__WEBPACK_IMPORTED_MODULE_6__, layout_Customization__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// material-ui
 // project imports













const HeaderWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({
  theme
}) => ({
  paddingTop: 30,
  overflowX: 'hidden',
  overflowY: 'clip',
  [theme.breakpoints.down('md')]: {
    paddingTop: 42
  }
}));
const SecondWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({
  theme
}) => ({
  paddingTop: 160,
  [theme.breakpoints.down('md')]: {
    paddingTop: 60
  }
})); // =============================|| LANDING MAIN ||============================= //

const Landing = () => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.Fragment, {
  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(HeaderWrapper, {
    id: "home",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components_ui_component_extended_AppBar__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components_landingpage_Header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})]
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(SecondWrapper, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components_landingpage_Feature__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(SecondWrapper, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components_landingpage_Demos__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(SecondWrapper, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components_landingpage_Layouts__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(SecondWrapper, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components_landingpage_KeyFeature__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(SecondWrapper, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components_landingpage_Subscribe__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components_landingpage_Footer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(layout_Customization__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})]
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Landing);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;