"use strict";
exports.id = 132;
exports.ids = [132];
exports.modules = {

/***/ 63653:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "E": () => (/* binding */ ConfigContext),
  "i": () => (/* binding */ ConfigProvider)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: ./src/config.js
var config = __webpack_require__(7878);
;// CONCATENATED MODULE: ./src/hooks/useLocalStorage.js
 // ==============================|| CONFIG - LOCAL STORAGE ||============================== //

function useLocalStorage(key, defaultValue) {
  const {
    0: value,
    1: setValue
  } = (0,external_react_.useState)(() => {
    const storedValue = localStorage.getItem(key);
    return storedValue === null ? defaultValue : JSON.parse(storedValue);
  });
  (0,external_react_.useEffect)(() => {
    const listener = e => {
      if (e.storageArea === localStorage && e.key === key) {
        setValue(e.newValue ? JSON.parse(e.newValue) : e.newValue);
      }
    };

    window.addEventListener('storage', listener);
    return () => {
      window.removeEventListener('storage', listener);
    };
  }, [key, defaultValue]);

  const setValueInLocalStorage = newValue => {
    setValue(currentValue => {
      const result = typeof newValue === 'function' ? newValue(currentValue) : newValue;
      localStorage.setItem(key, JSON.stringify(result));
      return result;
    });
  };

  return [value, setValueInLocalStorage];
}
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/contexts/ConfigContext.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // project import


 // initial state



const initialState = _objectSpread(_objectSpread({}, config/* default */.ZP), {}, {
  container: false,
  onChangeMenuType: () => {},
  onChangePresetColor: () => {},
  onChangeLocale: () => {},
  onChangeRTL: () => {},
  onChangeContainer: () => {},
  onChangeFontFamily: () => {},
  onChangeBorderRadius: () => {},
  onChangeOutlinedField: () => {}
}); // ==============================|| CONFIG CONTEXT & PROVIDER ||============================== //


const ConfigContext = /*#__PURE__*/(0,external_react_.createContext)(initialState);

function ConfigProvider({
  children
}) {
  const [config, setConfig] = useLocalStorage('berry-next-js-config', {
    fontFamily: initialState.fontFamily,
    borderRadius: initialState.borderRadius,
    outlinedFilled: initialState.outlinedFilled,
    navType: initialState.navType,
    presetColor: initialState.presetColor,
    locale: initialState.locale,
    rtlLayout: initialState.rtlLayout
  });

  const onChangeMenuType = navType => {
    setConfig(_objectSpread(_objectSpread({}, config), {}, {
      navType
    }));
  };

  const onChangePresetColor = presetColor => {
    setConfig(_objectSpread(_objectSpread({}, config), {}, {
      presetColor
    }));
  };

  const onChangeLocale = locale => {
    setConfig(_objectSpread(_objectSpread({}, config), {}, {
      locale
    }));
  };

  const onChangeRTL = rtlLayout => {
    setConfig(_objectSpread(_objectSpread({}, config), {}, {
      rtlLayout
    }));
  };

  const onChangeContainer = () => {
    setConfig(_objectSpread(_objectSpread({}, config), {}, {
      container: !config.container
    }));
  };

  const onChangeFontFamily = fontFamily => {
    setConfig(_objectSpread(_objectSpread({}, config), {}, {
      fontFamily
    }));
  };

  const onChangeBorderRadius = (event, newValue) => {
    setConfig(_objectSpread(_objectSpread({}, config), {}, {
      borderRadius: newValue
    }));
  };

  const onChangeOutlinedField = outlinedFilled => {
    setConfig(_objectSpread(_objectSpread({}, config), {}, {
      outlinedFilled
    }));
  };

  return /*#__PURE__*/jsx_runtime_.jsx(ConfigContext.Provider, {
    value: _objectSpread(_objectSpread({}, config), {}, {
      onChangeMenuType,
      onChangePresetColor,
      onChangeLocale,
      onChangeRTL,
      onChangeContainer,
      onChangeFontFamily,
      onChangeBorderRadius,
      onChangeOutlinedField
    }),
    children: children
  });
}



/***/ }),

/***/ 20132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var contexts_ConfigContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63653);

 // ==============================|| CONFIG - HOOKS  ||============================== //

const useConfig = () => (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(contexts_ConfigContext__WEBPACK_IMPORTED_MODULE_1__/* .ConfigContext */ .E);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useConfig);

/***/ })

};
;