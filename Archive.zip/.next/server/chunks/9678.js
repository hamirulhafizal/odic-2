"use strict";
exports.id = 9678;
exports.ids = [9678];
exports.modules = {

/***/ 39678:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95394);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(91588);
/* harmony import */ var hooks_useScriptRef__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(32953);
/* harmony import */ var store_slices_snackbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(12686);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(49514);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_5__]);
components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// material-ui
 // third party




 // project imports




 // ===========================|| MAILER SUBSCRIBER ||=========================== //




const MailerSubscriber = _ref => {
  let others = Object.assign({}, _ref);
  const scriptedRef = (0,hooks_useScriptRef__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
  const dispatch = (0,store__WEBPACK_IMPORTED_MODULE_1__/* .useDispatch */ .I0)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Formik, {
    initialValues: {
      email: '',
      submit: null
    },
    validationSchema: yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
      email: yup__WEBPACK_IMPORTED_MODULE_3__.string().email('Must be a valid email').max(255).required('Email is required')
    }),
    onSubmit: async (values, {
      setErrors,
      setStatus,
      setSubmitting
    }) => {
      try {
        const options = {
          headers: {
            'content-type': 'application/json'
          }
        };
        await axios__WEBPACK_IMPORTED_MODULE_4___default().post('https://yourapicall', {
          email: values.email
        }, options);
        dispatch((0,store_slices_snackbar__WEBPACK_IMPORTED_MODULE_7__/* .openSnackbar */ .ss)({
          open: true,
          message: 'Success! Please check inbox and confirm.',
          variant: 'alert',
          alert: {
            color: 'success'
          },
          close: false
        }));

        if (scriptedRef.current) {
          setStatus({
            success: true
          });
          setSubmitting(false);
        }
      } catch (err) {
        if (scriptedRef.current) {
          setStatus({
            success: false
          });
          setErrors({
            submit: err.message
          });
          setSubmitting(false);
        }
      }
    },
    children: ({
      errors,
      handleBlur,
      handleChange,
      handleSubmit,
      isSubmitting,
      touched,
      values
    }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("form", _objectSpread(_objectSpread({
      noValidate: true,
      onSubmit: handleSubmit
    }, others), {}, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
        container: true,
        alignItems: "center",
        spacing: store_constant__WEBPACK_IMPORTED_MODULE_9__/* .gridSpacing */ .dv,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          item: true,
          xs: true,
          zeroMinWidth: true,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.FormControl, {
            fullWidth: true,
            error: Boolean(touched.email && errors.email),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.InputLabel, {
              htmlFor: "outlined-adornment-email-forgot",
              children: "Email Address"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.OutlinedInput, {
              id: "outlined-adornment-email-forgot",
              type: "email",
              defaultValue: values.email,
              name: "email",
              onBlur: handleBlur,
              onChange: handleChange,
              label: "Email Address"
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          item: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button, {
              disableElevation: true,
              disabled: isSubmitting,
              type: "submit",
              variant: "contained",
              size: "large",
              sx: {
                px: 2.75,
                py: 1.5
              },
              children: "Subscribe"
            })
          })
        })]
      }), touched.email && errors.email && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box, {
        sx: {
          mt: 1
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.FormHelperText, {
          error: true,
          id: "standard-weight-helper-text-email-forgot",
          children: errors.email
        })
      }), errors.submit && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box, {
        sx: {
          mt: 3
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.FormHelperText, {
          error: true,
          children: errors.submit
        })
      })]
    }))
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MailerSubscriber);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 32953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
 // ==============================|| ELEMENT REFERENCE HOOKS  ||============================== //

const useScriptRef = () => {
  const scripted = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(true);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => () => {
    scripted.current = false;
  }, []);
  return scripted;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useScriptRef);

/***/ })

};
;