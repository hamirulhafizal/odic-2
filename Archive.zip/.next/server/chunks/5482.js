"use strict";
exports.id = 5482;
exports.ids = [5482];
exports.modules = {

/***/ 5482:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7878);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25675);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
// material-ui



/**
 * if you want to use image instead of <svg> uncomment following.
 *
 * import logoDark from 'assets/images/logo-dark.svg';
 * import logo from 'assets/images/logo.svg';
 *
 */
// ==============================|| LOGO SVG ||============================== //




const Logo = () => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  return (
    /*#__PURE__*/

    /**
     * if you want to use image instead of svg uncomment following, and comment out <svg> element.
     *
     *
     * <Image src={`${BASE_PATH}/assets/images/oneDream.png`} alt="Berry" width="100" />
     *
     */
    (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("svg", {
      width: "63",
      height: "37",
      viewBox: "0 0 63 37",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
        d: "M60.5435 8.90731C58.9093 6.10558 56.6132 3.92143 53.6555 2.35486C50.7028 0.783281 47.344 0 43.5791 0H33.613H19.2354C22.8147 0 26.0733 0.803365 29.0059 2.4101C31.2017 3.61012 33.0465 5.15158 34.5404 7.02945H41.5087H43.4237C45.5342 7.02945 47.4242 7.51649 49.0986 8.48053C50.7679 9.44959 52.0864 10.8153 53.0589 12.5777C54.0265 14.3401 54.5077 16.3284 54.5077 18.5527C54.5077 20.772 54.0515 22.7453 53.1341 24.4725C52.2167 26.1998 50.9434 27.5454 49.3091 28.5145C47.6748 29.4835 45.835 29.9655 43.7947 29.9655H43.4337C42.2356 29.9655 41.1227 30.5379 40.3757 31.4718C40.3707 31.4769 40.3657 31.4819 40.3657 31.4869C38.6813 33.5957 36.5908 35.3481 34.1594 36.6937C33.9639 36.7992 33.7684 36.8946 33.5729 36.995H43.2633C47.0983 36.995 50.5123 36.2117 53.5001 34.6451C56.4879 33.0786 58.819 30.8944 60.4934 28.0927C62.1628 25.2909 63 22.0925 63 18.4975C63 14.9024 62.1828 11.7091 60.5435 8.90731Z",
        fill: "#B2A433"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
        d: "M35.9441 9.04288C35.518 8.33492 35.0518 7.6621 34.5505 7.02945C33.0516 5.15158 31.2067 3.61012 29.016 2.4101C26.0783 0.803365 22.8198 0 19.2354 0C15.6209 0 12.3524 0.803365 9.43972 2.4101C6.52208 4.01683 4.22105 6.22608 2.53163 9.04288C0.842206 11.8647 0 14.9978 0 18.4473C0 21.9319 0.842206 25.0851 2.53163 27.9019C4.22105 30.7187 6.53211 32.943 9.46479 34.5648C12.3975 36.1866 15.656 37 19.2354 37C22.8148 37 26.0733 36.1866 29.006 34.5648C31.1767 33.3648 33.0014 31.8334 34.4903 29.9705C35.0167 29.3128 35.498 28.6199 35.9391 27.8768C37.6286 25.0399 38.4708 21.8967 38.4708 18.4473C38.4758 14.9978 37.6336 11.8647 35.9441 9.04288ZM24.7899 28.414C23.1356 29.4233 21.3208 29.9254 19.3407 29.9254C19.3056 29.9254 19.2755 29.9203 19.2454 29.9203C18.0372 29.9003 16.8291 29.7697 15.7061 29.3178C13.1194 28.2734 11.1542 26.5763 9.80067 24.2365C8.79303 22.4942 8.29172 20.5662 8.29172 18.4473C8.29172 16.3636 8.78802 14.4505 9.7756 12.7082C10.7632 10.9659 12.1117 9.59017 13.8162 8.58095C15.4906 7.5918 17.3003 7.0897 19.2404 7.07464C19.2755 7.07464 19.3106 7.06962 19.3407 7.06962C21.3208 7.06962 23.1356 7.57172 24.7899 8.58095C25.8627 9.23368 26.7902 10.0471 27.5772 11.0111C28.0033 11.5333 28.3894 12.0957 28.7302 12.7082C29.7028 14.4505 30.1891 16.3636 30.1891 18.4473C30.1891 20.5662 29.7028 22.5043 28.7302 24.2616C28.3894 24.8792 28.0033 25.4466 27.5772 25.9738C26.7902 26.9479 25.8627 27.7613 24.7899 28.414Z",
        fill: "#B5A837"
      })]
    })
  );
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Logo);

/***/ })

};
;