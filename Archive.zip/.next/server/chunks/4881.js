"use strict";
exports.id = 4881;
exports.ids = [4881];
exports.modules = {

/***/ 26708:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
// material-ui
 // ==============================|| AUTHENTICATION 1 WRAPPER ||============================== //

const AuthWrapper2 = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({
  theme
}) => ({
  backgroundColor: theme.palette.mode === 'dark' ? theme.palette.background.default : theme.palette.background.paper,
  minHeight: '100vh',
  [theme.breakpoints.down('lg')]: {
    backgroundColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.primary.light
  }
}));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthWrapper2);

/***/ }),

/***/ 59248:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
// material-ui
 // ==============================|| FOOTER - AUTHENTICATION 2 & 3 ||============================== //




const AuthFooter = () => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack, {
  direction: "row",
  justifyContent: "space-between",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
    variant: "subtitle2",
    component: _mui_material__WEBPACK_IMPORTED_MODULE_0__.Link,
    href: "https://berrydashboard.io",
    target: "_blank",
    underline: "hover",
    children: "berrydashboard.io"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
    variant: "subtitle2",
    component: _mui_material__WEBPACK_IMPORTED_MODULE_0__.Link,
    href: "https://codedthemes.com",
    target: "_blank",
    underline: "hover",
    children: "\xA9 codedthemes.com"
  })]
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthFooter);

/***/ }),

/***/ 76843:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
// material-ui

 // assets


const AuthPattern = '/assets/images/auth/img-a2-grid.svg';
const AuthPatternDark = '/assets/images/auth/img-a2-grid-dark.svg'; // ===========================|| BACKGROUND GRID PATTERN 2 ||=========================== //

const BackgroundPattern2 = ({
  children
}) => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
    component: "span",
    sx: {
      display: 'flex',
      minHeight: '100%',
      height: '100vh',
      bgcolor: theme.palette.mode === 'dark' ? theme.palette.dark.dark : '#fff',
      backgroundImage: theme.palette.mode === 'dark' ? `url(${AuthPatternDark})` : `url(${AuthPattern})`,
      position: 'absolute',
      backgroundPosition: 'bottom left',
      backgroundRepeat: 'no-repeat',
      // backgroundSize: 'cover',
      overflow: 'hidden',
      m: '0 0 0 auto',
      p: '100px 0',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      '& > *': {
        position: 'relative',
        zIndex: 5
      },
      '&:after': {
        content: '""',
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1,
        bottom: 0,
        bgcolor: theme.palette.mode === 'dark' ? theme.palette.dark.dark : theme.palette.primary.light,
        opacity: theme.palette.mode === 'dark' ? 0.85 : 0.9
      }
    },
    children: children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BackgroundPattern2);

/***/ })

};
;