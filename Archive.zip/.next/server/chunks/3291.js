"use strict";
exports.id = 3291;
exports.ids = [3291];
exports.modules = {

/***/ 33291:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91931);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(91588);
/* harmony import */ var hooks_useAuth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(49684);
/* harmony import */ var hooks_useScriptRef__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(32953);
/* harmony import */ var _mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(50773);
/* harmony import */ var _mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(77749);
/* harmony import */ var _mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__]);
components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
const _excluded = ["loginProp"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


 // material-ui


 // next

 // third party


 // project imports



 // assets


 // ===============================|| JWT LOGIN ||=============================== //




const JWTLogin = _ref => {
  let {
    loginProp
  } = _ref,
      others = _objectWithoutProperties(_ref, _excluded);

  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
  const scriptedRef = (0,hooks_useScriptRef__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
  const {
    login
  } = (0,hooks_useAuth__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
  const [checked, setChecked] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(true);
  const [showPassword, setShowPassword] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
  const [isLoading, setLoading] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleMouseDownPassword = event => {
    event.preventDefault();
  };

  console.log('isLoading', isLoading);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(formik__WEBPACK_IMPORTED_MODULE_6__.Formik, {
    initialValues: {
      email: 'agent06@agent.com',
      password: 'qwer1234',
      submit: null
    },
    validationSchema: yup__WEBPACK_IMPORTED_MODULE_5__.object().shape({
      email: yup__WEBPACK_IMPORTED_MODULE_5__.string().email('Must be a valid email').max(255).required('Email is required'),
      password: yup__WEBPACK_IMPORTED_MODULE_5__.string().max(255).required('Password is required')
    }),
    onSubmit: async (values, {
      setErrors,
      setStatus,
      setSubmitting
    }) => {
      setLoading(true);

      try {
        await login(values.email, values.password).then(res => {
          if (scriptedRef.current) {
            setLoading(false);
            setStatus({
              success: true,
              msg: 'success'
            });
            setSubmitting(false);
          }

          router.push(`/dashboard`);
        }).catch(err => {
          console.log('err', err);
          setLoading(false);
        });
      } catch (err) {
        console.error(err);

        if (scriptedRef.current) {
          setStatus({
            success: false,
            msg: 'fail'
          });
          setErrors({
            submit: err.message
          });
          setSubmitting(false);
          setLoading(false);
        }
      }
    },
    children: ({
      errors,
      status,
      handleBlur,
      handleChange,
      handleSubmit,
      isSubmitting,
      touched,
      values
    }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("form", _objectSpread(_objectSpread({
      noValidate: true,
      onSubmit: handleSubmit
    }, others), {}, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.FormControl, {
        fullWidth: true,
        error: Boolean(touched.email && errors.email),
        sx: _objectSpread({}, theme.typography.customInput),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.InputLabel, {
          htmlFor: "outlined-adornment-email-login",
          children: "Email"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.OutlinedInput, {
          id: "outlined-adornment-email-login",
          type: "email",
          value: values.email,
          name: "email",
          onBlur: handleBlur,
          onChange: handleChange,
          inputProps: {},
          label: "Email"
        }), touched.email && errors.email && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.FormHelperText, {
          error: true,
          id: "standard-weight-helper-text-email-login",
          children: errors.email
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.FormControl, {
        fullWidth: true,
        error: Boolean(touched.password && errors.password),
        sx: _objectSpread({}, theme.typography.customInput),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.InputLabel, {
          htmlFor: "outlined-adornment-password-login",
          children: "Password"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.OutlinedInput, {
          id: "outlined-adornment-password-login",
          type: showPassword ? 'text' : 'password',
          value: values.password,
          name: "password",
          onBlur: handleBlur,
          onChange: handleChange,
          endAdornment: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.InputAdornment, {
            position: "end",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
              "aria-label": "toggle password visibility",
              onClick: handleClickShowPassword,
              onMouseDown: handleMouseDownPassword,
              edge: "end",
              size: "large",
              children: showPassword ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_10___default()), {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_11___default()), {})
            })
          }),
          inputProps: {},
          label: "Password"
        }), touched.password && errors.password && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.FormHelperText, {
          error: true,
          id: "standard-weight-helper-text-password-login",
          children: errors.password
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
        container: true,
        alignItems: "center",
        justifyContent: "space-between",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
          item: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.FormControlLabel, {
            control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Checkbox, {
              checked: checked,
              onChange: event => setChecked(event.target.checked),
              name: "checked",
              color: "primary"
            }),
            label: "Keep me logged in"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
          item: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
            variant: "subtitle1",
            component: Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
            href: loginProp ? `/pages/authentication/auth${loginProp}/forgot-password` : '/pages/authentication/auth3/forgot-password',
            color: "secondary",
            sx: {
              textDecoration: 'none'
            },
            children: "Forgot Password?"
          })
        })]
      }), errors.submit && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
        sx: {
          mt: 3
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.FormHelperText, {
          error: true,
          children: errors.submit
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
        sx: {
          mt: 2
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
            color: `${status !== null && status !== void 0 && status.success ? 'success' : 'secondary'}`,
            disabled: isSubmitting,
            fullWidth: true,
            size: "large",
            type: "submit",
            variant: "contained",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.FormHelperText, {
              id: "standard-weight-helper-text-username-login",
              children: status && status.success ? `${status.msg}` : isLoading ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.CircularProgress, {
                size: 20
              }) : 'Sign In'
            })
          })
        })
      })]
    }))
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (JWTLogin);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 32953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
 // ==============================|| ELEMENT REFERENCE HOOKS  ||============================== //

const useScriptRef = () => {
  const scripted = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(true);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => () => {
    scripted.current = false;
  }, []);
  return scripted;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useScriptRef);

/***/ })

};
;