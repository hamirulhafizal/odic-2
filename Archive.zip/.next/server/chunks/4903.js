"use strict";
exports.id = 4903;
exports.ids = [4903];
exports.modules = {

/***/ 32953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
 // ==============================|| ELEMENT REFERENCE HOOKS  ||============================== //

const useScriptRef = () => {
  const scripted = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(true);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => () => {
    scripted.current = false;
  }, []);
  return scripted;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useScriptRef);

/***/ }),

/***/ 41577:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ strengthColor),
/* harmony export */   "X": () => (/* binding */ strengthIndicator)
/* harmony export */ });
/* harmony import */ var _scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70045);
/* harmony import */ var _scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_0__);
 // has number

const hasNumber = number => new RegExp(/[0-9]/).test(number); // has mix of small and capitals


const hasMixed = number => new RegExp(/[a-z]/).test(number) && new RegExp(/[A-Z]/).test(number); // has special chars


const hasSpecial = number => new RegExp(/[!#@$%^&*)(+=._-]/).test(number); // set color based on password strength


const strengthColor = count => {
  if (count < 2) return {
    label: 'Poor',
    color: (_scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_0___default().errorMain)
  };
  if (count < 3) return {
    label: 'Weak',
    color: (_scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_0___default().warningDark)
  };
  if (count < 4) return {
    label: 'Normal',
    color: (_scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_0___default().orangeMain)
  };
  if (count < 5) return {
    label: 'Good',
    color: (_scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_0___default().successMain)
  };
  if (count < 6) return {
    label: 'Strong',
    color: (_scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_0___default().successDark)
  };
  return {
    label: 'Poor',
    color: (_scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_0___default().errorMain)
  };
}; // password strength indicator

const strengthIndicator = number => {
  let strengths = 0;
  if (number.length > 5) strengths += 1;
  if (number.length > 7) strengths += 1;
  if (hasNumber(number)) strengths += 1;
  if (hasSpecial(number)) strengths += 1;
  if (hasMixed(number)) strengths += 1;
  return strengths;
};

/***/ })

};
;