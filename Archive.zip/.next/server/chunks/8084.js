"use strict";
exports.id = 8084;
exports.ids = [8084];
exports.modules = {

/***/ 28084:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var hooks_useScriptRef__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(32953);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(91588);
/* harmony import */ var utils_password_strength__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(41577);
/* harmony import */ var _mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(50773);
/* harmony import */ var _mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(77749);
/* harmony import */ var _mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_6__]);
components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // material-ui


 // third party


 // project imports
// import useAuth from 'hooks/useAuth';



 // assets


 // ========================|| FIREBASE - RESET PASSWORD ||======================== //




const AuthResetPassword = _ref => {
  let others = Object.assign({}, _ref);
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
  const scriptedRef = (0,hooks_useScriptRef__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
  const [showPassword, setShowPassword] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
  const [strength, setStrength] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(0);
  const [level, setLevel] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(); // const { firebaseEmailPasswordSignIn } = useAuth();

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleMouseDownPassword = event => {
    event.preventDefault();
  };

  const changePassword = value => {
    const temp = (0,utils_password_strength__WEBPACK_IMPORTED_MODULE_10__/* .strengthIndicator */ .X)(value);
    setStrength(temp);
    setLevel((0,utils_password_strength__WEBPACK_IMPORTED_MODULE_10__/* .strengthColor */ .V)(temp));
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    changePassword('123456');
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(formik__WEBPACK_IMPORTED_MODULE_4__.Formik, {
    initialValues: {
      email: 'info@codedthemes.com',
      password: '123456',
      confirmPassword: '123456',
      submit: null
    },
    validationSchema: yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
      password: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(255).required('Password is required'),
      confirmPassword: yup__WEBPACK_IMPORTED_MODULE_3__.string().when('password', {
        is: val => !!(val && val.length > 0),
        then: yup__WEBPACK_IMPORTED_MODULE_3__.string().oneOf([yup__WEBPACK_IMPORTED_MODULE_3__.ref('password')], 'Both Password must be match!')
      })
    }),
    onSubmit: async (values, {
      setErrors,
      setStatus,
      setSubmitting
    }) => {
      try {
        // await firebaseEmailPasswordSignIn(values.email, values.password);
        if (scriptedRef.current) {
          setStatus({
            success: true
          });
          setSubmitting(false);
        }
      } catch (err) {
        console.error(err);

        if (scriptedRef.current) {
          setStatus({
            success: false
          });
          setErrors({
            submit: err.message
          });
          setSubmitting(false);
        }
      }
    },
    children: ({
      errors,
      handleBlur,
      handleChange,
      handleSubmit,
      isSubmitting,
      touched,
      values
    }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("form", _objectSpread(_objectSpread({
      noValidate: true,
      onSubmit: handleSubmit
    }, others), {}, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
        fullWidth: true,
        error: Boolean(touched.password && errors.password),
        sx: _objectSpread({}, theme.typography.customInput),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
          htmlFor: "outlined-adornment-password-reset",
          children: "Password"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.OutlinedInput, {
          id: "outlined-adornment-password-reset",
          type: showPassword ? 'text' : 'password',
          value: values.password,
          name: "password",
          onBlur: handleBlur,
          onChange: e => {
            handleChange(e);
            changePassword(e.target.value);
          },
          endAdornment: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputAdornment, {
            position: "end",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
              "aria-label": "toggle password visibility",
              onClick: handleClickShowPassword,
              onMouseDown: handleMouseDownPassword,
              edge: "end",
              size: "large",
              children: showPassword ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_7___default()), {}) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_8___default()), {})
            })
          }),
          inputProps: {}
        })]
      }), touched.password && errors.password && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
        fullWidth: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormHelperText, {
          error: true,
          id: "standard-weight-helper-text-reset",
          children: errors.password
        })
      }), strength !== 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
        fullWidth: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
          sx: {
            mb: 2
          },
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            spacing: 2,
            alignItems: "center",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                style: {
                  backgroundColor: level.color
                },
                sx: {
                  width: 85,
                  height: 8,
                  borderRadius: '7px'
                }
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "subtitle1",
                fontSize: "0.75rem",
                children: level.label
              })
            })]
          })
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
        fullWidth: true,
        error: Boolean(touched.confirmPassword && errors.confirmPassword),
        sx: _objectSpread({}, theme.typography.customInput),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
          htmlFor: "outlined-adornment-confirm-password",
          children: "Confirm Password"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.OutlinedInput, {
          id: "outlined-adornment-confirm-password",
          type: "password",
          value: values.confirmPassword,
          name: "confirmPassword",
          label: "Confirm Password",
          onBlur: handleBlur,
          onChange: handleChange,
          inputProps: {}
        })]
      }), touched.confirmPassword && errors.confirmPassword && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
        fullWidth: true,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormHelperText, {
          error: true,
          id: "standard-weight-helper-text-confirm-password",
          children: [' ', errors.confirmPassword, ' ']
        })
      }), errors.submit && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        sx: {
          mt: 3
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormHelperText, {
          error: true,
          children: errors.submit
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        sx: {
          mt: 1
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
            disableElevation: true,
            disabled: isSubmitting,
            fullWidth: true,
            size: "large",
            type: "submit",
            variant: "contained",
            color: "secondary",
            children: "Reset Password"
          })
        })
      })]
    }))
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthResetPassword);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;