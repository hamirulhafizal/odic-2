"use strict";
exports.id = 1588;
exports.ids = [1588];
exports.modules = {

/***/ 91588:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(66197);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
 // third-party

 // ==============================|| ANIMATION BUTTON ||============================== //


const AnimateButton = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().forwardRef(({
  children,
  type,
  direction,
  offset,
  scale
}, ref) => {
  let offset1;
  let offset2;

  switch (direction) {
    case 'up':
    case 'left':
      offset1 = offset;
      offset2 = 0;
      break;

    case 'right':
    case 'down':
    default:
      offset1 = 0;
      offset2 = offset;
      break;
  }

  const [x, cycleX] = (0,framer_motion__WEBPACK_IMPORTED_MODULE_1__.useCycle)(offset1, offset2);
  const [y, cycleY] = (0,framer_motion__WEBPACK_IMPORTED_MODULE_1__.useCycle)(offset1, offset2);

  switch (type) {
    case 'rotate':
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
        ref: ref,
        animate: {
          rotate: 360
        },
        transition: {
          repeat: Infinity,
          repeatType: 'loop',
          duration: 2,
          repeatDelay: 0
        },
        children: children
      });

    case 'slide':
      if (direction === 'up' || direction === 'down') {
        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
          ref: ref,
          animate: {
            y: y !== undefined ? y : ''
          },
          onHoverEnd: () => cycleY(),
          onHoverStart: () => cycleY(),
          children: children
        });
      }

      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
        ref: ref,
        animate: {
          x: x !== undefined ? x : ''
        },
        onHoverEnd: () => cycleX(),
        onHoverStart: () => cycleX(),
        children: children
      });

    case 'scale':
    default:
      if (typeof scale === 'number') {
        scale = {
          hover: scale,
          tap: scale
        };
      }

      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
        ref: ref,
        whileHover: {
          scale: scale.hover
        },
        whileTap: {
          scale: scale.tap
        },
        children: children
      });
  }
});
AnimateButton.defaultProps = {
  type: 'scale',
  offset: 10,
  direction: 'right',
  scale: {
    hover: 1,
    tap: 0.9
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AnimateButton);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;