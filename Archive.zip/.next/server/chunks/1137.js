"use strict";
exports.id = 1137;
exports.ids = [1137];
exports.modules = {

/***/ 18995:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91931);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Breadcrumbs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(87185);
/* harmony import */ var _mui_material_Breadcrumbs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Breadcrumbs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7878);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(49514);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(94116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_AccountTreeTwoTone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(84118);
/* harmony import */ var _mui_icons_material_AccountTreeTwoTone__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AccountTreeTwoTone__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_Home__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(73467);
/* harmony import */ var _mui_icons_material_Home__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Home__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_HomeTwoTone__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(76942);
/* harmony import */ var _mui_icons_material_HomeTwoTone__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_HomeTwoTone__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);
const _excluded = ["card", "divider", "icon", "icons", "maxItems", "navigation", "rightAlign", "separator", "title", "titleBottom"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


 // material-ui



 // project imports


 // assets







const linkSX = {
  display: 'flex',
  color: 'grey.900',
  textDecoration: 'none',
  alignContent: 'center',
  alignItems: 'center'
}; // ==============================|| BREADCRUMBS ||============================== //

const Breadcrumbs = _ref => {
  let {
    card,
    divider,
    icon,
    icons,
    maxItems,
    navigation,
    rightAlign,
    separator,
    title,
    titleBottom
  } = _ref,
      others = _objectWithoutProperties(_ref, _excluded);

  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
  const iconStyle = {
    marginRight: theme.spacing(0.75),
    marginTop: `-${theme.spacing(0.25)}`,
    width: '1rem',
    height: '1rem',
    color: theme.palette.secondary.main
  };
  const {
    0: main,
    1: setMain
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    0: item,
    1: setItem
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(); // set active item state

  const getCollapse = menu => {
    if (menu.children) {
      menu.children.filter(collapse => {
        if (collapse.type && collapse.type === 'collapse') {
          getCollapse(collapse);
        } else if (collapse.type && collapse.type === 'item') {
          if (document.location.pathname === config__WEBPACK_IMPORTED_MODULE_5__/* .BASE_PATH */ .GW + collapse.url) {
            setMain(menu);
            setItem(collapse);
          }
        }

        return false;
      });
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    navigation.items.map(menu => {
      if (menu.type && menu.type === 'group') {
        getCollapse(menu);
      }

      return false;
    });
  }); // item separator

  const SeparatorIcon = separator;
  const separatorIcon = separator ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(SeparatorIcon, {
    stroke: 1.5,
    size: "1rem"
  }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconTallymark1, {
    stroke: 1.5,
    size: "1rem"
  });
  let mainContent;
  let itemContent;

  let breadcrumbContent = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {});

  let itemTitle = '';
  let CollapseIcon;
  let ItemIcon; // collapse item

  if (main && main.type === 'collapse') {
    CollapseIcon = main.icon ? main.icon : (_mui_icons_material_AccountTreeTwoTone__WEBPACK_IMPORTED_MODULE_7___default());
    mainContent = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
      component: Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
      href: "#",
      variant: "subtitle1",
      sx: linkSX,
      children: [icons && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(CollapseIcon, {
        style: iconStyle
      }), main.title]
    });
  } // items


  if (item && item.type === 'item') {
    itemTitle = item.title;
    ItemIcon = item.icon ? item.icon : (_mui_icons_material_AccountTreeTwoTone__WEBPACK_IMPORTED_MODULE_7___default());
    itemContent = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
      variant: "subtitle1",
      sx: {
        display: 'flex',
        textDecoration: 'none',
        alignContent: 'center',
        alignItems: 'center',
        color: 'grey.500'
      },
      children: [icons && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(ItemIcon, {
        style: iconStyle
      }), itemTitle]
    }); // main

    if (item.breadcrumbs !== false) {
      breadcrumbContent = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Card, _objectSpread(_objectSpread({
        sx: {
          marginBottom: card === false ? 0 : theme.spacing(store_constant__WEBPACK_IMPORTED_MODULE_11__/* .gridSpacing */ .dv),
          border: card === false ? 'none' : '1px solid',
          borderColor: theme.palette.mode === 'dark' ? theme.palette.background.default : theme.palette.primary[200] + 75,
          background: card === false ? 'transparent' : theme.palette.background.default
        }
      }, others), {}, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
          sx: {
            p: 2,
            pl: card === false ? 0 : 2
          },
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
            container: true,
            direction: rightAlign ? 'row' : 'column',
            justifyContent: rightAlign ? 'space-between' : 'flex-start',
            alignItems: rightAlign ? 'center' : 'flex-start',
            spacing: 1,
            children: [title && !titleBottom && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                variant: "h3",
                sx: {
                  fontWeight: 500
                },
                children: item.title
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
              item: true,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)((_mui_material_Breadcrumbs__WEBPACK_IMPORTED_MODULE_4___default()), {
                sx: {
                  '& .MuiBreadcrumbs-separator': {
                    width: 16,
                    ml: 1.25,
                    mr: 1.25
                  }
                },
                "aria-label": "breadcrumb",
                maxItems: maxItems || 8,
                separator: separatorIcon,
                children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                  component: Link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
                  href: "/",
                  color: "inherit",
                  variant: "subtitle1",
                  sx: linkSX,
                  children: [icons && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_HomeTwoTone__WEBPACK_IMPORTED_MODULE_9___default()), {
                    sx: iconStyle
                  }), icon && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_Home__WEBPACK_IMPORTED_MODULE_8___default()), {
                    sx: _objectSpread(_objectSpread({}, iconStyle), {}, {
                      mr: 0
                    })
                  }), !icon && 'Dashboard']
                }), mainContent, itemContent]
              })
            }), title && titleBottom && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                variant: "h3",
                sx: {
                  fontWeight: 500
                },
                children: item.title
              })
            })]
          })
        }), card === false && divider !== false && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Divider, {
          sx: {
            borderColor: theme.palette.primary.main,
            mb: store_constant__WEBPACK_IMPORTED_MODULE_11__/* .gridSpacing */ .dv
          }
        })]
      }));
    }
  }

  return breadcrumbContent;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Breadcrumbs);

/***/ }),

/***/ 67509:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ menu_items)
});

// EXTERNAL MODULE: external "react-intl"
var external_react_intl_ = __webpack_require__(13126);
// EXTERNAL MODULE: external "@tabler/icons"
var icons_ = __webpack_require__(94116);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/menu-items/application.js
// third-party
 // assets

 // constant




const icons = {
  IconUserCheck: icons_.IconUserCheck,
  IconBasket: icons_.IconBasket,
  IconMessages: icons_.IconMessages,
  IconLayoutKanban: icons_.IconLayoutKanban,
  IconMail: icons_.IconMail,
  IconCalendar: icons_.IconCalendar,
  IconNfc: icons_.IconNfc
}; // ==============================|| APPLICATION MENU ITEMS ||============================== //

const application = {
  id: 'application',
  title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
    id: "application"
  }),
  type: 'group',
  children: [{
    id: 'users',
    title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
      id: "users"
    }),
    type: 'collapse',
    icon: icons.IconUserCheck,
    children: [{
      id: 'posts',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "social-profile"
      }),
      type: 'item',
      url: '/app/user/social-profile/posts'
    }, {
      id: 'account-profile',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "account-profile"
      }),
      type: 'collapse',
      children: [{
        id: 'profile1',
        title: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
            id: "profile"
          }), " 01"]
        }),
        type: 'item',
        url: '/app/user/account-profile/profile1'
      }, {
        id: 'profile2',
        title: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
            id: "profile"
          }), " 02"]
        }),
        type: 'item',
        url: '/app/user/account-profile/profile2'
      }, {
        id: 'profile3',
        title: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
            id: "profile"
          }), " 03"]
        }),
        type: 'item',
        url: '/app/user/account-profile/profile3'
      }]
    }, {
      id: 'user-card',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "cards"
      }),
      type: 'collapse',
      children: [{
        id: 'card1',
        title: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
            id: "style"
          }), " 01"]
        }),
        type: 'item',
        url: '/app/user/card/card1'
      }, {
        id: 'card2',
        title: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
            id: "style"
          }), " 02"]
        }),
        type: 'item',
        url: '/app/user/card/card2'
      }, {
        id: 'card3',
        title: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
            id: "style"
          }), " 03"]
        }),
        type: 'item',
        url: '/app/user/card/card3'
      }]
    }, {
      id: 'user-list',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "list"
      }),
      type: 'collapse',
      children: [{
        id: 'list1',
        title: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
            id: "style"
          }), " 01"]
        }),
        type: 'item',
        url: '/app/user/list/list1'
      }, {
        id: 'list2',
        title: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
            id: "style"
          }), " 02"]
        }),
        type: 'item',
        url: '/app/user/list/list2'
      }]
    }]
  }, {
    id: 'customer',
    title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
      id: "customer"
    }),
    type: 'collapse',
    icon: icons.IconBasket,
    children: [{
      id: 'customer-list',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "customer-list"
      }),
      type: 'item',
      url: '/app/customer/customer-list',
      breadcrumbs: false
    }, {
      id: 'order-list',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "order-list"
      }),
      type: 'item',
      url: '/app/customer/order-list',
      breadcrumbs: false
    }, {
      id: 'order-details',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "order-details"
      }),
      type: 'item',
      url: '/app/customer/order-details'
    }, {
      id: 'product',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "product"
      }),
      type: 'item',
      url: '/app/customer/product',
      breadcrumbs: false
    }, {
      id: 'product-review',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "product-review"
      }),
      type: 'item',
      url: '/app/customer/product-review',
      breadcrumbs: false
    }]
  }, {
    id: 'chat',
    title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
      id: "chat"
    }),
    type: 'item',
    icon: icons.IconMessages,
    url: '/app/chat'
  }, {
    id: 'kanban',
    title: 'Kanban',
    type: 'item',
    icon: icons.IconLayoutKanban,
    url: '/app/kanban/board'
  }, {
    id: 'mail',
    title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
      id: "mail"
    }),
    type: 'item',
    icon: icons.IconMail,
    url: '/app/mail'
  }, {
    id: 'calendar',
    title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
      id: "calendar"
    }),
    type: 'item',
    url: '/app/calendar',
    icon: icons.IconCalendar,
    breadcrumbs: false
  }, {
    id: 'contact',
    title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
      id: "contact"
    }),
    type: 'collapse',
    icon: icons.IconNfc,
    children: [{
      id: 'c-card',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "cards"
      }),
      type: 'item',
      url: '/app/contact/c-card',
      breadcrumbs: false
    }, {
      id: 'c-list',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "list"
      }),
      type: 'item',
      url: '/app/contact/c-list',
      breadcrumbs: false
    }]
  }, {
    id: 'e-commerce',
    title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
      id: "e-commerce"
    }),
    type: 'collapse',
    icon: icons.IconBasket,
    children: [{
      id: 'products',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "products"
      }),
      type: 'item',
      url: '/app/e-commerce/products'
    }, {
      id: 'product-details',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "product-details"
      }),
      type: 'item',
      url: '/app/e-commerce/product-details/default',
      breadcrumbs: false
    }, {
      id: 'product-list',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "product-list"
      }),
      type: 'item',
      url: '/app/e-commerce/product-list',
      breadcrumbs: false
    }, {
      id: 'checkout',
      title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
        id: "checkout"
      }),
      type: 'item',
      url: '/app/e-commerce/checkout'
    }]
  }]
};
/* harmony default export */ const menu_items_application = ((/* unused pure expression or super */ null && (application)));
;// CONCATENATED MODULE: ./src/menu-items/dashboard.js
// third-party
 // assets

 // constant


const dashboard_icons = {
  IconDashboard: icons_.IconDashboard,
  IconDeviceAnalytics: icons_.IconDeviceAnalytics,
  IconListCheck: icons_.IconListCheck
}; // ==============================|| DASHBOARD MENU ITEMS ||============================== //

const dashboard = {
  id: 'dashboard',
  title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
    id: "dashboard"
  }),
  type: 'group',
  children: [{
    id: 'default',
    title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
      id: "default"
    }),
    type: 'item',
    url: '/dashboard/',
    icon: dashboard_icons.IconDashboard,
    breadcrumbs: false
  }, {
    id: 'listing',
    title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
      id: "listing"
    }),
    type: 'item',
    url: '/listing/',
    icon: dashboard_icons.IconListCheck,
    breadcrumbs: false
  }]
};
/* harmony default export */ const menu_items_dashboard = (dashboard);
;// CONCATENATED MODULE: ./src/menu-items/pages.js
// third-party
 // assets

 // constant


const pages_icons = {
  IconKey: icons_.IconKey,
  IconReceipt2: icons_.IconReceipt2,
  IconBug: icons_.IconBug,
  IconBellRinging: icons_.IconBellRinging,
  IconPhoneCall: icons_.IconPhoneCall,
  IconQuestionMark: icons_.IconQuestionMark,
  IconShieldLock: icons_.IconShieldLock
}; // ==============================|| EXTRA PAGES MENU ITEMS ||============================== //

const pages = {
  id: 'pages',
  title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
    id: "pages"
  }),
  caption: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
    id: "pages-caption"
  }),
  type: 'group',
  children: [{
    id: 'contact-us',
    title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
      id: "contact-us"
    }),
    type: 'item',
    icon: pages_icons.IconPhoneCall,
    url: '/pages/contact-us'
  }, {
    id: 'faqs',
    title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
      id: "faqs"
    }),
    type: 'item',
    icon: pages_icons.IconQuestionMark,
    url: '/pages/faqs'
  }, {
    id: 'privacy-policy',
    title: /*#__PURE__*/jsx_runtime_.jsx(external_react_intl_.FormattedMessage, {
      id: "privacy-policy"
    }),
    type: 'item',
    icon: pages_icons.IconShieldLock,
    url: '/pages/privacy-policy'
  }]
};
/* harmony default export */ const menu_items_pages = (pages);
;// CONCATENATED MODULE: ./src/menu-items/index.js


 // ==============================|| MENU ITEMS ||============================== //

const menuItems = {
  items: [menu_items_dashboard, menu_items_pages]
};
/* harmony default export */ const menu_items = (menuItems);

/***/ }),

/***/ 49514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dv": () => (/* binding */ gridSpacing),
/* harmony export */   "RK": () => (/* binding */ drawerWidth),
/* harmony export */   "D2": () => (/* binding */ appDrawerWidth)
/* harmony export */ });
// theme constant
const gridSpacing = 3;
const drawerWidth = 260;
const appDrawerWidth = 320;

/***/ })

};
;