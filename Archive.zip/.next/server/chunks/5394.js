"use strict";
exports.id = 5394;
exports.ids = [5394];
exports.modules = {

/***/ 95394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "WI": () => (/* binding */ store_dispatch),
  "yT": () => (/* binding */ persister),
  "h": () => (/* binding */ store),
  "I0": () => (/* binding */ useDispatch),
  "v9": () => (/* binding */ useSelector)
});

// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(75184);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "redux-persist"
var external_redux_persist_ = __webpack_require__(14161);
// EXTERNAL MODULE: external "redux"
var external_redux_ = __webpack_require__(86695);
// EXTERNAL MODULE: external "redux-persist/lib/storage"
var storage_ = __webpack_require__(98936);
var storage_default = /*#__PURE__*/__webpack_require__.n(storage_);
// EXTERNAL MODULE: ./src/store/slices/snackbar.js
var snackbar = __webpack_require__(12686);
// EXTERNAL MODULE: ./src/store/slices/customer.js
var customer = __webpack_require__(25475);
// EXTERNAL MODULE: ./src/store/slices/contact.js
var contact = __webpack_require__(28313);
// EXTERNAL MODULE: ./src/store/slices/product.js
var product = __webpack_require__(57541);
// EXTERNAL MODULE: ./src/store/slices/chat.js
var chat = __webpack_require__(12790);
// EXTERNAL MODULE: ./src/utils/axios.js
var utils_axios = __webpack_require__(17550);
;// CONCATENATED MODULE: ./src/store/slices/calendar.js
// third-party
 // project imports


 // ----------------------------------------------------------------------

const initialState = {
  error: null,
  events: []
};
const slice = (0,toolkit_.createSlice)({
  name: 'calendar',
  initialState,
  reducers: {
    // HAS ERROR
    hasError(state, action) {
      state.error = action.payload;
    },

    // GET EVENTS
    getEventsSuccess(state, action) {
      state.events = action.payload;
    },

    // ADD EVENT
    addEventSuccess(state, action) {
      state.events = action.payload;
    },

    // UPDATE EVENT
    updateEventSuccess(state, action) {
      state.events = action.payload;
    },

    // REMOVE EVENT
    removeEventSuccess(state, action) {
      state.events = action.payload;
    }

  }
}); // Reducer

/* harmony default export */ const calendar = (slice.reducer); // ----------------------------------------------------------------------

function getEvents() {
  return async () => {
    try {
      const response = await axios.get('/api/calendar/events');
      dispatch(slice.actions.getEventsSuccess(response.data.events));
    } catch (error) {
      dispatch(slice.actions.hasError(error));
    }
  };
}
function addEvent(event) {
  return async () => {
    try {
      const response = await axios.post('/api/calendar/events/new', event);
      dispatch(slice.actions.addEventSuccess(response.data));
    } catch (error) {
      dispatch(slice.actions.hasError(error));
    }
  };
}
function updateEvent(event) {
  return async () => {
    try {
      const response = await axios.post('/api/calendar/events/update', event);
      dispatch(slice.actions.updateEventSuccess(response.data.events));
    } catch (error) {
      dispatch(slice.actions.hasError(error));
    }
  };
}
function removeEvent(eventId) {
  return async () => {
    try {
      const response = await axios.post('/api/calendar/events/remove', {
        eventId
      });
      dispatch(slice.actions.removeEventSuccess(response.data));
    } catch (error) {
      dispatch(slice.actions.hasError(error));
    }
  };
}
// EXTERNAL MODULE: ./src/store/slices/mail.js
var mail = __webpack_require__(8110);
// EXTERNAL MODULE: ./src/store/slices/user.js
var user = __webpack_require__(83841);
// EXTERNAL MODULE: ./src/store/slices/cart.js
var cart = __webpack_require__(96504);
// EXTERNAL MODULE: ./src/store/slices/kanban.js
var kanban = __webpack_require__(38617);
// EXTERNAL MODULE: ./src/store/slices/menu.js
var menu = __webpack_require__(22361);
;// CONCATENATED MODULE: ./src/store/reducer.js
// third-party


 // project imports











 // import accReducer from './slices/accUser';
// ==============================|| COMBINE REDUCER ||============================== //

const reducer = (0,external_redux_.combineReducers)({
  snackbar: snackbar/* default */.ZP,
  cart: (0,external_redux_persist_.persistReducer)({
    key: 'cart',
    storage: (storage_default()),
    keyPrefix: 'berry-'
  }, cart/* default */.ZP),
  kanban: kanban/* default */.ZP,
  customer: customer/* default */.ZP,
  contact: contact/* default */.ZP,
  product: product/* default */.ZP,
  chat: chat/* default */.ZP,
  calendar: calendar,
  mail: mail/* default */.ZP,
  user: user/* default */.ZP,
  menu: menu/* default */.ZP // account: accReducer

});
/* harmony default export */ const store_reducer = (reducer);
;// CONCATENATED MODULE: ./src/store/index.js
// third-party


 // project imports

 // ==============================|| REDUX - MAIN STORE ||============================== //

const store = (0,toolkit_.configureStore)({
  reducer: store_reducer,
  middleware: getDefaultMiddleware => getDefaultMiddleware({
    serializableCheck: false,
    immutableCheck: false
  })
});
const persister = (0,external_redux_persist_.persistStore)(store);
const {
  dispatch: store_dispatch
} = store;

const useDispatch = () => (0,external_react_redux_.useDispatch)();

const useSelector = external_react_redux_.useSelector;


/***/ }),

/***/ 96504:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "gK": () => (/* binding */ addProduct),
/* harmony export */   "kh": () => (/* binding */ removeProduct),
/* harmony export */   "nM": () => (/* binding */ updateProduct),
/* harmony export */   "nj": () => (/* binding */ setStep),
/* harmony export */   "FE": () => (/* binding */ setNextStep),
/* harmony export */   "LE": () => (/* binding */ setBackStep),
/* harmony export */   "wC": () => (/* binding */ setBillingAddress),
/* harmony export */   "Q8": () => (/* binding */ setDiscount),
/* harmony export */   "aR": () => (/* binding */ setShippingCharge),
/* harmony export */   "s9": () => (/* binding */ resetCart)
/* harmony export */ });
/* unused harmony exports setPaymentMethod, setPaymentCard */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17550);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(95394);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// third-party
 // project imports


 // ----------------------------------------------------------------------

const initialState = {
  error: null,
  checkout: {
    step: 0,
    products: [],
    subtotal: 0,
    total: 0,
    discount: 0,
    shipping: 0,
    billing: null,
    payment: {
      type: 'free',
      method: 'cod',
      card: ''
    }
  }
};
const slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'cart',
  initialState,
  reducers: {
    // HAS ERROR
    hasError(state, action) {
      state.error = action.payload;
    },

    // ADD PRODUCT
    addProductSuccess(state, action) {
      state.checkout.products = action.payload.products;
      state.checkout.subtotal += action.payload.subtotal;
      state.checkout.total += action.payload.subtotal;
    },

    // REMOVE PRODUCT
    removeProductSuccess(state, action) {
      state.checkout.products = action.payload.products;
      state.checkout.subtotal += -action.payload.subtotal;
      state.checkout.total += -action.payload.subtotal;
    },

    // UPDATE PRODUCT
    updateProductSuccess(state, action) {
      state.checkout.products = action.payload.products;
      state.checkout.subtotal = state.checkout.subtotal - action.payload.oldSubTotal + action.payload.subtotal;
      state.checkout.total = state.checkout.total - action.payload.oldSubTotal + action.payload.subtotal;
    },

    // SET STEP
    setStepSuccess(state, action) {
      state.checkout.step = action.payload.step;
    },

    // SET NEXT STEP
    setNextStepSuccess(state) {
      state.checkout.step += 1;
    },

    // SET BACK STEP
    setBackStepSuccess(state) {
      state.checkout.step -= 1;
    },

    // SET BILLING ADDRESS
    setBillingAddressSuccess(state, action) {
      state.checkout.billing = action.payload.billing;
    },

    // SET DISCOUNT
    setDiscountSuccess(state, action) {
      let difference = 0;

      if (state.checkout.discount > 0) {
        difference = state.checkout.discount;
      }

      state.checkout.discount = action.payload.amount;
      state.checkout.total = state.checkout.total + difference - action.payload.amount;
    },

    // SET SHIPPING CHARGE
    setShippingChargeSuccess(state, action) {
      state.checkout.shipping = action.payload.shipping;
      state.checkout.total += action.payload.newShipping;
      state.checkout.payment = _objectSpread(_objectSpread({}, state.checkout.payment), {}, {
        type: action.payload.type
      });
    },

    // SET PAYMENT METHOD
    setPaymentMethodSuccess(state, action) {
      state.checkout.payment = _objectSpread(_objectSpread({}, state.checkout.payment), {}, {
        method: action.payload.method
      });
    },

    // SET PAYMENT CARD
    setPaymentCardSuccess(state, action) {
      state.checkout.payment = _objectSpread(_objectSpread({}, state.checkout.payment), {}, {
        card: action.payload.card
      });
    },

    // RESET CART
    resetCardSuccess(state) {
      state.checkout = initialState.checkout;
    }

  }
}); // Reducer

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (slice.reducer); // ----------------------------------------------------------------------

function addProduct(product, products) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/cart/add', {
        product,
        products
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.addProductSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function removeProduct(id, products) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/cart/remove', {
        id,
        products
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.removeProductSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function updateProduct(id, quantity, products) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/cart/update', {
        id,
        quantity,
        products
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.updateProductSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function setStep(step) {
  return () => {
    (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.setStepSuccess(step));
  };
}
function setNextStep() {
  return () => {
    (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.setNextStepSuccess({}));
  };
}
function setBackStep() {
  return () => {
    (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.setBackStepSuccess({}));
  };
}
function setBillingAddress(address) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/cart/billing-address', {
        address
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.setBillingAddressSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function setDiscount(code, total) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/cart/discount', {
        code,
        total
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.setDiscountSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function setShippingCharge(charge, shipping) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/cart/shipping-charge', {
        charge,
        shipping
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.setShippingChargeSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function setPaymentMethod(method) {
  return async () => {
    try {
      const response = await axios.post('/api/cart/payment-method', {
        method
      });
      dispatch(slice.actions.setPaymentMethodSuccess(response.data));
    } catch (error) {
      dispatch(slice.actions.hasError(error));
    }
  };
}
function setPaymentCard(card) {
  return async () => {
    try {
      const response = await axios.post('/api/cart/payment-card', {
        card
      });
      dispatch(slice.actions.setPaymentCardSuccess(response.data));
    } catch (error) {
      dispatch(slice.actions.hasError(error));
    }
  };
}
function resetCart() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/cart/reset');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.resetCardSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}

/***/ }),

/***/ 12790:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "PR": () => (/* binding */ getUser),
/* harmony export */   "Se": () => (/* binding */ getUserChats),
/* harmony export */   "H4": () => (/* binding */ insertChat),
/* harmony export */   "Rf": () => (/* binding */ getUsers)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17550);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(95394);
// third-party
 // project imports


 // ----------------------------------------------------------------------

const initialState = {
  error: null,
  chats: [],
  user: {},
  users: []
};
const slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'chat',
  initialState,
  reducers: {
    // HAS ERROR
    hasError(state, action) {
      state.error = action.payload;
    },

    // GET USER
    getUserSuccess(state, action) {
      state.user = action.payload;
    },

    // GET USER CHATS
    getUserChatsSuccess(state, action) {
      state.chats = action.payload;
    },

    // GET USERS
    getUsersSuccess(state, action) {
      state.users = action.payload;
    }

  }
}); // Reducer

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (slice.reducer); // ----------------------------------------------------------------------

function getUser(id) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/chat/users/id', {
        id
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getUserSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getUserChats(user) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/chat/filter', {
        user
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getUserChatsSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function insertChat(chat) {
  return async () => {
    try {
      await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/chat/insert', chat);
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getUsers() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/chat/users');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getUsersSuccess(response.data.users));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}

/***/ }),

/***/ 28313:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "K2": () => (/* binding */ getContacts),
/* harmony export */   "N6": () => (/* binding */ modifyContact)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17550);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(95394);
// third-party
 // project imports


 // ----------------------------------------------------------------------

const initialState = {
  error: null,
  contacts: []
};
const slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'contact',
  initialState,
  reducers: {
    // HAS ERROR
    hasError(state, action) {
      state.error = action.payload;
    },

    // GET CONTACTS
    getContactsSuccess(state, action) {
      state.contacts = action.payload;
    },

    // MODIFY CONTACT
    modifyContactSuccess(state, action) {
      state.contacts = action.payload;
    }

  }
}); // Reducer

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (slice.reducer); // ----------------------------------------------------------------------

function getContacts() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/contact/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getContactsSuccess(response.data.contacts));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function modifyContact(contact) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/contact/modify', contact);
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.modifyContactSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}

/***/ }),

/***/ 25475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "OL": () => (/* binding */ getCustomers),
/* harmony export */   "AU": () => (/* binding */ getOrders),
/* harmony export */   "Xp": () => (/* binding */ getProducts),
/* harmony export */   "mk": () => (/* binding */ getProductReviews)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17550);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(95394);
// third-party
 // project imports


 // ----------------------------------------------------------------------

const initialState = {
  error: null,
  customers: [],
  orders: [],
  products: [],
  productreviews: []
};
const slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'customer',
  initialState,
  reducers: {
    // HAS ERROR
    hasError(state, action) {
      state.error = action.payload;
    },

    // GET CUSTOMERS
    getCustomersSuccess(state, action) {
      state.customers = action.payload;
    },

    // GET ORDERS
    getOrdersSuccess(state, action) {
      state.orders = action.payload;
    },

    // GET PRODUCTS
    getProductsSuccess(state, action) {
      state.products = action.payload;
    },

    // GET PRODUCT REVIEWS
    getProductReviewsSuccess(state, action) {
      state.productreviews = action.payload;
    }

  }
}); // Reducer

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (slice.reducer); // ----------------------------------------------------------------------

function getCustomers() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/customer/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getCustomersSuccess(response.data.customers));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getOrders() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/customer/order/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getOrdersSuccess(response.data.orders));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getProducts() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/customer/product/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getProductsSuccess(response.data.products));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getProductReviews() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/customer/product/reviews');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getProductReviewsSuccess(response.data.productreviews));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}

/***/ }),

/***/ 38617:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Pu": () => (/* binding */ getColumns),
/* harmony export */   "WR": () => (/* binding */ getColumnsOrder),
/* harmony export */   "li": () => (/* binding */ getComments),
/* harmony export */   "cp": () => (/* binding */ getProfiles),
/* harmony export */   "kk": () => (/* binding */ getItems),
/* harmony export */   "Bh": () => (/* binding */ getUserStory),
/* harmony export */   "Zv": () => (/* binding */ getUserStoryOrder),
/* harmony export */   "Wf": () => (/* binding */ addColumn),
/* harmony export */   "L9": () => (/* binding */ editColumn),
/* harmony export */   "sf": () => (/* binding */ updateColumnOrder),
/* harmony export */   "eA": () => (/* binding */ deleteColumn),
/* harmony export */   "jX": () => (/* binding */ addItem),
/* harmony export */   "Ob": () => (/* binding */ editItem),
/* harmony export */   "X6": () => (/* binding */ updateColumnItemOrder),
/* harmony export */   "Gh": () => (/* binding */ selectItem),
/* harmony export */   "$B": () => (/* binding */ addItemComment),
/* harmony export */   "wz": () => (/* binding */ deleteItem),
/* harmony export */   "kh": () => (/* binding */ addStory),
/* harmony export */   "l4": () => (/* binding */ editStory),
/* harmony export */   "qG": () => (/* binding */ updateStoryOrder),
/* harmony export */   "CA": () => (/* binding */ updateStoryItemOrder),
/* harmony export */   "mx": () => (/* binding */ addStoryComment),
/* harmony export */   "LA": () => (/* binding */ deleteStory)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17550);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(95394);
// third-party
 // project imports


 // ----------------------------------------------------------------------

const initialState = {
  error: null,
  columns: [],
  columnsOrder: [],
  comments: [],
  items: [],
  profiles: [],
  selectedItem: false,
  userStory: [],
  userStoryOrder: []
};
const slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'kanban',
  initialState,
  reducers: {
    // HAS ERROR
    hasError(state, action) {
      state.error = action.payload;
    },

    // ADD COLUMN
    addColumnSuccess(state, action) {
      state.columns = action.payload.columns;
      state.columnsOrder = action.payload.columnsOrder;
    },

    // EDIT COLUMN
    editColumnSuccess(state, action) {
      state.columns = action.payload.columns;
    },

    // UPDATE COLUMN ORDER
    updateColumnOrderSuccess(state, action) {
      state.columnsOrder = action.payload.columnsOrder;
    },

    // DELETE COLUMN
    deleteColumnSuccess(state, action) {
      state.columns = action.payload.columns;
      state.columnsOrder = action.payload.columnsOrder;
    },

    // ADD ITEM
    addItemSuccess(state, action) {
      state.items = action.payload.items;
      state.columns = action.payload.columns;
      state.userStory = action.payload.userStory;
    },

    // EDIT ITEM
    editItemSuccess(state, action) {
      state.items = action.payload.items;
      state.columns = action.payload.columns;
      state.userStory = action.payload.userStory;
    },

    // UPDATE COLUMN ITEM ORDER
    updateColumnItemOrderSuccess(state, action) {
      state.columns = action.payload.columns;
    },

    // SELECT ITEM
    selectItemSuccess(state, action) {
      state.selectedItem = action.payload.selectedItem;
    },

    // ADD ITEM COMMENT
    addItemCommentSuccess(state, action) {
      state.items = action.payload.items;
      state.comments = action.payload.comments;
    },

    // DELETE ITEM
    deleteItemSuccess(state, action) {
      state.items = action.payload.items;
      state.columns = action.payload.columns;
      state.userStory = action.payload.userStory;
    },

    // ADD STORY
    addStorySuccess(state, action) {
      state.userStory = action.payload.userStory;
      state.userStoryOrder = action.payload.userStoryOrder;
    },

    // EDIT STORY
    editStorySuccess(state, action) {
      state.userStory = action.payload.userStory;
    },

    // UPDATE STORY ORDER
    updateStoryOrderSuccess(state, action) {
      state.userStoryOrder = action.payload.userStoryOrder;
    },

    // UPDATE STORY ITEM ORDER
    updateStoryItemOrderSuccess(state, action) {
      state.userStory = action.payload.userStory;
    },

    // ADD STORY COMMENT
    addStoryCommentSuccess(state, action) {
      state.userStory = action.payload.userStory;
      state.comments = action.payload.comments;
    },

    // DELETE STORY
    deleteStorySuccess(state, action) {
      state.userStory = action.payload.userStory;
      state.userStoryOrder = action.payload.userStoryOrder;
    },

    // GET COLUMNS
    getColumnsSuccess(state, action) {
      state.columns = action.payload;
    },

    // GET COLUMNS ORDER
    getColumnsOrderSuccess(state, action) {
      state.columnsOrder = action.payload;
    },

    // GET COMMENTS
    getCommentsSuccess(state, action) {
      state.comments = action.payload;
    },

    // GET PROFILES
    getProfilesSuccess(state, action) {
      state.profiles = action.payload;
    },

    // GET ITEMS
    getItemsSuccess(state, action) {
      state.items = action.payload;
    },

    // GET USER STORY
    getUserStorySuccess(state, action) {
      state.userStory = action.payload;
    },

    // GET USER STORY ORDER
    getUserStoryOrderSuccess(state, action) {
      state.userStoryOrder = action.payload;
    }

  }
}); // Reducer

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (slice.reducer); // ----------------------------------------------------------------------

function getColumns() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/kanban/columns');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getColumnsSuccess(response.data.columns));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getColumnsOrder() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/kanban/columns-order');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getColumnsOrderSuccess(response.data.columnsOrder));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getComments() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/kanban/comments');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getCommentsSuccess(response.data.comments));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getProfiles() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/kanban/profiles');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getProfilesSuccess(response.data.profiles));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getItems() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/kanban/items');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getItemsSuccess(response.data.items));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getUserStory() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/kanban/userstory');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getUserStorySuccess(response.data.userStory));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getUserStoryOrder() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/kanban/userstory-order');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getUserStoryOrderSuccess(response.data.userStoryOrder));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function addColumn(column, columns, columnsOrder) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/add-column', {
        column,
        columns,
        columnsOrder
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.addColumnSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function editColumn(column, columns) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/edit-column', {
        column,
        columns
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.editColumnSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function updateColumnOrder(columnsOrder) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/update-column-order', {
        columnsOrder
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.updateColumnOrderSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function deleteColumn(columnId, columnsOrder, columns) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/delete-column', {
        columnId,
        columnsOrder,
        columns
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.deleteColumnSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function addItem(columnId, columns, item, items, storyId, userStory) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/add-item', {
        columnId,
        columns,
        item,
        items,
        storyId,
        userStory
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.addItemSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function editItem(columnId, columns, item, items, storyId, userStory) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/edit-item', {
        items,
        item,
        userStory,
        storyId,
        columns,
        columnId
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.editItemSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function updateColumnItemOrder(columns) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/update-item-order', {
        columns
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.updateColumnItemOrderSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function selectItem(selectedItem) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/select-item', {
        selectedItem
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.selectItemSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function addItemComment(itemId, comment, items, comments) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/add-item-comment', {
        items,
        itemId,
        comment,
        comments
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.addItemCommentSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function deleteItem(itemId, items, columns, userStory) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/delete-item', {
        columns,
        itemId,
        userStory,
        items
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.deleteItemSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function addStory(story, userStory, userStoryOrder) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/add-story', {
        userStory,
        story,
        userStoryOrder
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.addStorySuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function editStory(story, userStory) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/edit-story', {
        userStory,
        story
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.editStorySuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function updateStoryOrder(userStoryOrder) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/update-story-order', {
        userStoryOrder
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.updateStoryOrderSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function updateStoryItemOrder(userStory) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/update-storyitem-order', {
        userStory
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.updateStoryItemOrderSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function addStoryComment(storyId, comment, comments, userStory) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/add-story-comment', {
        userStory,
        storyId,
        comment,
        comments
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.addStoryCommentSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function deleteStory(storyId, userStory, userStoryOrder) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/kanban/delete-story', {
        userStory,
        storyId,
        userStoryOrder
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.deleteStorySuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}

/***/ }),

/***/ 8110:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Y9": () => (/* binding */ getMails),
/* harmony export */   "tj": () => (/* binding */ filterMails),
/* harmony export */   "LL": () => (/* binding */ setImportant),
/* harmony export */   "OQ": () => (/* binding */ setStarred),
/* harmony export */   "$h": () => (/* binding */ setRead)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17550);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(95394);
// third-party
 // project imports


 // ----------------------------------------------------------------------

const initialState = {
  error: null,
  mails: [],
  unreadCount: undefined
};
const slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'mail',
  initialState,
  reducers: {
    // HAS ERROR
    hasError(state, action) {
      state.error = action.payload;
    },

    // GET MAILS
    getMailsSuccess(state, action) {
      state.mails = action.payload.mails;
      state.unreadCount = action.payload.unreadCount;
    },

    // FILTER MAILS
    filterMailsSuccess(state, action) {
      state.mails = action.payload;
    }

  }
}); // Reducer

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (slice.reducer); // ----------------------------------------------------------------------

function getMails() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/mails/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getMailsSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function filterMails(filter) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/mails/filter', {
        filter
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.filterMailsSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function setImportant(id) {
  return async () => {
    try {
      await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/mails/setImportant', {
        id
      });
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function setStarred(id) {
  return async () => {
    try {
      await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/mails/setStarred', {
        id
      });
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function setRead(id) {
  return async () => {
    try {
      await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/mails/setRead', {
        id
      });
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}

/***/ }),

/***/ 22361:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "zw": () => (/* binding */ activeItem),
/* harmony export */   "FJ": () => (/* binding */ openDrawer)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
// third-party
 // initial state

const initialState = {
  openItem: ['dashboard'],
  drawerOpen: false
}; // ==============================|| SLICE - MENU ||============================== //

const menu = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'menu',
  initialState,
  reducers: {
    activeItem(state, action) {
      state.openItem = action.payload;
    },

    openDrawer(state, action) {
      state.drawerOpen = action.payload;
    }

  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (menu.reducer);
const {
  activeItem,
  openDrawer
} = menu.actions;

/***/ }),

/***/ 57541:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Xp": () => (/* binding */ getProducts),
/* harmony export */   "ft": () => (/* binding */ filterProducts),
/* harmony export */   "wv": () => (/* binding */ getProduct),
/* harmony export */   "Er": () => (/* binding */ getRelatedProducts),
/* harmony export */   "mk": () => (/* binding */ getProductReviews),
/* harmony export */   "ZK": () => (/* binding */ getAddresses),
/* harmony export */   "y$": () => (/* binding */ addAddress),
/* harmony export */   "Yb": () => (/* binding */ editAddress)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var utils_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17550);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(95394);
// third-party
 // project imports


 // ----------------------------------------------------------------------

const initialState = {
  error: null,
  products: [],
  product: null,
  relatedProducts: [],
  reviews: [],
  addresses: []
};
const slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'product',
  initialState,
  reducers: {
    // HAS ERROR
    hasError(state, action) {
      state.error = action.payload;
    },

    // GET PRODUCTS
    getProductsSuccess(state, action) {
      state.products = action.payload;
    },

    // FILTER PRODUCTS
    filterProductsSuccess(state, action) {
      state.products = action.payload;
    },

    // GET PRODUCT
    getProductSuccess(state, action) {
      state.product = action.payload;
    },

    // GET RELATED PRODUCTS
    getRelatedProductsSuccess(state, action) {
      state.relatedProducts = action.payload;
    },

    // GET PRODUCT REVIEWS
    getProductReviewsSuccess(state, action) {
      state.reviews = action.payload;
    },

    // GET ADDRESSES
    getAddressesSuccess(state, action) {
      state.addresses = action.payload;
    },

    // ADD ADDRESS
    addAddressSuccess(state, action) {
      state.addresses = action.payload;
    },

    // EDIT ADDRESS
    editAddressSuccess(state, action) {
      state.addresses = action.payload;
    }

  }
}); // Reducer

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (slice.reducer); // ----------------------------------------------------------------------

function getProducts() {
  return async () => {
    try {
      const response = await utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/products/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getProductsSuccess(response.data.products));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function filterProducts(filter) {
  return async () => {
    try {
      const response = await utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/product/filter', {
        filter
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.filterProductsSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getProduct(id) {
  return async () => {
    try {
      const response = await utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/product/details', {
        id
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getProductSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getRelatedProducts(id) {
  return async () => {
    try {
      const response = await utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/product/related', {
        id
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getRelatedProductsSuccess(response.data));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getProductReviews() {
  return async () => {
    try {
      const response = await utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/review/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getProductReviewsSuccess(response.data.productReviews));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getAddresses() {
  return async () => {
    try {
      const response = await utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/address/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getAddressesSuccess(response.data.address));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function addAddress(address) {
  return async () => {
    try {
      const response = await utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/address/new', address);
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.addAddressSuccess(response.data.address));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function editAddress(address) {
  return async () => {
    try {
      const response = await utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/address/edit', address);
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.editAddressSuccess(response.data.address));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}

/***/ }),

/***/ 12686:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "sy": () => (/* binding */ closeSnackbar),
/* harmony export */   "ss": () => (/* binding */ openSnackbar)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
  action: false,
  open: false,
  message: 'Note archived',
  anchorOrigin: {
    vertical: 'bottom',
    horizontal: 'right'
  },
  variant: 'default',
  alert: {
    color: 'primary',
    variant: 'filled'
  },
  transition: 'Fade',
  close: true,
  actionButton: false
}; // ==============================|| SLICE - SNACKBAR ||============================== //

const snackbar = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'snackbar',
  initialState,
  reducers: {
    openSnackbar(state, action) {
      const {
        open,
        message,
        anchorOrigin,
        variant,
        alert,
        transition,
        close,
        actionButton
      } = action.payload;
      state.action = !state.action;
      state.open = open || initialState.open;
      state.message = message || initialState.message;
      state.anchorOrigin = anchorOrigin || initialState.anchorOrigin;
      state.variant = variant || initialState.variant;
      state.alert = {
        color: alert && alert.color || initialState.alert.color,
        variant: alert && alert.variant || initialState.alert.variant
      };
      state.transition = transition || initialState.transition;
      state.close = close === false ? close : initialState.close;
      state.actionButton = actionButton || initialState.actionButton;
    },

    closeSnackbar(state) {
      state.open = false;
    }

  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (snackbar.reducer);
const {
  closeSnackbar,
  openSnackbar
} = snackbar.actions;

/***/ }),

/***/ 83841:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "RM": () => (/* binding */ getUsersListStyle1),
/* harmony export */   "fO": () => (/* binding */ getUsersListStyle2),
/* harmony export */   "ET": () => (/* binding */ getFollowers),
/* harmony export */   "WX": () => (/* binding */ filterFollowers),
/* harmony export */   "_e": () => (/* binding */ getFriendRequests),
/* harmony export */   "YJ": () => (/* binding */ filterFriendRequests),
/* harmony export */   "$J": () => (/* binding */ getFriends),
/* harmony export */   "Gy": () => (/* binding */ filterFriends),
/* harmony export */   "we": () => (/* binding */ getGallery),
/* harmony export */   "Jq": () => (/* binding */ getPosts),
/* harmony export */   "DF": () => (/* binding */ editComment),
/* harmony export */   "Ir": () => (/* binding */ addComment),
/* harmony export */   "Bn": () => (/* binding */ addReply),
/* harmony export */   "n9": () => (/* binding */ likePost),
/* harmony export */   "xG": () => (/* binding */ likeComment),
/* harmony export */   "YO": () => (/* binding */ likeReply),
/* harmony export */   "Hq": () => (/* binding */ getDetailCards),
/* harmony export */   "Mv": () => (/* binding */ filterDetailCards),
/* harmony export */   "eJ": () => (/* binding */ getSimpleCards),
/* harmony export */   "nl": () => (/* binding */ filterSimpleCards),
/* harmony export */   "qI": () => (/* binding */ getProfileCards),
/* harmony export */   "l0": () => (/* binding */ filterProfileCards)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17550);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(95394);
// third-party
 // project imports


 // ----------------------------------------------------------------------

const initialState = {
  error: null,
  usersS1: [],
  usersS2: [],
  followers: [],
  friendRequests: [],
  friends: [],
  gallery: [],
  posts: [],
  detailCards: [],
  simpleCards: [],
  profileCards: []
};
const slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'user',
  initialState,
  reducers: {
    // HAS ERROR
    hasError(state, action) {
      state.error = action.payload;
    },

    // GET USERS STYLE 1
    getUsersListStyle1Success(state, action) {
      state.usersS1 = action.payload;
    },

    // GET USERS STYLE 2
    getUsersListStyle2Success(state, action) {
      state.usersS2 = action.payload;
    },

    // GET FOLLOWERS
    getFollowersSuccess(state, action) {
      state.followers = action.payload;
    },

    // FILTER FOLLOWERS
    filterFollowersSuccess(state, action) {
      state.followers = action.payload;
    },

    // GET FRIEND REQUESTS
    getFriendRequestsSuccess(state, action) {
      state.friendRequests = action.payload;
    },

    // FILTER FRIEND REQUESTS
    filterFriendRequestsSuccess(state, action) {
      state.friendRequests = action.payload;
    },

    // GET FRIENDS
    getFriendsSuccess(state, action) {
      state.friends = action.payload;
    },

    // FILTER FRIENDS
    filterFriendsSuccess(state, action) {
      state.friends = action.payload;
    },

    // GET GALLERY
    getGallerySuccess(state, action) {
      state.gallery = action.payload;
    },

    // GET POSTS
    getPostsSuccess(state, action) {
      state.posts = action.payload;
    },

    // EDIT COMMENT
    editCommentSuccess(state, action) {
      state.posts = action.payload;
    },

    // ADD COMMENT
    addCommentSuccess(state, action) {
      state.posts = action.payload;
    },

    // ADD REPLY
    addReplySuccess(state, action) {
      state.posts = action.payload;
    },

    // LIKE POST
    likePostSuccess(state, action) {
      state.posts = action.payload;
    },

    // LIKE COMMENT
    likeCommentSuccess(state, action) {
      state.posts = action.payload;
    },

    // LIKE REPLY
    likeReplySuccess(state, action) {
      state.posts = action.payload;
    },

    // GET DETAIL CARDS
    getDetailCardsSuccess(state, action) {
      state.detailCards = action.payload;
    },

    // FILTER DETAIL CARDS
    filterDetailCardsSuccess(state, action) {
      state.detailCards = action.payload;
    },

    // GET SIMPLE CARDS
    getSimpleCardsSuccess(state, action) {
      state.simpleCards = action.payload;
    },

    // FILTER SIMPLE CARDS
    filterSimpleCardsSuccess(state, action) {
      state.simpleCards = action.payload;
    },

    // GET PROFILE CARDS
    getProfileCardsSuccess(state, action) {
      state.profileCards = action.payload;
    },

    // FILTER PROFILE CARDS
    filterProfileCardsSuccess(state, action) {
      state.profileCards = action.payload;
    }

  }
}); // Reducer

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (slice.reducer); // ----------------------------------------------------------------------

function getUsersListStyle1() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/user-list/s1/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getUsersListStyle1Success(response.data.users_s1));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getUsersListStyle2() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/user-list/s2/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getUsersListStyle2Success(response.data.users_s2));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getFollowers() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/followers/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getFollowersSuccess(response.data.followers));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function filterFollowers(key) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/followers/filter', {
        key
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.filterFollowersSuccess(response.data.results));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getFriendRequests() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/friend-request/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getFriendRequestsSuccess(response.data.friends));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function filterFriendRequests(key) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/friend-request/filter', {
        key
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.filterFriendRequestsSuccess(response.data.results));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getFriends() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/friends/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getFriendsSuccess(response.data.friends));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function filterFriends(key) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/friends/filter', {
        key
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.filterFriendsSuccess(response.data.results));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getGallery() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/gallery/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getGallerySuccess(response.data.gallery));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getPosts() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/posts/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getPostsSuccess(response.data.posts));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function editComment(key, id) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/posts/editComment', {
        key,
        id
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.editCommentSuccess(response.data.posts));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function addComment(postId, comment) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/comments/add', {
        postId,
        comment
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.addCommentSuccess(response.data.posts));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function addReply(postId, commentId, reply) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/replies/add', {
        postId,
        commentId,
        reply
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.addReplySuccess(response.data.posts));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function likePost(postId) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/posts/list/like', {
        postId
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.likePostSuccess(response.data.posts));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function likeComment(postId, commentId) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/comments/list/like', {
        postId,
        commentId
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.likeCommentSuccess(response.data.posts));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function likeReply(postId, commentId, replayId) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/replies/list/like', {
        postId,
        commentId,
        replayId
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.likeReplySuccess(response.data.posts));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getDetailCards() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/details-card/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getDetailCardsSuccess(response.data.users));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function filterDetailCards(key) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/details-card/filter', {
        key
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.filterDetailCardsSuccess(response.data.results));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getSimpleCards() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/simple-card/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getSimpleCardsSuccess(response.data.users));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function filterSimpleCards(key) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/simple-card/filter', {
        key
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.filterSimpleCardsSuccess(response.data.results));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function getProfileCards() {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get('/api/profile-card/list');
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.getProfileCardsSuccess(response.data.users));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}
function filterProfileCards(key) {
  return async () => {
    try {
      const response = await _utils_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post('/api/profile-card/filter', {
        key
      });
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.filterProfileCardsSuccess(response.data.results));
    } catch (error) {
      (0,_index__WEBPACK_IMPORTED_MODULE_2__/* .dispatch */ .WI)(slice.actions.hasError(error));
    }
  };
}

/***/ }),

/***/ 17550:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/**
 * axios setup to use mock service
 */

const axiosServices = axios__WEBPACK_IMPORTED_MODULE_0___default().create(); // interceptor for http

axiosServices.interceptors.response.use(response => response, error => Promise.reject(error.response && error.response.data || 'Wrong Services'));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosServices);

/***/ })

};
;