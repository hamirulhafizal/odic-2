"use strict";
exports.id = 9684;
exports.ids = [9684];
exports.modules = {

/***/ 37762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "C": () => (/* binding */ JWTProvider),
  "Z": () => (/* binding */ contexts_JWTContext)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "chance"
var external_chance_ = __webpack_require__(40306);
// EXTERNAL MODULE: external "jwt-decode"
var external_jwt_decode_ = __webpack_require__(45567);
// EXTERNAL MODULE: external "jsonwebtoken"
var external_jsonwebtoken_ = __webpack_require__(99344);
// EXTERNAL MODULE: ./src/config.js
var config = __webpack_require__(7878);
;// CONCATENATED MODULE: ./src/store/actions.js
// action - account reducer
const LOGIN = 'LOGIN';
const LOGOUT = 'LOGOUT';
const REGISTER = 'REGISTER';
const FIREBASE_STATE_CHANGED = 'FIREBASE_STATE_CHANGED';
;// CONCATENATED MODULE: ./src/store/accountReducer.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// action - state management
 // ==============================|| ACCOUNT REDUCER ||============================== //

const initialState = {
  isLoggedIn: false,
  isInitialized: false,
  user: null
};

const accountReducer = (state = initialState, action) => {
  switch (action.type) {
    case REGISTER:
      {
        const {
          user
        } = action.payload;
        return _objectSpread(_objectSpread({}, state), {}, {
          user
        });
      }

    case LOGIN:
      {
        const {
          user
        } = action.payload;
        return _objectSpread(_objectSpread({}, state), {}, {
          isLoggedIn: true,
          isInitialized: true,
          user
        });
      }

    case LOGOUT:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          isInitialized: true,
          isLoggedIn: false,
          user: null
        });
      }

    default:
      {
        return _objectSpread({}, state);
      }
  }
};

/* harmony default export */ const store_accountReducer = (accountReducer);
// EXTERNAL MODULE: external "@mui/material/LinearProgress"
var LinearProgress_ = __webpack_require__(25545);
var LinearProgress_default = /*#__PURE__*/__webpack_require__.n(LinearProgress_);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(18442);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/components/ui-component/Loader.js
// material-ui

 // styles


const LoaderWrapper = (0,styles_.styled)('div')({
  position: 'fixed',
  top: 0,
  left: 0,
  zIndex: 1301,
  width: '100%'
}); // ==============================|| LOADER ||============================== //

const Loader = () => /*#__PURE__*/jsx_runtime_.jsx(LoaderWrapper, {
  children: /*#__PURE__*/jsx_runtime_.jsx((LinearProgress_default()), {
    color: "primary"
  })
});

/* harmony default export */ const ui_component_Loader = (Loader);
// EXTERNAL MODULE: ./src/utils/axios.js
var axios = __webpack_require__(17550);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(52167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ./src/contexts/axios.js


const baseURL = config/* BACKEND_PATH */.rB;
const axiosInstance = external_axios_default().create({
  baseURL: baseURL,
  timeout: 5000,
  headers: {
    Authorization:  false ? 0 :  false ? 0 : null,
    'Content-Type': 'application/json',
    accept: 'application/json'
  }
});
axiosInstance.interceptors.response.use(response => {
  return response;
}, async function (error) {
  const originalRequest = error.config;

  if (typeof error.response === 'undefined') {
    alert('A server/network error occurred. ' + 'Looks like CORS might be the problem. ' + 'Sorry about this - we will get it fixed shortly.');
    return Promise.reject(error);
  }

  if (error.response.status === 401 && originalRequest.url === baseURL + '/api/v1/login/refresh') {
    window.location.href = '/login/';
    return Promise.reject(error);
  }

  if (error.response.data.code === 'token_not_valid' && error.response.status === 401 && error.response.statusText === 'Unauthorized') {
    const refreshToken =  false ? 0 : null;

    if (refreshToken) {
      const tokenParts = JSON.parse(atob(refreshToken.split('.')[1])); // exp date in token is expressed in seconds, while now() returns milliseconds:

      const now = Math.ceil(Date.now() / 1000);
      console.log(tokenParts.exp);

      if (tokenParts.exp > now) {
        return axiosInstance.post('/api/v1/login/refresh', {
          refresh: refreshToken
        }).then(response => {
          localStorage.setItem('access', response.data.access);
          localStorage.setItem('refresh', response.data.refresh);
          axiosInstance.defaults.headers['Authorization'] = 'JWT ' + response.data.access;
          originalRequest.headers['Authorization'] = 'JWT ' + response.data.access;
          return axiosInstance(originalRequest);
        }).catch(err => {
          console.log(err);
        });
      } else {
        console.log('Refresh token is expired', tokenParts.exp, now);
        window.location.href = '/login/';
      }
    } else {
      console.log('Refresh token not available.');
      window.location.href = '/login/';
    }
  } // specific error handling done elsewhere


  return Promise.reject(error);
});
/* harmony default export */ const contexts_axios = (axiosInstance);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(71853);
// EXTERNAL MODULE: ./src/store/slices/user.js
var user = __webpack_require__(83841);
;// CONCATENATED MODULE: ./src/contexts/JWTContext.js
function JWTContext_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function JWTContext_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { JWTContext_ownKeys(Object(source), true).forEach(function (key) { JWTContext_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { JWTContext_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function JWTContext_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/* eslint-disable arrow-body-style */

/* eslint-disable camelcase */
 // third-party




 // reducer - state management


 // project imports




 //next


 // constant


const JWT_SECRET = config/* JWT_API.secret */.Sk.secret;
const JWT_EXPIRES_TIME = config/* JWT_API.timeout */.Sk.timeout;
const chance = new external_chance_.Chance(); // let users = [
//   {
//     user_name: '5e86809283e28b96d2d38537',
//     email: 'info@codedthemes.com',
//     password: '123456'
//   }
// ];
// constant

const JWTContext_initialState = {
  isLoggedIn: false,
  isInitialized: false,
  user: null
}; // ==============================|| JWT CONTEXT & PROVIDER ||============================== //

const JWTContext = /*#__PURE__*/(0,external_react_.createContext)(null);
const JWTProvider = ({
  children
}) => {
  const {
    0: state,
    1: dispatch
  } = (0,external_react_.useReducer)(store_accountReducer, JWTContext_initialState);
  const history = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    const init = async () => {
      try {
        const serviceToken = window.localStorage.getItem('access');

        if (serviceToken) {
          if (window.localStorage.getItem('users') !== undefined && window.localStorage.getItem('users') !== null) {
            const localUsers = window.localStorage.getItem('users');
            let users = JSON.parse(localUsers);
            dispatch({
              type: LOGIN,
              payload: {
                isLoggedIn: true,
                user: users
              }
            });
          }
        } else {
          dispatch({
            type: LOGOUT
          });
        }
      } catch (err) {
        // console.error(err);
        dispatch({
          type: LOGOUT
        });
      }
    };

    if (state.user == null) init();
  }, [state.user]);

  const login = async (email, password) => {
    const response = await contexts_axios.post(`${config/* BACKEND_PATH */.rB}/api/v1/user/login`, {
      email,
      password
    }).then(async res => {
      var _res$data3;

      if (false) { var _res$data, _res$data2; }

      await getProfile(res === null || res === void 0 ? void 0 : (_res$data3 = res.data) === null || _res$data3 === void 0 ? void 0 : _res$data3.user_name);
      dispatch({
        type: LOGIN,
        payload: {
          isLoggedIn: true
        }
      });
      history.push('/dashboard');
      return res;
    });
  };

  const register = async (email, password, first_name, last_name) => {
    // todo: this flow need to be recode as it not verified
    const user_name = first_name + last_name;
    const response = await contexts_axios.post(`${config/* BACKEND_PATH */.rB}/api/v1/user/register`, {
      email,
      user_name,
      first_name,
      password
    }).then(res => {
      console.log(res);
      login(email, password, user_name);
      history.push('/login');
      return res;
    });
  };

  const logout = async () => {
    // const response = await axiosInstance.post(`${BACKEND_PATH}/api/v1/user/logout`)
    // .then((res) => {
    //   history.push('/login');
    //   return res;
    // });
    // let off = response.data;
    dispatch({
      type: LOGOUT
    });
    window.localStorage.removeItem('access');
    window.localStorage.removeItem('refresh');
    window.localStorage.removeItem('users');
  };

  const resetPassword = email => console.log(email);

  const getProfile = async user_name => {
    contexts_axios.defaults.headers.Authorization = 'JWT ' + localStorage.getItem('access');
    const response = await contexts_axios.get(`${config/* BACKEND_PATH */.rB}/api/v1/profile/${user_name}`).then(res => {
      if (false) {}

      return res;
    });
  };

  const updateProfile = async (user_name, formData) => {
    const response = await contexts_axios.patch(`${config/* BACKEND_PATH */.rB}/api/v1/profile/${user_name}`, formData).then(res => {
      if (false) {}

      return res;
    });
  };

  if (state.isInitialized !== undefined && !state.isInitialized) {
    return /*#__PURE__*/jsx_runtime_.jsx(ui_component_Loader, {});
  }

  return /*#__PURE__*/jsx_runtime_.jsx(JWTContext.Provider, {
    value: JWTContext_objectSpread(JWTContext_objectSpread({}, state), {}, {
      login,
      logout,
      register,
      resetPassword,
      updateProfile,
      getProfile
    }),
    children: children
  });
};
/* harmony default export */ const contexts_JWTContext = (JWTContext);

/***/ }),

/***/ 49684:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var contexts_JWTContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(37762);
 // auth provider
// import AuthContext from 'contexts/Auth0Context';
// import AuthContext from 'contexts/FirebaseContext';

 // import AuthContext from 'contexts/AWSCognitoContext';
// ==============================|| AUTH HOOKS ||============================== //

const useAuth = () => {
  const context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(contexts_JWTContext__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z);
  if (!context) throw new Error('context must be use inside provider');
  return context;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAuth);

/***/ })

};
;