"use strict";
exports.id = 8408;
exports.ids = [8408];
exports.modules = {

/***/ 66832:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(95394);
/* harmony import */ var hooks_useConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20132);
/* harmony import */ var store_slices_kanban__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38617);
/* harmony import */ var chance__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(40306);
/* harmony import */ var chance__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(chance__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_AttachFileTwoTone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(78388);
/* harmony import */ var _mui_icons_material_AttachFileTwoTone__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AttachFileTwoTone__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_AddToDriveTwoTone__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(96069);
/* harmony import */ var _mui_icons_material_AddToDriveTwoTone__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddToDriveTwoTone__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_AddPhotoAlternateTwoTone__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(56387);
/* harmony import */ var _mui_icons_material_AddPhotoAlternateTwoTone__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddPhotoAlternateTwoTone__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var store_slices_snackbar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(12686);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__);
 // material-ui


 // project imports



 // third-party

 // assets







const chance = new chance__WEBPACK_IMPORTED_MODULE_6__.Chance(); // ==============================|| KANBAN BACKLOGS - ADD STORY COMMENT ||============================== //

const AddStoryComment = ({
  storyId
}) => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
  const dispatch = (0,store__WEBPACK_IMPORTED_MODULE_3__/* .useDispatch */ .I0)();
  const {
    borderRadius
  } = (0,hooks_useConfig__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
  const {
    comments,
    userStory
  } = (0,store__WEBPACK_IMPORTED_MODULE_3__/* .useSelector */ .v9)(state => state.kanban);
  const {
    0: comment,
    1: setComment
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: isComment,
    1: setIsComment
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const addNewStoryComment = () => {
    if (comment.length > 0) {
      const newComment = {
        id: `${chance.integer({
          min: 1000,
          max: 9999
        })}`,
        comment,
        profileId: 'profile-1'
      };
      dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_5__/* .addStoryComment */ .mx)(storyId, newComment, comments, userStory));
      dispatch((0,store_slices_snackbar__WEBPACK_IMPORTED_MODULE_10__/* .openSnackbar */ .ss)({
        open: true,
        message: 'Comment Add successfully',
        anchorOrigin: {
          vertical: 'top',
          horizontal: 'right'
        },
        variant: 'alert',
        alert: {
          color: 'success'
        },
        close: false
      }));
      setComment('');
    } else {
      setIsComment(true);
    }
  };

  const handleAddStoryComment = event => {
    if (event.key === 'Enter' || event.keyCode === 13) {
      addNewStoryComment();
    }
  };

  const handleStoryComment = event => {
    const newComment = event.target.value;
    setComment(newComment);

    if (newComment.length <= 0) {
      setIsComment(true);
    } else {
      setIsComment(false);
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
    sx: {
      p: 2.5,
      border: '1px solid',
      borderColor: theme.palette.mode === 'dark' ? theme.palette.background.default : theme.palette.primary[200] + 75,
      borderRadius: `${borderRadius}px`
    },
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
      container: true,
      alignItems: "center",
      spacing: 0.5,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
          fullWidth: true,
          placeholder: "Add Comment",
          value: comment,
          onChange: handleStoryComment,
          sx: {
            mb: 2,
            '& input': {
              bgcolor: 'transparent',
              p: 0,
              borderRadius: '0px'
            },
            '& fieldset': {
              display: 'none'
            },
            '& .MuiFormHelperText-root': {
              ml: 0
            },
            '& .MuiOutlinedInput-root': {
              bgcolor: 'transparent'
            }
          },
          onKeyUp: handleAddStoryComment,
          helperText: isComment ? 'Comment is required.' : '',
          error: isComment
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
          variant: "text",
          color: "primary",
          sx: {
            p: 0.5,
            minWidth: 32
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((_mui_icons_material_AddPhotoAlternateTwoTone__WEBPACK_IMPORTED_MODULE_9___default()), {})
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
          variant: "text",
          color: "primary",
          sx: {
            p: 0.5,
            minWidth: 32
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((_mui_icons_material_AttachFileTwoTone__WEBPACK_IMPORTED_MODULE_7___default()), {})
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
          variant: "text",
          color: "primary",
          sx: {
            p: 0.5,
            minWidth: 32
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((_mui_icons_material_AddToDriveTwoTone__WEBPACK_IMPORTED_MODULE_8___default()), {})
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        xs: true,
        zeroMinWidth: true
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
          variant: "contained",
          color: "primary",
          onClick: addNewStoryComment,
          children: "Comment"
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddStoryComment);

/***/ }),

/***/ 34616:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AlertStoryDelete)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
// material-ui
 // ==============================|| KANBAN BACKLOGS - STORY DELETE ||============================== //




function AlertStoryDelete({
  title,
  open,
  handleClose
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Dialog, {
    open: open,
    onClose: () => handleClose(false),
    keepMounted: true,
    maxWidth: "xs",
    "aria-labelledby": "item-delete-title",
    "aria-describedby": "item-delete-description",
    children: open && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.DialogTitle, {
        id: "item-delete-title",
        children: [title, " - Are you sure you want to delete?"]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.DialogContent, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.DialogContentText, {
          id: "item-delete-description",
          children: "By deleting user story, all task inside that user story will also be deleted."
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.DialogActions, {
        sx: {
          mr: 2
        },
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button, {
          onClick: () => handleClose(false),
          color: "error",
          children: "Cancel"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button, {
          variant: "contained",
          size: "small",
          onClick: () => handleClose(true),
          autoFocus: true,
          children: "Delete"
        })]
      })]
    })
  });
}

/***/ }),

/***/ 79025:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(25675);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_lab_AdapterDateFns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(96715);
/* harmony import */ var _mui_lab_AdapterDateFns__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_AdapterDateFns__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_lab_LocalizationProvider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(89904);
/* harmony import */ var _mui_lab_LocalizationProvider__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_LocalizationProvider__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_lab_DesktopDatePicker__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(60691);
/* harmony import */ var _mui_lab_DesktopDatePicker__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_DesktopDatePicker__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(55162);
/* harmony import */ var react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _AddStoryComment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(66832);
/* harmony import */ var _StoryComment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(58492);
/* harmony import */ var _AlertStoryDelete__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(34616);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(91588);
/* harmony import */ var store_slices_snackbar__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(12686);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(95394);
/* harmony import */ var store_slices_kanban__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(38617);
/* harmony import */ var _mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(26502);
/* harmony import */ var _mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(66380);
/* harmony import */ var _mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_12__]);
components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_12__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


 // material-ui




 // third party



 // project imports








 // assets






const avatarImage = '/assets/images/users';
const validationSchema = yup__WEBPACK_IMPORTED_MODULE_6__.object({
  title: yup__WEBPACK_IMPORTED_MODULE_6__.string().required('User story title is required'),
  dueDate: yup__WEBPACK_IMPORTED_MODULE_6__.date()
}); // ==============================|| KANBAN BACKLOGS - EDIT STORY ||============================== //

const EditStory = ({
  story,
  open,
  handleDrawerOpen
}) => {
  const dispatch = (0,store__WEBPACK_IMPORTED_MODULE_14__/* .useDispatch */ .I0)();
  const kanban = (0,store__WEBPACK_IMPORTED_MODULE_14__/* .useSelector */ .v9)(state => state.kanban);
  const {
    profiles,
    columns,
    comments,
    userStory,
    userStoryOrder
  } = kanban;
  const formik = (0,formik__WEBPACK_IMPORTED_MODULE_8__.useFormik)({
    enableReinitialize: true,
    initialValues: {
      id: story.id,
      title: story.title,
      assign: story.assign,
      columnId: story.columnId,
      priority: story.priority,
      dueDate: story.dueDate ? new Date(story.dueDate) : new Date(),
      acceptance: story.acceptance,
      description: story.description,
      commentIds: story.commentIds,
      image: false,
      itemIds: story.itemIds
    },
    validationSchema,
    onSubmit: values => {
      dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_15__/* .editStory */ .l4)(values, userStory));
      dispatch((0,store_slices_snackbar__WEBPACK_IMPORTED_MODULE_13__/* .openSnackbar */ .ss)({
        open: true,
        message: 'Submit Success',
        variant: 'alert',
        alert: {
          color: 'success'
        },
        close: false
      }));
      handleDrawerOpen();
    }
  });
  const {
    0: openModal,
    1: setOpenModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const handleModalClose = status => {
    setOpenModal(false);

    if (status) {
      handleDrawerOpen();
      dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_15__/* .deleteStory */ .LA)(story.id, userStory, userStoryOrder));
      dispatch((0,store_slices_snackbar__WEBPACK_IMPORTED_MODULE_13__/* .openSnackbar */ .ss)({
        open: true,
        message: 'Story Deleted successfully',
        anchorOrigin: {
          vertical: 'top',
          horizontal: 'right'
        },
        variant: 'alert',
        alert: {
          color: 'success'
        },
        close: false
      }));
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Drawer, {
    sx: {
      ml: open ? 3 : 0,
      flexShrink: 0,
      zIndex: 1200,
      overflowX: 'hidden',
      width: {
        xs: 320,
        md: 450
      },
      '& .MuiDrawer-paper': {
        height: '100vh',
        width: {
          xs: 320,
          md: 450
        },
        position: 'fixed',
        border: 'none',
        borderRadius: '0px'
      }
    },
    variant: "temporary",
    anchor: "right",
    open: open,
    ModalProps: {
      keepMounted: true
    },
    onClose: () => {
      handleDrawerOpen();
      formik.resetForm();
    },
    children: open && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        sx: {
          p: 3
        },
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          container: true,
          alignItems: "center",
          spacing: 0.5,
          justifyContent: "space-between",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            sx: {
              width: 'calc(100% - 50px)'
            },
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
              direction: "row",
              spacing: 0.5,
              alignItems: "center",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "text",
                color: "error",
                sx: {
                  p: 0.5,
                  minWidth: 32,
                  display: {
                    xs: 'block',
                    md: 'none'
                  }
                },
                onClick: handleDrawerOpen,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx((_mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_17___default()), {})
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "h4",
                sx: {
                  display: 'inline-block',
                  width: 'calc(100% - 34px)',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  verticalAlign: 'middle'
                },
                children: story.title
              })]
            })
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
              variant: "text",
              color: "error",
              sx: {
                p: 0.5,
                minWidth: 32
              },
              onClick: () => setOpenModal(true),
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx((_mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_16___default()), {})
            }), openModal && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_AlertStoryDelete__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
              title: story.title,
              open: openModal,
              handleClose: handleModalClose
            })]
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Divider, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx((react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_7___default()), {
        component: "div",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
          sx: {
            p: 3
          },
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            spacing: 2,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: 12,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("form", {
                onSubmit: formik.handleSubmit,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx((_mui_lab_LocalizationProvider__WEBPACK_IMPORTED_MODULE_4___default()), {
                  dateAdapter: (_mui_lab_AdapterDateFns__WEBPACK_IMPORTED_MODULE_3___default()),
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    container: true,
                    spacing: 3,
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                      item: true,
                      xs: 12,
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                        fullWidth: true,
                        id: "title",
                        name: "title",
                        label: "Title",
                        value: formik.values.title,
                        onChange: formik.handleChange,
                        error: formik.touched.title && Boolean(formik.errors.title),
                        helperText: formik.touched.title && formik.errors.title
                      })
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                      item: true,
                      xs: 12,
                      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        alignItems: "center",
                        spacing: 2,
                        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 4,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            variant: "subtitle1",
                            children: "Assign to:"
                          })
                        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 8,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            container: true,
                            justifyContent: "flex-start",
                            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Autocomplete, {
                              id: "assign",
                              value: profiles.find(profile => profile.id === formik.values.assign) || null,
                              onChange: (event, value) => {
                                formik.setFieldValue('assign', value.id);
                              },
                              options: profiles,
                              fullWidth: true,
                              autoHighlight: true,
                              getOptionLabel: option => option.name,
                              isOptionEqualToValue: option => option.id === formik.values.assign,
                              renderOption: (props, option) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, _objectSpread(_objectSpread({
                                component: "li",
                                sx: {
                                  '& > img': {
                                    mr: 2,
                                    flexShrink: 0
                                  }
                                }
                              }, props), {}, {
                                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                  height: "20",
                                  width: "20",
                                  src: `${avatarImage}/${option.avatar}`,
                                  alt: ""
                                }), option.name]
                              })),
                              renderInput: params => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, _objectSpread(_objectSpread({}, params), {}, {
                                label: "Choose a assignee",
                                inputProps: _objectSpread(_objectSpread({}, params.inputProps), {}, {
                                  autoComplete: 'new-password' // disable autocomplete and autofill

                                })
                              }))
                            })
                          })
                        })]
                      })
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                      item: true,
                      xs: 12,
                      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        alignItems: "center",
                        spacing: 2,
                        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 4,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            variant: "subtitle1",
                            children: "Prioritize:"
                          })
                        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 8,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
                            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.RadioGroup, {
                              row: true,
                              "aria-label": "color",
                              value: formik.values.priority,
                              onChange: formik.handleChange,
                              name: "priority",
                              id: "priority",
                              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControlLabel, {
                                value: "low",
                                control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Radio, {
                                  color: "primary",
                                  sx: {
                                    color: 'primary.main'
                                  }
                                }),
                                label: "Low"
                              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControlLabel, {
                                value: "medium",
                                control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Radio, {
                                  color: "warning",
                                  sx: {
                                    color: 'warning.main'
                                  }
                                }),
                                label: "Medium"
                              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControlLabel, {
                                value: "high",
                                control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Radio, {
                                  color: "error",
                                  sx: {
                                    color: 'error.main'
                                  }
                                }),
                                label: "High"
                              })]
                            })
                          })
                        })]
                      })
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                      item: true,
                      xs: 12,
                      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        alignItems: "center",
                        spacing: 2,
                        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 4,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            variant: "subtitle1",
                            children: "Due date:"
                          })
                        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 8,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx((_mui_lab_DesktopDatePicker__WEBPACK_IMPORTED_MODULE_5___default()), {
                            label: "Due Date",
                            value: formik.values.dueDate,
                            inputFormat: "dd/MM/yyyy",
                            onChange: date => {
                              formik.setFieldValue('dueDate', date);
                            },
                            renderInput: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, _objectSpread({
                              fullWidth: true
                            }, props))
                          })
                        })]
                      })
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                      item: true,
                      xs: 12,
                      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        alignItems: "center",
                        spacing: 2,
                        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 4,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            variant: "subtitle1",
                            children: "Acceptance:"
                          })
                        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 8,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                            fullWidth: true,
                            id: "acceptance",
                            name: "acceptance",
                            multiline: true,
                            rows: 3,
                            value: formik.values.acceptance,
                            onChange: formik.handleChange,
                            error: formik.touched.acceptance && Boolean(formik.errors.acceptance),
                            helperText: formik.touched.acceptance && formik.errors.acceptance
                          })
                        })]
                      })
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                      item: true,
                      xs: 12,
                      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        alignItems: "center",
                        spacing: 2,
                        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 4,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            variant: "subtitle1",
                            children: "Description:"
                          })
                        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 8,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                            fullWidth: true,
                            id: "description",
                            name: "description",
                            multiline: true,
                            rows: 3,
                            value: formik.values.description,
                            onChange: formik.handleChange,
                            error: formik.touched.description && Boolean(formik.errors.description),
                            helperText: formik.touched.description && formik.errors.description
                          })
                        })]
                      })
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                      item: true,
                      xs: 12,
                      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        alignItems: "center",
                        spacing: 2,
                        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 4,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            variant: "subtitle1",
                            children: "State:"
                          })
                        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 8,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
                            fullWidth: true,
                            sx: {
                              m: 1
                            },
                            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Select, {
                              id: "columnId",
                              name: "columnId",
                              displayEmpty: true,
                              value: formik.values.columnId,
                              onChange: formik.handleChange,
                              inputProps: {
                                'aria-label': 'Without label'
                              },
                              children: columns.map((column, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                value: column.id,
                                children: column.title
                              }, index))
                            })
                          })
                        })]
                      })
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                      item: true,
                      xs: 12,
                      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        alignItems: "center",
                        spacing: 2,
                        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 4,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            variant: "subtitle1",
                            children: "Attachments:"
                          })
                        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                          item: true,
                          xs: 12,
                          sm: 8
                        })]
                      })
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                      item: true,
                      xs: 12,
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                          fullWidth: true,
                          variant: "contained",
                          type: "submit",
                          children: "Save"
                        })
                      })
                    })]
                  })
                })
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: 12,
              children: story.commentIds && [...story.commentIds].reverse().map((commentId, index) => {
                const commentData = comments.filter(comment => comment.id === commentId)[0];
                const profile = profiles.filter(item => item.id === commentData.profileId)[0];
                return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_StoryComment__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                  comment: commentData,
                  profile: profile
                }, index);
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: 12,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_AddStoryComment__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                storyId: story.id
              })
            })]
          })
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditStory);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 58492:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_ui_component_extended_Avatar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(74202);
/* harmony import */ var _mui_icons_material_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77943);
/* harmony import */ var _mui_icons_material_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
// material-ui

 // project imports

 // assets




const avatarImage = '/assets/images/users'; // ==============================|| KANBAN BACKLOGS - STORY COMMENT ||============================== //

const StoryComment = ({
  comment,
  profile
}) => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, {
    sx: {
      background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.grey[50],
      p: 1.5,
      mt: 1.25
    },
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      container: true,
      spacing: 1,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          container: true,
          wrap: "nowrap",
          alignItems: "center",
          spacing: 1,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_ui_component_extended_Avatar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              sx: {
                width: 24,
                height: 24
              },
              size: "sm",
              alt: "User 1",
              src: profile && profile.avatar && `${avatarImage}/${profile.avatar}`
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: true,
            zeroMinWidth: true,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              container: true,
              alignItems: "center",
              spacing: 1,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  align: "left",
                  variant: "h5",
                  component: "div",
                  children: profile.name
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  align: "left",
                  variant: "caption",
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((_mui_icons_material_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3___default()), {
                    sx: {
                      width: 10,
                      height: 10,
                      opacity: 0.5,
                      my: 0,
                      mx: 0.625
                    }
                  }), profile.time]
                })
              })]
            })
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        sx: {
          '&.MuiGrid-root': {
            pt: 1.5
          }
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          align: "left",
          variant: "body2",
          children: comment.comment
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StoryComment);

/***/ }),

/***/ 61594:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var chance__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(40306);
/* harmony import */ var chance__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(chance__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var hooks_useConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20132);
/* harmony import */ var store_slices_snackbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(12686);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(95394);
/* harmony import */ var store_slices_kanban__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(38617);
/* harmony import */ var _mui_icons_material_AddPhotoAlternateTwoTone__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(56387);
/* harmony import */ var _mui_icons_material_AddPhotoAlternateTwoTone__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddPhotoAlternateTwoTone__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_AttachFileTwoTone__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(78388);
/* harmony import */ var _mui_icons_material_AttachFileTwoTone__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AttachFileTwoTone__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_AddToDriveTwoTone__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(96069);
/* harmony import */ var _mui_icons_material_AddToDriveTwoTone__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddToDriveTwoTone__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__);
 // material-ui


 // third-party

 // project imports




 // assets






const chance = new chance__WEBPACK_IMPORTED_MODULE_3__.Chance(); // ==============================|| KANBAN BOARD - ADD ITEM COMMENT ||============================== //

const AddItemComment = ({
  itemId
}) => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
  const dispatch = (0,store__WEBPACK_IMPORTED_MODULE_6__/* .useDispatch */ .I0)();
  const {
    borderRadius
  } = (0,hooks_useConfig__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
  const {
    comments,
    items
  } = (0,store__WEBPACK_IMPORTED_MODULE_6__/* .useSelector */ .v9)(state => state.kanban);
  const {
    0: comment,
    1: setComment
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: isComment,
    1: setIsComment
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const addTaskComment = () => {
    if (comment.length > 0) {
      const newComment = {
        id: `${chance.integer({
          min: 1000,
          max: 9999
        })}`,
        comment,
        profileId: 'profile-1'
      };
      dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_7__/* .addItemComment */ .$B)(itemId, newComment, items, comments));
      dispatch((0,store_slices_snackbar__WEBPACK_IMPORTED_MODULE_5__/* .openSnackbar */ .ss)({
        open: true,
        message: 'Comment Add successfully',
        anchorOrigin: {
          vertical: 'top',
          horizontal: 'right'
        },
        variant: 'alert',
        alert: {
          color: 'success'
        },
        close: false
      }));
      setComment('');
    } else {
      setIsComment(true);
    }
  };

  const handleAddTaskComment = event => {
    if (event.key === 'Enter' || event.keyCode === 13) {
      addTaskComment();
    }
  };

  const handleTaskComment = event => {
    const newComment = event.target.value;
    setComment(newComment);

    if (newComment.length <= 0) {
      setIsComment(true);
    } else {
      setIsComment(false);
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
    sx: {
      p: 2.5,
      border: '1px solid',
      borderColor: theme.palette.mode === 'dark' ? theme.palette.background.default : theme.palette.primary[200] + 75,
      borderRadius: `${borderRadius}px`
    },
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
      container: true,
      alignItems: "center",
      spacing: 0.5,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
          fullWidth: true,
          placeholder: "Add Comment",
          value: comment,
          onChange: handleTaskComment,
          sx: {
            mb: 2,
            '& input': {
              bgcolor: 'transparent',
              p: 0,
              borderRadius: '0px'
            },
            '& fieldset': {
              display: 'none'
            },
            '& .MuiFormHelperText-root': {
              ml: 0
            },
            '& .MuiOutlinedInput-root': {
              bgcolor: 'transparent'
            }
          },
          onKeyUp: handleAddTaskComment,
          helperText: isComment ? 'Comment is required.' : '',
          error: isComment
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
          variant: "text",
          color: "primary",
          sx: {
            p: 0.5,
            minWidth: 32
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((_mui_icons_material_AddPhotoAlternateTwoTone__WEBPACK_IMPORTED_MODULE_8___default()), {})
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
          variant: "text",
          color: "primary",
          sx: {
            p: 0.5,
            minWidth: 32
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((_mui_icons_material_AttachFileTwoTone__WEBPACK_IMPORTED_MODULE_9___default()), {})
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
          variant: "text",
          color: "primary",
          sx: {
            p: 0.5,
            minWidth: 32
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((_mui_icons_material_AddToDriveTwoTone__WEBPACK_IMPORTED_MODULE_10___default()), {})
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        xs: true,
        zeroMinWidth: true
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
          variant: "contained",
          color: "primary",
          onClick: addTaskComment,
          children: "Comment"
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddItemComment);

/***/ }),

/***/ 25341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AlertItemDelete)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
// material-ui
 // ==============================|| KANBAN BOARD - ITEM DELETE ||============================== //




function AlertItemDelete({
  title,
  open,
  handleClose
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Dialog, {
    open: open,
    onClose: () => handleClose(false),
    keepMounted: true,
    maxWidth: "xs",
    "aria-labelledby": "item-delete-title",
    "aria-describedby": "item-delete-description",
    children: open && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.DialogTitle, {
        id: "item-delete-title",
        children: [title, " - Are you sure you want to delete this item?"]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.DialogActions, {
        sx: {
          mr: 2
        },
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button, {
          onClick: () => handleClose(false),
          color: "error",
          children: "Cancel"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button, {
          variant: "contained",
          size: "small",
          onClick: () => handleClose(true),
          autoFocus: true,
          children: "Delete"
        })]
      })]
    })
  });
}

/***/ }),

/***/ 49477:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25675);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_lab_AdapterDateFns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(96715);
/* harmony import */ var _mui_lab_AdapterDateFns__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_AdapterDateFns__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_lab_LocalizationProvider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(89904);
/* harmony import */ var _mui_lab_LocalizationProvider__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_LocalizationProvider__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_lab_DesktopDatePicker__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(60691);
/* harmony import */ var _mui_lab_DesktopDatePicker__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_DesktopDatePicker__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(91588);
/* harmony import */ var store_slices_snackbar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(12686);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(95394);
/* harmony import */ var store_slices_kanban__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(38617);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__]);
components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // material-ui




 // third-party


 // project imports








const avatarImage = '/assets/images/users';
const validationSchema = yup__WEBPACK_IMPORTED_MODULE_5__.object({
  title: yup__WEBPACK_IMPORTED_MODULE_5__.string().required('Task title is required'),
  dueDate: yup__WEBPACK_IMPORTED_MODULE_5__.date()
}); // ==============================|| KANBAN BOARD - ITEM EDIT ||============================== //

const EditItem = ({
  item,
  profiles,
  userStory,
  columns,
  handleDrawerOpen
}) => {
  const dispatch = (0,store__WEBPACK_IMPORTED_MODULE_9__/* .useDispatch */ .I0)();
  const {
    items
  } = (0,store__WEBPACK_IMPORTED_MODULE_9__/* .useSelector */ .v9)(state => state.kanban);
  const itemUserStory = userStory.filter(story => story.itemIds.filter(itemId => itemId === item.id)[0])[0];
  const itemColumn = columns.filter(column => column.itemIds.filter(itemId => itemId === item.id)[0])[0];
  const formik = (0,formik__WEBPACK_IMPORTED_MODULE_6__.useFormik)({
    enableReinitialize: true,
    initialValues: {
      id: item.id,
      title: item.title,
      assign: item.assign,
      priority: item.priority,
      dueDate: item.dueDate ? new Date(item.dueDate) : new Date(),
      description: item.description,
      commentIds: item.commentIds,
      image: item.image,
      storyId: itemUserStory ? itemUserStory.id : '',
      columnId: itemColumn ? itemColumn.id : '',
      attachments: item.attachments
    },
    validationSchema,
    onSubmit: values => {
      const itemToEdit = {
        id: values.id,
        title: values.title,
        assign: values.assign,
        priority: values.priority,
        dueDate: values.dueDate ? new Date(values.dueDate) : new Date(),
        description: values.description,
        commentIds: values.commentIds,
        image: values.image,
        attachments: values.attachments
      };
      dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_10__/* .editItem */ .Ob)(values.columnId, columns, itemToEdit, items, values.storyId, userStory));
      dispatch((0,store_slices_snackbar__WEBPACK_IMPORTED_MODULE_8__/* .openSnackbar */ .ss)({
        open: true,
        message: 'Submit Success',
        variant: 'alert',
        alert: {
          color: 'success'
        },
        close: false
      }));
      handleDrawerOpen();
    }
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("form", {
    onSubmit: formik.handleSubmit,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((_mui_lab_LocalizationProvider__WEBPACK_IMPORTED_MODULE_3___default()), {
      dateAdapter: (_mui_lab_AdapterDateFns__WEBPACK_IMPORTED_MODULE_2___default()),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        container: true,
        spacing: 3,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, {
            fullWidth: true,
            id: "title",
            name: "title",
            label: "Title",
            value: formik.values.title,
            onChange: formik.handleChange,
            error: formik.touched.title && Boolean(formik.errors.title),
            helperText: formik.touched.title && formik.errors.title
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            container: true,
            alignItems: "center",
            spacing: 2,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 4,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "subtitle1",
                children: "Assign to:"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 8,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                container: true,
                justifyContent: "flex-start",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Autocomplete, {
                  id: "assign",
                  value: profiles.find(profile => profile.id === formik.values.assign),
                  onChange: (event, value) => {
                    formik.setFieldValue('assign', value.id);
                  },
                  options: profiles,
                  fullWidth: true,
                  autoHighlight: true,
                  getOptionLabel: option => option.name,
                  isOptionEqualToValue: option => option.id === formik.values.assign,
                  renderOption: (props, option) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, _objectSpread(_objectSpread({
                    component: "li",
                    sx: {
                      '& > img': {
                        mr: 2,
                        flexShrink: 0
                      }
                    }
                  }, props), {}, {
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__["default"], {
                      loading: "lazy",
                      width: "20",
                      height: "20",
                      src: `${avatarImage}/${option.avatar}`,
                      alt: ""
                    }), option.name]
                  })),
                  renderInput: params => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({}, params), {}, {
                    name: "assign",
                    label: "Choose a assignee",
                    inputProps: _objectSpread(_objectSpread({}, params.inputProps), {}, {
                      autoComplete: 'new-password' // disable autocomplete and autofill

                    })
                  }))
                })
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            container: true,
            alignItems: "center",
            spacing: 2,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 4,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "subtitle1",
                children: "Prioritize:"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 8,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.RadioGroup, {
                  row: true,
                  "aria-label": "color",
                  value: formik.values.priority,
                  onChange: formik.handleChange,
                  name: "priority",
                  id: "priority",
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, {
                    value: "low",
                    control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Radio, {
                      color: "primary",
                      sx: {
                        color: 'primary.main'
                      }
                    }),
                    label: "Low"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, {
                    value: "medium",
                    control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Radio, {
                      color: "warning",
                      sx: {
                        color: 'warning.main'
                      }
                    }),
                    label: "Medium"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, {
                    value: "high",
                    control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Radio, {
                      color: "error",
                      sx: {
                        color: 'error.main'
                      }
                    }),
                    label: "High"
                  })]
                })
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            container: true,
            alignItems: "center",
            spacing: 2,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 4,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "subtitle1",
                children: "Due date:"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 8,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((_mui_lab_DesktopDatePicker__WEBPACK_IMPORTED_MODULE_4___default()), {
                label: "Due Date",
                value: formik.values.dueDate,
                inputFormat: "dd/MM/yyyy",
                onChange: date => {
                  formik.setFieldValue('dueDate', date);
                },
                renderInput: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread({
                  fullWidth: true
                }, props))
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            container: true,
            alignItems: "center",
            spacing: 2,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 4,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "subtitle1",
                children: "Description:"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 8,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, {
                fullWidth: true,
                id: "description",
                name: "description",
                multiline: true,
                rows: 3,
                value: formik.values.description,
                onChange: formik.handleChange,
                error: formik.touched.description && Boolean(formik.errors.description),
                helperText: formik.touched.description && formik.errors.description
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            container: true,
            alignItems: "center",
            spacing: 2,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 4,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "subtitle1",
                children: "User Story:"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 8,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                fullWidth: true,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Select, {
                  id: "storyId",
                  name: "storyId",
                  displayEmpty: true,
                  value: formik.values.storyId,
                  onChange: formik.handleChange,
                  inputProps: {
                    'aria-label': 'Without label'
                  },
                  children: userStory.map((story, index) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, {
                    value: story.id,
                    children: [story.id, " - ", story.title]
                  }, index))
                })
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            container: true,
            alignItems: "center",
            spacing: 2,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 4,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "subtitle1",
                children: "State:"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 8,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                fullWidth: true,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Select, {
                  id: "columnId",
                  name: "columnId",
                  displayEmpty: true,
                  value: formik.values.columnId,
                  onChange: formik.handleChange,
                  inputProps: {
                    'aria-label': 'Without label'
                  },
                  children: columns.map((column, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, {
                    value: column.id,
                    children: column.title
                  }, index))
                })
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            container: true,
            alignItems: "center",
            spacing: 2,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 4,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "subtitle1",
                children: "Attachments:"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              xs: 12,
              sm: 8
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
              fullWidth: true,
              variant: "contained",
              type: "submit",
              children: "Save"
            })
          })
        })]
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditItem);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 43796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_ui_component_extended_Avatar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(74202);
/* harmony import */ var _mui_icons_material_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77943);
/* harmony import */ var _mui_icons_material_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
// material-ui

 // project imports

 // assets




const avatarImage = '/assets/images/users'; // ==============================|| KANBAN BOARD - ITEM COMMENT ||============================== //

const ItemComment = ({
  comment,
  profile
}) => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, {
    sx: {
      background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.grey[50],
      p: 1.5,
      mt: 1.25
    },
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      container: true,
      spacing: 1,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          container: true,
          wrap: "nowrap",
          alignItems: "center",
          spacing: 1,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_ui_component_extended_Avatar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              sx: {
                width: 24,
                height: 24
              },
              size: "sm",
              alt: "User 1",
              src: profile && profile.avatar && `${avatarImage}/${profile.avatar}`
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: true,
            zeroMinWidth: true,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              container: true,
              alignItems: "center",
              spacing: 1,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  align: "left",
                  variant: "h5",
                  component: "div",
                  children: profile.name
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  align: "left",
                  variant: "caption",
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((_mui_icons_material_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3___default()), {
                    sx: {
                      width: 10,
                      height: 10,
                      opacity: 0.5,
                      my: 0,
                      mx: 0.625
                    }
                  }), profile.time]
                })
              })]
            })
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        sx: {
          '&.MuiGrid-root': {
            pt: 1.5
          }
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          align: "left",
          variant: "body2",
          children: comment.comment
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ItemComment);

/***/ }),

/***/ 72211:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(55162);
/* harmony import */ var react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ItemComment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(43796);
/* harmony import */ var _EditItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(49477);
/* harmony import */ var _AddItemComment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(61594);
/* harmony import */ var _AlertItemDelete__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(25341);
/* harmony import */ var store_slices_snackbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(12686);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(95394);
/* harmony import */ var store_slices_kanban__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(38617);
/* harmony import */ var _mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(26502);
/* harmony import */ var _mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(66380);
/* harmony import */ var _mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_EditItem__WEBPACK_IMPORTED_MODULE_4__]);
_EditItem__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
 // material-ui

 // third party

 // project imports







 // assets


 // ==============================|| KANBAN BOARD - ITEM DETAILS ||============================== //





const ItemDetails = () => {
  let selectedData;

  let commentList = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {});

  const dispatch = (0,store__WEBPACK_IMPORTED_MODULE_8__/* .useDispatch */ .I0)();
  const kanban = (0,store__WEBPACK_IMPORTED_MODULE_8__/* .useSelector */ .v9)(state => state.kanban);
  const {
    columns,
    comments,
    profiles,
    items,
    selectedItem,
    userStory
  } = kanban; // drawer

  const {
    0: open,
    1: setOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(selectedItem !== false);

  const handleDrawerOpen = () => {
    setOpen(prevState => !prevState);
    dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_9__/* .selectItem */ .Gh)(false));
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (selectedItem !== false) setOpen(true);
  }, [selectedItem]);

  if (selectedItem !== false) {
    selectedData = items.filter(item => item.id === selectedItem)[0];

    if (selectedData.commentIds) {
      commentList = [...selectedData.commentIds].reverse().map((commentId, index) => {
        const commentData = comments.filter(comment => comment.id === commentId)[0];
        const profile = profiles.filter(item => item.id === commentData.profileId)[0];
        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_ItemComment__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
          comment: commentData,
          profile: profile
        }, index);
      });
    }
  }

  const {
    0: openModal,
    1: setOpenModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const handleModalClose = status => {
    setOpenModal(false);

    if (status) {
      handleDrawerOpen();
      dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_9__/* .deleteItem */ .wz)(selectedData.id, items, columns, userStory));
      dispatch((0,store_slices_snackbar__WEBPACK_IMPORTED_MODULE_7__/* .openSnackbar */ .ss)({
        open: true,
        message: 'Task Deleted successfully',
        anchorOrigin: {
          vertical: 'top',
          horizontal: 'right'
        },
        variant: 'alert',
        alert: {
          color: 'success'
        },
        close: false
      }));
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Drawer, {
    sx: {
      ml: open ? 3 : 0,
      flexShrink: 0,
      zIndex: 1200,
      overflowX: 'hidden',
      width: {
        xs: 320,
        md: 450
      },
      '& .MuiDrawer-paper': {
        height: '100vh',
        width: {
          xs: 320,
          md: 450
        },
        position: 'fixed',
        border: 'none',
        borderRadius: '0px'
      }
    },
    variant: "temporary",
    anchor: "right",
    open: open,
    ModalProps: {
      keepMounted: true
    },
    onClose: handleDrawerOpen,
    children: open && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
      children: [selectedData && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
          sx: {
            p: 3
          },
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            container: true,
            alignItems: "center",
            spacing: 0.5,
            justifyContent: "space-between",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              sx: {
                width: 'calc(100% - 50px)'
              },
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                direction: "row",
                spacing: 0.5,
                alignItems: "center",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                  variant: "text",
                  color: "error",
                  sx: {
                    p: 0.5,
                    minWidth: 32,
                    display: {
                      xs: 'block',
                      md: 'none'
                    }
                  },
                  onClick: handleDrawerOpen,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((_mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_11___default()), {})
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  variant: "h4",
                  sx: {
                    display: 'inline-block',
                    width: 'calc(100% - 34px)',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    verticalAlign: 'middle'
                  },
                  children: selectedData.title
                })]
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                variant: "text",
                color: "error",
                sx: {
                  p: 0.5,
                  minWidth: 32
                },
                onClick: () => setOpenModal(true),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((_mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_10___default()), {})
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_AlertItemDelete__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                title: selectedData.title,
                open: openModal,
                handleClose: handleModalClose
              })]
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_2___default()), {
          component: "div",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
            sx: {
              p: 3
            },
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              container: true,
              spacing: 2,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                xs: 12,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_EditItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                  item: selectedData,
                  profiles: profiles,
                  userStory: userStory,
                  columns: columns,
                  handleDrawerOpen: handleDrawerOpen
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                xs: 12,
                children: commentList
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                item: true,
                xs: 12,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_AddItemComment__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                  itemId: selectedItem
                })
              })]
            })
          })
        })]
      }), !selectedData && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
        justifyContent: "center",
        alignItems: "center",
        sx: {
          height: '100vh'
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          variant: "h5",
          color: "error",
          children: "No item found"
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ItemDetails);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 97001:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var Link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(91931);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var store_slices_kanban__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(38617);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(95394);
/* harmony import */ var store_slices_menu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(22361);
/* harmony import */ var components_ui_component_cards_MainCard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(32107);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



 // material-ui


 // project imports







function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`
  };
} // ==============================|| APPLICATION - KANBAN ||============================== //


function KanbanPage({
  children
}) {
  const dispatch = (0,store__WEBPACK_IMPORTED_MODULE_5__/* .useDispatch */ .I0)();
  const {
    pathname
  } = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  let selectedTab = 0;

  switch (pathname) {
    case '/app/kanban/backlogs':
      selectedTab = 1;
      break;

    case '/app/kanban/board':
    default:
      selectedTab = 0;
  }

  const {
    0: value,
    1: setValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(selectedTab);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    // hide left drawer when email app opens
    dispatch((0,store_slices_menu__WEBPACK_IMPORTED_MODULE_6__/* .openDrawer */ .FJ)(false)); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_4__/* .getItems */ .kk)());
    dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_4__/* .getColumns */ .Pu)());
    dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_4__/* .getColumnsOrder */ .WR)());
    dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_4__/* .getProfiles */ .cp)());
    dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_4__/* .getComments */ .li)());
    dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_4__/* .getUserStory */ .Bh)());
    dispatch((0,store_slices_kanban__WEBPACK_IMPORTED_MODULE_4__/* .getUserStoryOrder */ .Zv)()); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
    sx: {
      display: 'flex'
    },
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
      container: true,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(components_ui_component_cards_MainCard__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
          contentSX: {
            p: 2
          },
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Tabs, {
            value: value,
            variant: "scrollable",
            onChange: handleChange,
            sx: {
              px: 1,
              pb: 2,
              '& a': {
                minWidth: 10,
                px: 1,
                py: 1.5,
                mr: 2.25,
                color: 'grey.600',
                display: 'flex',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center'
              },
              '& a.Mui-selected': {
                color: 'primary.main'
              },
              '& a > svg': {
                marginBottom: '0px !important',
                mr: 1.25
              }
            },
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Tab, _objectSpread({
              sx: {
                textTransform: 'none'
              },
              component: Link__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
              href: "/app/kanban/board",
              label: value === 0 ? 'Board' : 'View as Board'
            }, a11yProps(0))), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Tab, _objectSpread({
              sx: {
                textTransform: 'none'
              },
              component: Link__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
              href: "/app/kanban/backlogs",
              label: value === 1 ? 'Backlogs' : 'View as Backlog'
            }, a11yProps(1)))]
          }), children]
        })
      })
    })
  });
}

KanbanPage.Layout = 'authGuard';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (KanbanPage);

/***/ })

};
;