"use strict";
exports.id = 4443;
exports.ids = [4443];
exports.modules = {

/***/ 67265:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(22278);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(49514);
/* harmony import */ var _mui_icons_material_HighlightOffTwoTone__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9849);
/* harmony import */ var _mui_icons_material_HighlightOffTwoTone__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_HighlightOffTwoTone__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_BusinessTwoTone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(99299);
/* harmony import */ var _mui_icons_material_BusinessTwoTone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_BusinessTwoTone__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_WorkTwoTone__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(82097);
/* harmony import */ var _mui_icons_material_WorkTwoTone__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_WorkTwoTone__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_MailTwoTone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(94018);
/* harmony import */ var _mui_icons_material_MailTwoTone__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_MailTwoTone__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_CallTwoTone__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(47159);
/* harmony import */ var _mui_icons_material_CallTwoTone__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CallTwoTone__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_PinDropTwoTone__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(38273);
/* harmony import */ var _mui_icons_material_PinDropTwoTone__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PinDropTwoTone__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_CakeTwoTone__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(60887);
/* harmony import */ var _mui_icons_material_CakeTwoTone__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CakeTwoTone__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_InfoTwoTone__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(23878);
/* harmony import */ var _mui_icons_material_InfoTwoTone__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_InfoTwoTone__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_ChatBubbleTwoTone__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(53161);
/* harmony import */ var _mui_icons_material_ChatBubbleTwoTone__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ChatBubbleTwoTone__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_icons_material_NotInterestedTwoTone__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(96111);
/* harmony import */ var _mui_icons_material_NotInterestedTwoTone__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_NotInterestedTwoTone__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
const _excluded = ["user", "onClose", "onEditClick"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

 // material-ui


 // project imports


 // assets













const avatarImage = '/assets/images/users';

function ElevationScroll({
  children,
  window
}) {
  const trigger = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useScrollTrigger)({
    disableHysteresis: true,
    threshold: 130,
    target: window || undefined
  });
  return /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.cloneElement)(children, {
    style: {
      position: trigger ? 'fixed' : 'relative',
      top: trigger ? 83 : 0,
      width: trigger ? 318 : '100%'
    }
  });
}

// ==============================|| CONTACT CARD/LIST USER DETAILS ||============================== //
const UserDetails = _ref => {
  let {
    user,
    onClose,
    onEditClick
  } = _ref,
      others = _objectWithoutProperties(_ref, _excluded);

  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
  const avatarProfile = user.avatar && `${avatarImage}/${user.avatar}`;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(ElevationScroll, _objectSpread(_objectSpread({}, others), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      sx: {
        background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.grey[50],
        width: '100%',
        maxWidth: 342
      },
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        container: true,
        spacing: store_constant__WEBPACK_IMPORTED_MODULE_15__/* .gridSpacing */ .dv,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            alignItems: "center",
            spacing: 1,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Avatar, {
                alt: user.name,
                src: avatarProfile,
                sx: {
                  width: 64,
                  height: 64
                }
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: true,
              zeroMinWidth: true,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                container: true,
                spacing: 1,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                  item: true,
                  xs: 12,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                    variant: "h5",
                    component: "div",
                    sx: {
                      fontSize: '1rem'
                    },
                    children: user.name
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                  item: true,
                  xs: 12,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Chip, {
                    label: "Work",
                    sx: {
                      color: theme.palette.primary.main,
                      bgcolor: theme.palette.mode === 'dark' ? theme.palette.dark.dark : theme.palette.primary.light
                    }
                  })
                })]
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                onClick: onClose,
                size: "large",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_mui_icons_material_HighlightOffTwoTone__WEBPACK_IMPORTED_MODULE_4___default()), {})
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            spacing: 1,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: 6,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "outlined",
                fullWidth: true,
                startIcon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_mui_icons_material_ChatBubbleTwoTone__WEBPACK_IMPORTED_MODULE_12___default()), {}),
                onClick: onEditClick,
                children: "Edit"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: 6,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "outlined",
                color: "secondary",
                fullWidth: true,
                startIcon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_mui_icons_material_NotInterestedTwoTone__WEBPACK_IMPORTED_MODULE_13___default()), {}),
                children: "Block"
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Divider, {})
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            spacing: 1,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_mui_icons_material_BusinessTwoTone__WEBPACK_IMPORTED_MODULE_5___default()), {
                sx: {
                  verticalAlign: 'sub',
                  fontSize: '1.125rem',
                  mr: 0.625
                }
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: true,
              zeroMinWidth: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "body2",
                children: user.company
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            spacing: 1,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_mui_icons_material_WorkTwoTone__WEBPACK_IMPORTED_MODULE_6___default()), {
                sx: {
                  verticalAlign: 'sub',
                  fontSize: '1.125rem',
                  mr: 0.625
                }
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: true,
              zeroMinWidth: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "body2",
                children: user.role
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            spacing: 1,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_mui_icons_material_MailTwoTone__WEBPACK_IMPORTED_MODULE_7___default()), {
                sx: {
                  verticalAlign: 'sub',
                  fontSize: '1.125rem',
                  mr: 0.625
                }
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: true,
              zeroMinWidth: true,
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "body2",
                sx: {
                  mb: 0.625
                },
                children: [user.work_email, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                  component: "span",
                  color: "primary",
                  children: "work"
                })]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "body2",
                children: [user.personal_email, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                  component: "span",
                  color: "secondary",
                  children: "Personal"
                })]
              })]
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            spacing: 1,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_mui_icons_material_CallTwoTone__WEBPACK_IMPORTED_MODULE_8___default()), {
                sx: {
                  verticalAlign: 'sub',
                  fontSize: '1.125rem',
                  mr: 0.625
                }
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: true,
              zeroMinWidth: true,
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "body2",
                sx: {
                  mb: 0.625
                },
                children: [user.work_phone, ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                  component: "span",
                  color: "primary",
                  children: "work"
                })]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "body2",
                children: [user.personal_phone, ' ', /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                  component: "span",
                  color: "secondary",
                  children: "Personal"
                })]
              })]
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            spacing: 1,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_mui_icons_material_PinDropTwoTone__WEBPACK_IMPORTED_MODULE_9___default()), {
                sx: {
                  verticalAlign: 'sub',
                  fontSize: '1.125rem',
                  mr: 0.625
                }
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: true,
              zeroMinWidth: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "body2",
                children: user.location
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            spacing: 1,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_mui_icons_material_CakeTwoTone__WEBPACK_IMPORTED_MODULE_10___default()), {
                sx: {
                  verticalAlign: 'sub',
                  fontSize: '1.125rem',
                  mr: 0.625
                }
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: true,
              zeroMinWidth: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "body2",
                children: "November 30, 1997"
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            spacing: 1,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((_mui_icons_material_InfoTwoTone__WEBPACK_IMPORTED_MODULE_11___default()), {
                sx: {
                  verticalAlign: 'sub',
                  fontSize: '1.125rem',
                  mr: 0.625
                }
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              item: true,
              xs: true,
              zeroMinWidth: true,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "body2",
                sx: {
                  mb: 0.625
                },
                children: user.birthdayText
              })
            })]
          })
        })]
      })
    })
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserDetails);

/***/ }),

/***/ 75222:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(55162);
/* harmony import */ var react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22278);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(49514);
/* harmony import */ var _mui_icons_material_HighlightOffTwoTone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9849);
/* harmony import */ var _mui_icons_material_HighlightOffTwoTone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_HighlightOffTwoTone__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_BusinessTwoTone__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99299);
/* harmony import */ var _mui_icons_material_BusinessTwoTone__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_BusinessTwoTone__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_WorkTwoTone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(82097);
/* harmony import */ var _mui_icons_material_WorkTwoTone__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_WorkTwoTone__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_MailTwoTone__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(94018);
/* harmony import */ var _mui_icons_material_MailTwoTone__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_MailTwoTone__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_CallTwoTone__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(47159);
/* harmony import */ var _mui_icons_material_CallTwoTone__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CallTwoTone__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_UploadTwoTone__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(95530);
/* harmony import */ var _mui_icons_material_UploadTwoTone__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_UploadTwoTone__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_ControlPoint__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(81474);
/* harmony import */ var _mui_icons_material_ControlPoint__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ControlPoint__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_TodayTwoTone__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(50460);
/* harmony import */ var _mui_icons_material_TodayTwoTone__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_TodayTwoTone__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__);
const _excluded = ["user", "onCancel", "onSave"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

 // material-ui


 // third-party

 // project imports


 // assets











const User1 = '/assets/images/users/avatar-1.png';
const avatarImage = '/assets/images/users';
const jobTypes = [{
  label: 'Work',
  id: 1
}, {
  label: 'Personal',
  id: 2
}];

function ElevationScroll({
  children,
  window
}) {
  const trigger = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useScrollTrigger)({
    disableHysteresis: true,
    threshold: 130,
    target: window || undefined
  });
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().cloneElement(children, {
    style: {
      position: trigger ? 'fixed' : 'relative',
      top: trigger ? 83 : 0,
      width: trigger ? 318 : '100%'
    }
  });
}

// ==============================|| CONTACT CARD/LIST USER EDIT ||============================== //
const UserEdit = _ref => {
  let {
    user,
    onCancel,
    onSave
  } = _ref,
      others = _objectWithoutProperties(_ref, _excluded);

  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)(); // save user to local state to update details and submit letter

  const {
    0: profile,
    1: setProfile
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(user);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    setProfile(user);
  }, [user]);
  let avatarProfile = User1;

  if (profile) {
    avatarProfile = profile.avatar && `${avatarImage}/${profile.avatar}`;
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(ElevationScroll, _objectSpread(_objectSpread({}, others), {}, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      sx: {
        background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.grey[50],
        width: '100%',
        maxWidth: 342
      },
      content: false,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_3___default()), {
        style: {
          height: 'calc(100vh - 83px)',
          overflowX: 'hidden'
        },
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          container: true,
          spacing: store_constant__WEBPACK_IMPORTED_MODULE_14__/* .gridSpacing */ .dv,
          sx: {
            p: 3
          },
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              container: true,
              alignItems: "center",
              spacing: 1,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Avatar, {
                  alt: "User 3",
                  src: avatarProfile,
                  sx: {
                    width: 64,
                    height: 64
                  }
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                xs: true,
                zeroMinWidth: true,
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                  container: true,
                  spacing: 1,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    xs: 12,
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("label", {
                      htmlFor: "containedButtonFile",
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("input", {
                        accept: "image/*",
                        style: {
                          opacity: 0,
                          position: 'fixed',
                          zIndex: 1,
                          padding: 0.5,
                          cursor: 'pointer'
                        },
                        id: "containedButtonFile",
                        multiple: true,
                        type: "file"
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        variant: "outlined",
                        size: "small",
                        startIcon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_UploadTwoTone__WEBPACK_IMPORTED_MODULE_10___default()), {}),
                        children: "Upload"
                      })]
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    xs: 12,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                      variant: "caption",
                      children: "Image size should be 125kb Max."
                    })
                  })]
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                  onClick: () => onCancel(profile),
                  size: "large",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_HighlightOffTwoTone__WEBPACK_IMPORTED_MODULE_5___default()), {})
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Divider, {})
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
              fullWidth: true,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
                children: "Name"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.OutlinedInput, {
                value: profile.name,
                onChange: e => setProfile(_objectSpread(_objectSpread({}, profile), {}, {
                  name: e.target.value
                })),
                type: "text",
                label: "Name",
                startAdornment: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputAdornment, {
                  position: "start",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_BusinessTwoTone__WEBPACK_IMPORTED_MODULE_6___default()), {})
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
              fullWidth: true,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
                children: "Company"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.OutlinedInput, {
                value: profile.company,
                onChange: e => setProfile(_objectSpread(_objectSpread({}, profile), {}, {
                  company: e.target.value
                })),
                type: "text",
                label: "Company",
                startAdornment: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputAdornment, {
                  position: "start",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_BusinessTwoTone__WEBPACK_IMPORTED_MODULE_6___default()), {})
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
              fullWidth: true,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
                children: "Job Title"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.OutlinedInput, {
                value: profile.role,
                onChange: e => setProfile(_objectSpread(_objectSpread({}, profile), {}, {
                  role: e.target.value
                })),
                type: "text",
                label: "Job Title",
                startAdornment: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputAdornment, {
                  position: "start",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_WorkTwoTone__WEBPACK_IMPORTED_MODULE_7___default()), {})
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Autocomplete, {
              multiple: true,
              options: jobTypes,
              getOptionLabel: option => option.label,
              defaultValue: [jobTypes[0]],
              renderInput: params => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, _objectSpread({}, params))
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
              fullWidth: true,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
                children: "Email"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.OutlinedInput, {
                value: profile.work_email,
                onChange: e => setProfile(_objectSpread(_objectSpread({}, profile), {}, {
                  work_email: e.target.value
                })),
                type: "text",
                label: "Email",
                startAdornment: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputAdornment, {
                  position: "start",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_MailTwoTone__WEBPACK_IMPORTED_MODULE_8___default()), {})
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Autocomplete, {
              multiple: true,
              options: jobTypes,
              getOptionLabel: option => option.label,
              defaultValue: [jobTypes[1]],
              renderInput: params => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, _objectSpread({}, params))
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
              fullWidth: true,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
                children: "Email"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.OutlinedInput, {
                value: profile.personal_email,
                onChange: e => setProfile(_objectSpread(_objectSpread({}, profile), {}, {
                  personal_email: e.target.value
                })),
                type: "text",
                label: "Email",
                startAdornment: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputAdornment, {
                  position: "start",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_MailTwoTone__WEBPACK_IMPORTED_MODULE_8___default()), {})
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
              variant: "text",
              startIcon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_ControlPoint__WEBPACK_IMPORTED_MODULE_11___default()), {}),
              children: "Add New Email"
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Autocomplete, {
              multiple: true,
              options: jobTypes,
              getOptionLabel: option => option.label,
              defaultValue: [jobTypes[0]],
              renderInput: params => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, _objectSpread({}, params))
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
              fullWidth: true,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
                children: "Phone Number"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.OutlinedInput, {
                value: profile.work_phone,
                onChange: e => {
                  setProfile(_objectSpread(_objectSpread({}, profile), {}, {
                    work_phone: e.target.value
                  }));
                },
                type: "text",
                label: "Phone Number",
                startAdornment: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputAdornment, {
                  position: "start",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_CallTwoTone__WEBPACK_IMPORTED_MODULE_9___default()), {})
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Autocomplete, {
              multiple: true,
              options: jobTypes,
              getOptionLabel: option => option.label,
              defaultValue: [jobTypes[1]],
              renderInput: params => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, _objectSpread({}, params))
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
              fullWidth: true,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
                children: "Phone Number"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.OutlinedInput, {
                value: profile.personal_phone,
                onChange: e => {
                  setProfile(_objectSpread(_objectSpread({}, profile), {}, {
                    personal_phone: e.target.value
                  }));
                },
                type: "text",
                label: "Phone Number",
                startAdornment: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputAdornment, {
                  position: "start",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_CallTwoTone__WEBPACK_IMPORTED_MODULE_9___default()), {})
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
              variant: "text",
              startIcon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_ControlPoint__WEBPACK_IMPORTED_MODULE_11___default()), {}),
              children: "Add New Phone"
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
              fullWidth: true,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
                children: "Birthday"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.OutlinedInput, {
                defaultValue: "November 30, 1997",
                type: "text",
                label: "Birthday",
                endAdornment: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputAdornment, {
                  position: "end",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_TodayTwoTone__WEBPACK_IMPORTED_MODULE_12___default()), {})
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
              fullWidth: true,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
                children: "Bio"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.OutlinedInput, {
                defaultValue: profile.birthdayText,
                onChange: e => setProfile(_objectSpread(_objectSpread({}, profile), {}, {
                  birthdayText: e.target.value
                })),
                type: "text",
                label: "Bio",
                multiline: true,
                rows: 3
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              container: true,
              spacing: 1,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                xs: 6,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                  variant: "contained",
                  fullWidth: true,
                  onClick: () => onSave(profile),
                  children: "Save"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                xs: 6,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                  variant: "outlined",
                  fullWidth: true,
                  onClick: () => onCancel(profile),
                  children: "Cancel"
                })
              })]
            })
          })]
        })
      })
    })
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserEdit);

/***/ }),

/***/ 49514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dv": () => (/* binding */ gridSpacing),
/* harmony export */   "RK": () => (/* binding */ drawerWidth),
/* harmony export */   "D2": () => (/* binding */ appDrawerWidth)
/* harmony export */ });
// theme constant
const gridSpacing = 3;
const drawerWidth = 260;
const appDrawerWidth = 320;

/***/ })

};
;