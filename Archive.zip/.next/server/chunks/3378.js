"use strict";
exports.id = 3378;
exports.ids = [3378];
exports.modules = {

/***/ 23378:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Chip__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(58369);
/* harmony import */ var _mui_material_Chip__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Chip__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
const _excluded = ["chipcolor", "disabled", "sx", "variant"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

// material-ui

 // ==============================|| CHIP ||============================== //



const Chip = _ref => {
  let {
    chipcolor,
    disabled,
    sx = {},
    variant
  } = _ref,
      others = _objectWithoutProperties(_ref, _excluded);

  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  let defaultSX = {
    color: theme.palette.mode === 'dark' ? theme.palette.primary.light : theme.palette.primary.main,
    bgcolor: theme.palette.mode === 'dark' ? theme.palette.primary.main : theme.palette.primary.light,
    ':hover': {
      color: theme.palette.primary.light,
      bgcolor: theme.palette.mode === 'dark' ? theme.palette.primary.dark + 90 : theme.palette.primary.dark
    }
  };
  let outlineSX = {
    color: theme.palette.primary.main,
    bgcolor: 'transparent',
    border: '1px solid',
    borderColor: theme.palette.primary.main,
    ':hover': {
      color: theme.palette.mode === 'dark' ? theme.palette.primary.light : theme.palette.primary.light,
      bgcolor: theme.palette.mode === 'dark' ? theme.palette.primary.main : theme.palette.primary.dark
    }
  };

  switch (chipcolor) {
    case 'secondary':
      if (variant === 'outlined') {
        outlineSX = {
          color: theme.palette.secondary.main,
          bgcolor: 'transparent',
          border: '1px solid',
          borderColor: theme.palette.secondary.main,
          ':hover': {
            color: theme.palette.mode === 'dark' ? theme.palette.secondary.light : theme.palette.secondary.main,
            bgcolor: theme.palette.mode === 'dark' ? theme.palette.secondary.dark : theme.palette.secondary.light
          }
        };
      } else {
        defaultSX = {
          color: theme.palette.mode === 'dark' ? theme.palette.secondary.light : theme.palette.secondary.main,
          bgcolor: theme.palette.mode === 'dark' ? theme.palette.secondary.dark : theme.palette.secondary.light,
          ':hover': {
            color: theme.palette.secondary.light,
            bgcolor: theme.palette.mode === 'dark' ? theme.palette.secondary.dark + 90 : theme.palette.secondary.main
          }
        };
      }

      break;

    case 'success':
      if (variant === 'outlined') {
        outlineSX = {
          color: theme.palette.success.dark,
          bgcolor: 'transparent',
          border: '1px solid',
          borderColor: theme.palette.success.dark,
          ':hover': {
            color: theme.palette.mode === 'dark' ? theme.palette.success.light : theme.palette.success.dark,
            bgcolor: theme.palette.mode === 'dark' ? theme.palette.success.dark : theme.palette.success.light + 60
          }
        };
      } else {
        defaultSX = {
          color: theme.palette.mode === 'dark' ? theme.palette.success.light : theme.palette.success.dark,
          bgcolor: theme.palette.mode === 'dark' ? theme.palette.success.dark : theme.palette.success.light + 60,
          ':hover': {
            color: theme.palette.success.light,
            bgcolor: theme.palette.mode === 'dark' ? theme.palette.success.dark + 90 : theme.palette.success.dark
          }
        };
      }

      break;

    case 'error':
      if (variant === 'outlined') {
        outlineSX = {
          color: theme.palette.error.main,
          bgcolor: 'transparent',
          border: '1px solid',
          borderColor: theme.palette.error.main,
          ':hover': {
            color: theme.palette.mode === 'dark' ? theme.palette.error.light : theme.palette.error.dark,
            bgcolor: theme.palette.mode === 'dark' ? theme.palette.error.dark : theme.palette.error.light
          }
        };
      } else {
        defaultSX = {
          color: theme.palette.mode === 'dark' ? theme.palette.error.light : theme.palette.error.dark,
          bgcolor: theme.palette.mode === 'dark' ? theme.palette.error.dark : theme.palette.error.light + 60,
          ':hover': {
            color: theme.palette.error.light,
            bgcolor: theme.palette.mode === 'dark' ? theme.palette.error.dark + 90 : theme.palette.error.dark
          }
        };
      }

      break;

    case 'orange':
      if (variant === 'outlined') {
        outlineSX = {
          color: theme.palette.orange.dark,
          bgcolor: 'transparent',
          border: '1px solid',
          borderColor: theme.palette.orange.main,
          ':hover': {
            color: theme.palette.orange.dark,
            bgcolor: theme.palette.orange.light
          }
        };
      } else {
        defaultSX = {
          color: theme.palette.orange.dark,
          bgcolor: theme.palette.orange.light,
          ':hover': {
            color: theme.palette.orange.light,
            bgcolor: theme.palette.orange.dark
          }
        };
      }

      break;

    case 'warning':
      if (variant === 'outlined') {
        outlineSX = {
          color: theme.palette.warning.dark,
          bgcolor: 'transparent',
          border: '1px solid',
          borderColor: theme.palette.warning.dark,
          ':hover': {
            color: theme.palette.warning.dark,
            bgcolor: theme.palette.warning.light
          }
        };
      } else {
        defaultSX = {
          color: theme.palette.warning.dark,
          bgcolor: theme.palette.warning.light,
          ':hover': {
            color: theme.palette.warning.light,
            bgcolor: theme.palette.mode === 'dark' ? theme.palette.warning.dark + 90 : theme.palette.warning.dark
          }
        };
      }

      break;

    default:
  }

  if (disabled) {
    if (variant === 'outlined') {
      outlineSX = {
        color: theme.palette.grey[500],
        bgcolor: 'transparent',
        border: '1px solid',
        borderColor: theme.palette.grey[500],
        ':hover': {
          color: theme.palette.grey[500],
          bgcolor: 'transparent'
        }
      };
    } else {
      defaultSX = {
        color: theme.palette.grey[500],
        bgcolor: theme.palette.grey[50],
        ':hover': {
          color: theme.palette.grey[500],
          bgcolor: theme.palette.grey[50]
        }
      };
    }
  }

  let SX = defaultSX;

  if (variant === 'outlined') {
    SX = outlineSX;
  }

  SX = _objectSpread(_objectSpread({}, SX), sx);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx((_mui_material_Chip__WEBPACK_IMPORTED_MODULE_1___default()), _objectSpread(_objectSpread({}, others), {}, {
    sx: SX
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Chip);

/***/ })

};
;