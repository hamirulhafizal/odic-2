"use strict";
exports.id = 1931;
exports.ids = [1931];
exports.modules = {

/***/ 91931:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ src_Link)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(71853);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(41664);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(18442);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
;// CONCATENATED MODULE: ./src/NextLinkComposed.js
const _excluded = ["to", "linkAs", "replace", "scroll", "shallow", "prefetch", "locale"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


 // next imports

 // M-UI

 // =============================|| Next Link Component ||============================= //


const Anchor = (0,styles_.styled)('a')({});
const NextLinkComposed = /*#__PURE__*/external_react_.forwardRef((_ref, ref) => {
  let {
    to,
    linkAs,
    replace,
    scroll,
    shallow,
    prefetch,
    locale
  } = _ref,
      other = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: to,
    prefetch: prefetch,
    as: linkAs,
    replace: replace,
    scroll: scroll,
    shallow: shallow,
    passHref: true,
    locale: locale,
    children: /*#__PURE__*/jsx_runtime_.jsx(Anchor, _objectSpread({
      ref: ref
    }, other))
  });
});
NextLinkComposed.propTypes = {
  to: (external_prop_types_default()).string,
  linkAs: (external_prop_types_default()).func,
  replace: (external_prop_types_default()).func,
  scroll: (external_prop_types_default()).func,
  shallow: (external_prop_types_default()).func,
  prefetch: (external_prop_types_default()).func,
  locale: (external_prop_types_default()).string
};
/* harmony default export */ const src_NextLinkComposed = (NextLinkComposed);
// EXTERNAL MODULE: external "@mui/material/Link"
var Link_ = __webpack_require__(85246);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link_);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(68103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
;// CONCATENATED MODULE: ./src/Link.js
const Link_excluded = ["activeClassName", "as", "className", "href", "noLinkStyle"];

function Link_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Link_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Link_ownKeys(Object(source), true).forEach(function (key) { Link_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Link_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Link_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function Link_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = Link_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function Link_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

 // next imports


 // M-UI


 // other

 // =============================|| Custom Link Component ||============================= //


const Link_Anchor = (0,styles_.styled)('a')({});
const Link = /*#__PURE__*/external_react_.forwardRef((_ref, ref) => {
  let {
    activeClassName = 'active',
    as: linkAs,
    className: classNameProps,
    href,
    noLinkStyle
  } = _ref,
      other = Link_objectWithoutProperties(_ref, Link_excluded);

  const router = (0,router_.useRouter)();
  const pathname = typeof href === 'string' ? href : href.pathname;
  const className = external_clsx_default()(classNameProps, {
    [activeClassName]: router.pathname === pathname && activeClassName
  });
  const isExternal = typeof href === 'string' && (href.indexOf('http') === 0 || href.indexOf('mailto:') === 0);

  if (isExternal) {
    if (noLinkStyle) {
      return /*#__PURE__*/jsx_runtime_.jsx(Link_Anchor, Link_objectSpread({
        className: className,
        href: href,
        ref: ref
      }, other));
    }

    return /*#__PURE__*/jsx_runtime_.jsx((Link_default()), Link_objectSpread({
      className: className,
      href: href,
      ref: ref
    }, other));
  }

  if (noLinkStyle) {
    return /*#__PURE__*/jsx_runtime_.jsx(src_NextLinkComposed, Link_objectSpread({
      className: className,
      ref: ref,
      to: href
    }, other));
  }

  return /*#__PURE__*/jsx_runtime_.jsx((Link_default()), Link_objectSpread({
    component: src_NextLinkComposed,
    linkAs: linkAs,
    className: className,
    ref: ref,
    to: href
  }, other));
});
/* harmony default export */ const src_Link = (Link);

/***/ })

};
;