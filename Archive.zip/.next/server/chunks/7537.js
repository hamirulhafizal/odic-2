"use strict";
exports.id = 7537;
exports.ids = [7537];
exports.modules = {

/***/ 85947:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_MoreHorizOutlined__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(46222);
/* harmony import */ var _mui_icons_material_MoreHorizOutlined__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_MoreHorizOutlined__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_PersonAddTwoTone__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(17003);
/* harmony import */ var _mui_icons_material_PersonAddTwoTone__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PersonAddTwoTone__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_PeopleAltTwoTone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8245);
/* harmony import */ var _mui_icons_material_PeopleAltTwoTone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PeopleAltTwoTone__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_PinDropTwoTone__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(38273);
/* harmony import */ var _mui_icons_material_PinDropTwoTone__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PinDropTwoTone__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_FavoriteTwoTone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(66979);
/* harmony import */ var _mui_icons_material_FavoriteTwoTone__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FavoriteTwoTone__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(26502);
/* harmony import */ var _mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_GroupTwoTone__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(40527);
/* harmony import */ var _mui_icons_material_GroupTwoTone__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_GroupTwoTone__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);
 // material-ui


 // assets







 // ==============================|| SOCIAL PROFILE - FOLLOWER CARD ||============================== //




const FollowerCard = ({
  avatar,
  follow,
  location,
  name
}) => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
  const avatarImage = `/assets/images/profile/${avatar}`;
  const {
    0: anchorEl,
    1: setAnchorEl
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Card, {
    sx: {
      padding: '16px',
      background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.grey[50],
      border: '1px solid',
      borderColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.grey[100],
      '&:hover': {
        border: `1px solid${theme.palette.primary.main}`
      }
    },
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
      container: true,
      spacing: 2,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          container: true,
          spacing: 2,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Avatar, {
              alt: "User 1",
              src: avatarImage
            })
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: true,
            zeroMinWidth: true,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
              variant: "h5",
              component: "div",
              sx: {
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                display: 'block'
              },
              children: name
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
              variant: "subtitle2",
              sx: {
                mt: 0.25,
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                display: 'block'
              },
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_PinDropTwoTone__WEBPACK_IMPORTED_MODULE_6___default()), {
                sx: {
                  mr: '6px',
                  fontSize: '16px',
                  verticalAlign: 'text-top'
                }
              }), location]
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_MoreHorizOutlined__WEBPACK_IMPORTED_MODULE_3___default()), {
              fontSize: "small",
              sx: {
                color: theme.palette.primary[200],
                cursor: 'pointer'
              },
              "aria-controls": "menu-followers-card",
              "aria-haspopup": "true",
              onClick: handleClick
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Menu, {
              id: "menu-followers-card",
              anchorEl: anchorEl,
              keepMounted: true,
              open: Boolean(anchorEl),
              onClose: handleClose,
              variant: "selectedMenu",
              anchorOrigin: {
                vertical: 'bottom',
                horizontal: 'right'
              },
              transformOrigin: {
                vertical: 'top',
                horizontal: 'right'
              },
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                onClick: handleClose,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemIcon, {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_FavoriteTwoTone__WEBPACK_IMPORTED_MODULE_7___default()), {
                    fontSize: "small"
                  })
                }), "Favorites"]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                onClick: handleClose,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemIcon, {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_GroupTwoTone__WEBPACK_IMPORTED_MODULE_9___default()), {
                    fontSize: "small"
                  })
                }), "Edit Friend List"]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                onClick: handleClose,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemIcon, {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_8___default()), {
                    fontSize: "small"
                  })
                }), "Removed"]
              })]
            })]
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        xs: 12,
        children: follow === 2 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
          variant: "contained",
          fullWidth: true,
          startIcon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_PersonAddTwoTone__WEBPACK_IMPORTED_MODULE_4___default()), {}),
          children: "Follow Back"
        }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
          variant: "outlined",
          fullWidth: true,
          startIcon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_PeopleAltTwoTone__WEBPACK_IMPORTED_MODULE_5___default()), {}),
          children: "Followed"
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FollowerCard);

/***/ }),

/***/ 6701:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(49514);
/* harmony import */ var _mui_icons_material_MoreHorizOutlined__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(46222);
/* harmony import */ var _mui_icons_material_MoreHorizOutlined__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_MoreHorizOutlined__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_PinDropTwoTone__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(38273);
/* harmony import */ var _mui_icons_material_PinDropTwoTone__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PinDropTwoTone__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_VideoCallTwoTone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(77184);
/* harmony import */ var _mui_icons_material_VideoCallTwoTone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_VideoCallTwoTone__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_ChatBubbleTwoTone__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(53161);
/* harmony import */ var _mui_icons_material_ChatBubbleTwoTone__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ChatBubbleTwoTone__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_FavoriteTwoTone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(66979);
/* harmony import */ var _mui_icons_material_FavoriteTwoTone__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FavoriteTwoTone__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(26502);
/* harmony import */ var _mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_GroupTwoTone__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(40527);
/* harmony import */ var _mui_icons_material_GroupTwoTone__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_GroupTwoTone__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);
 // material-ui


 // project imports

 // assets










const avatarImage = '/assets/images/profile'; // ==============================|| SOCIAL PROFILE - FRIENDS CARD ||============================== //

const FriendsCard = ({
  avatar,
  location,
  name
}) => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
  const avatarProfile = avatar && `${avatarImage}/${avatar}`;
  const btnSX = {
    borderColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.grey[200],
    background: theme.palette.mode === 'dark' ? theme.palette.dark.dark : theme.palette.background.paper
  };
  const {
    0: anchorEl,
    1: setAnchorEl
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Card, {
    sx: {
      p: 2,
      background: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.grey[50],
      border: '1px solid',
      borderColor: theme.palette.mode === 'dark' ? theme.palette.dark.main : theme.palette.grey[100],
      '&:hover': {
        border: `1px solid${theme.palette.primary.main}`
      }
    },
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
      container: true,
      spacing: 2,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          container: true,
          spacing: store_constant__WEBPACK_IMPORTED_MODULE_11__/* .gridSpacing */ .dv,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Avatar, {
              alt: "User 1",
              src: avatarProfile
            })
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: true,
            zeroMinWidth: true,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
              variant: "h5",
              sx: {
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                display: 'block'
              },
              children: name
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
              variant: "subtitle2",
              sx: {
                mt: 0.5,
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                display: 'block'
              },
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_PinDropTwoTone__WEBPACK_IMPORTED_MODULE_4___default()), {
                fontSize: "inherit",
                sx: {
                  mr: 0.5,
                  fontSize: '0.875rem',
                  verticalAlign: 'text-top'
                }
              }), location]
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
              size: "small",
              onClick: handleClick,
              sx: {
                mt: -0.75,
                mr: -0.75
              },
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_MoreHorizOutlined__WEBPACK_IMPORTED_MODULE_3___default()), {
                fontSize: "small",
                color: "primary",
                "aria-controls": "menu-friend-card",
                "aria-haspopup": "true",
                sx: {
                  opacity: 0.6
                }
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Menu, {
              id: "menu-friend-card",
              anchorEl: anchorEl,
              keepMounted: true,
              open: Boolean(anchorEl),
              onClose: handleClose,
              variant: "selectedMenu",
              anchorOrigin: {
                vertical: 'bottom',
                horizontal: 'right'
              },
              transformOrigin: {
                vertical: 'top',
                horizontal: 'right'
              },
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                onClick: handleClose,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemIcon, {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_FavoriteTwoTone__WEBPACK_IMPORTED_MODULE_7___default()), {
                    fontSize: "small"
                  })
                }), "Favorites"]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                onClick: handleClose,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemIcon, {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_GroupTwoTone__WEBPACK_IMPORTED_MODULE_9___default()), {
                    fontSize: "small"
                  })
                }), "Edit Friend List"]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                onClick: handleClose,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemIcon, {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_DeleteTwoTone__WEBPACK_IMPORTED_MODULE_8___default()), {
                    fontSize: "small"
                  })
                }), "Unfriend"]
              })]
            })]
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          container: true,
          spacing: 1,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
              title: "Video Call",
              placement: "top",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "outlined",
                color: "secondary",
                fullWidth: true,
                sx: btnSX,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_VideoCallTwoTone__WEBPACK_IMPORTED_MODULE_5___default()), {
                  fontSize: "small"
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 6,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
              title: "Message",
              placement: "top",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                variant: "outlined",
                fullWidth: true,
                sx: btnSX,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx((_mui_icons_material_ChatBubbleTwoTone__WEBPACK_IMPORTED_MODULE_6___default()), {
                  fontSize: "small"
                })
              })
            })
          })]
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FriendsCard);

/***/ }),

/***/ 49514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dv": () => (/* binding */ gridSpacing),
/* harmony export */   "RK": () => (/* binding */ drawerWidth),
/* harmony export */   "D2": () => (/* binding */ appDrawerWidth)
/* harmony export */ });
// theme constant
const gridSpacing = 3;
const drawerWidth = 260;
const appDrawerWidth = 320;

/***/ })

};
;