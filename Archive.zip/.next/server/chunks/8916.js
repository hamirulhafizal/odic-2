"use strict";
exports.id = 8916;
exports.ids = [8916];
exports.modules = {

/***/ 32152:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
 // material-ui


 // ==============================|| FORM CONTROL SELECT ||============================== //




const FormControlSelect = ({
  idz,
  namez,
  captionLabel,
  value,
  onChange,
  fullWidth,
  error,
  helperText,
  currencies,
  formState,
  iconPrimary,
  iconSecondary,
  selected,
  textPrimary,
  textSecondary
}) => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
  const IconPrimary = iconPrimary;
  const primaryIcon = iconPrimary ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(IconPrimary, {
    fontSize: "small",
    sx: {
      color: theme.palette.grey[700]
    }
  }) : null;
  const IconSecondary = iconSecondary;
  const secondaryIcon = iconSecondary ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(IconSecondary, {
    fontSize: "small",
    sx: {
      color: theme.palette.grey[700]
    }
  }) : null;
  const errorState = formState === 'error';
  const val = selected || '';
  const {
    0: currency,
    1: setCurrency
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(val);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
    fullWidth: true,
    error: errorState,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
      id: "demo-simple-select-label",
      children: "Category"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Select, {
      id: idz,
      value: value || '',
      name: namez,
      label: captionLabel,
      onChange: onChange,
      children: currencies.map((state, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
        value: state === null || state === void 0 ? void 0 : state.label,
        children: state === null || state === void 0 ? void 0 : state.label
      }, index))
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormControlSelect);

/***/ }),

/***/ 49514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dv": () => (/* binding */ gridSpacing),
/* harmony export */   "RK": () => (/* binding */ drawerWidth),
/* harmony export */   "D2": () => (/* binding */ appDrawerWidth)
/* harmony export */ });
// theme constant
const gridSpacing = 3;
const drawerWidth = 260;
const appDrawerWidth = 320;

/***/ })

};
;