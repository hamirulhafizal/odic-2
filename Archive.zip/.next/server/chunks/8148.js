"use strict";
exports.id = 8148;
exports.ids = [8148];
exports.modules = {

/***/ 88148:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _extended_Avatar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(74202);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
// material-ui

 // project imports

 // ==============================|| CARD SECONDARY ACTION ||============================== //




const CardSecondaryAction = ({
  title,
  link,
  icon
}) => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, {
    title: title || 'Reference',
    placement: "left",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ButtonBase, {
      disableRipple: true,
      children: [!icon && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_extended_Avatar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        component: _mui_material__WEBPACK_IMPORTED_MODULE_1__.Link,
        href: link,
        target: "_blank",
        alt: "MUI Logo",
        size: "badge",
        color: "primary",
        outline: true,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("svg", {
          width: "500",
          height: "500",
          viewBox: "0 0 500 500",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("g", {
            clipPath: "url(#clip0)",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
              d: "M100 260.9V131L212.5 195.95V239.25L137.5 195.95V282.55L100 260.9Z",
              fill: theme.palette.primary[800]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
              d: "M212.5 195.95L325 131V260.9L250 304.2L212.5 282.55L287.5 239.25V195.95L212.5 239.25V195.95Z",
              fill: theme.palette.primary.main
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
              d: "M212.5 282.55V325.85L287.5 369.15V325.85L212.5 282.55Z",
              fill: theme.palette.primary[800]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("path", {
              d: "M287.5 369.15L400 304.2V217.6L362.5 239.25V282.55L287.5 325.85V369.15ZM362.5 195.95V152.65L400 131V174.3L362.5 195.95Z",
              fill: theme.palette.primary.main
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("defs", {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("clipPath", {
              id: "clip0",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("rect", {
                width: "300",
                height: "238.3",
                fill: "white",
                transform: "translate(100 131)"
              })
            })
          })]
        })
      }), icon && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_extended_Avatar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        component: _mui_material__WEBPACK_IMPORTED_MODULE_1__.Link,
        href: link,
        target: "_blank",
        size: "badge",
        color: "primary",
        outline: true,
        children: icon
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardSecondaryAction);

/***/ })

};
;