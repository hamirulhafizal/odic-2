"use strict";
exports.id = 8033;
exports.ids = [8033];
exports.modules = {

/***/ 78033:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_otp_input_rc_17__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(78939);
/* harmony import */ var react_otp_input_rc_17__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_otp_input_rc_17__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
 // material-ui


 // third-party

 // ============================|| STATIC - CODE VERIFICATION ||============================ //




const AuthCodeVerification = () => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
  const {
    0: otp,
    1: setOtp
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const borderColor = theme.palette.mode === 'dark' ? theme.palette.grey[200] : theme.palette.grey[300];
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
    container: true,
    spacing: 3,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
      item: true,
      xs: 12,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((react_otp_input_rc_17__WEBPACK_IMPORTED_MODULE_3___default()), {
        value: otp,
        onChange: otpNumber => setOtp(otpNumber),
        numInputs: 4,
        containerStyle: {
          justifyContent: 'space-between'
        },
        inputStyle: {
          width: '100%',
          margin: '8px',
          padding: '10px',
          border: `1px solid ${borderColor}`,
          borderRadius: 4,
          ':hover': {
            borderColor: theme.palette.primary.main
          }
        },
        focusStyle: {
          outline: 'none',
          border: `2px solid ${theme.palette.primary.main}`
        }
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
      item: true,
      xs: 12,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
        disableElevation: true,
        fullWidth: true,
        size: "large",
        type: "submit",
        variant: "contained",
        children: "Continue"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
      item: true,
      xs: 12,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
        direction: "row",
        justifyContent: "space-between",
        alignItems: "baseline",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
          children: "Did not receive the email? Check your spam filter, or"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
          variant: "body1",
          sx: {
            minWidth: 85,
            ml: 2,
            textDecoration: 'none',
            cursor: 'pointer'
          },
          color: "primary",
          children: "Resend code"
        })]
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthCodeVerification);

/***/ })

};
;