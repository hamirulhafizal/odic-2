"use strict";
exports.id = 7725;
exports.ids = [7725];
exports.modules = {

/***/ 7725:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var Link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(91931);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7878);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91588);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(49514);
/* harmony import */ var _mui_icons_material_HomeTwoTone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(76942);
/* harmony import */ var _mui_icons_material_HomeTwoTone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_HomeTwoTone__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_4__]);
components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
 // material-ui


 // project imports



 // assets




const imageBackground = '/assets/images/maintenance/img-error-bg.svg';
const imageDarkBackground = '/assets/images/maintenance/img-error-bg-dark.svg';
const imageBlue = '/assets/images/maintenance/img-error-blue.svg';
const imageText = '/assets/images/maintenance/img-error-text.svg';
const imagePurple = '/assets/images/maintenance/img-error-purple.svg'; // styles

const CardMediaWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.styled)('div')({
  maxWidth: 720,
  margin: '0 auto',
  position: 'relative'
});
const ErrorWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.styled)('div')({
  maxWidth: 350,
  margin: '0 auto',
  textAlign: 'center'
});
const ErrorCard = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Card)({
  minHeight: '100vh',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center'
});
const CardMediaBlock = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.styled)('img')({
  position: 'absolute',
  top: 0,
  left: 0,
  width: '100%',
  animation: '3s bounce ease-in-out infinite'
});
const CardMediaBlue = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.styled)('img')({
  position: 'absolute',
  top: 0,
  left: 0,
  width: '100%',
  animation: '15s wings ease-in-out infinite'
});
const CardMediaPurple = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.styled)('img')({
  position: 'absolute',
  top: 0,
  left: 0,
  width: '100%',
  animation: '12s wings ease-in-out infinite'
}); // ==============================|| ERROR PAGE ||============================== //

const Error = id => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(ErrorCard, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CardContent, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        container: true,
        justifyContent: "center",
        spacing: store_constant__WEBPACK_IMPORTED_MODULE_7__/* .gridSpacing */ .dv,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(CardMediaWrapper, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CardMedia, {
              component: "img",
              image: theme.palette.mode === 'dark' ? imageDarkBackground : imageBackground,
              title: "Slider5 image"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(CardMediaBlock, {
              src: imageText,
              title: "Slider 1 image"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(CardMediaBlue, {
              src: imageBlue,
              title: "Slider 2 image"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(CardMediaPurple, {
              src: imagePurple,
              title: "Slider 3 image"
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(ErrorWrapper, {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
              container: true,
              spacing: store_constant__WEBPACK_IMPORTED_MODULE_7__/* .gridSpacing */ .dv,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                xs: 12,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                  variant: "h1",
                  component: "div",
                  children: id === 'userNotFound' ? 'User Not Found' : 'Something is wrong'
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                xs: 12,
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                  variant: "body2",
                  children: ["The ", id === 'userNotFound' ? 'user not found ' : 'page ', " you are looking was moved, removed, renamed, or might never exist!"]
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                xs: 12,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                    variant: "contained",
                    size: "large",
                    component: Link__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z,
                    href: config__WEBPACK_IMPORTED_MODULE_3__/* .DASHBOARD_PATH */ .tu,
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx((_mui_icons_material_HomeTwoTone__WEBPACK_IMPORTED_MODULE_5___default()), {
                      sx: {
                        fontSize: '1.3rem',
                        mr: 0.75
                      }
                    }), " Home"]
                  })
                })
              })]
            })
          })
        })]
      })
    })
  });
};

Error.Layout = 'minimalLayout';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Error);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;