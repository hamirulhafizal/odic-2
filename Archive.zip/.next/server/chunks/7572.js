"use strict";
exports.id = 7572;
exports.ids = [7572];
exports.modules = {

/***/ 58190:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91588);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_ui_component_extended_Form_FormControlSelect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(32152);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_1__]);
components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// material-ui
 // project imports

 // third-party







const type = [{
  value: '1',
  label: 'Rent'
}, {
  value: '2',
  label: 'Sales'
}, {
  value: '3',
  label: 'Short Stay'
}];
const propertyTypes = [{
  value: '0',
  label: 'Apartment'
}, {
  value: '1',
  label: 'Landed House'
}, {
  value: '2',
  label: 'Private Room'
}, {
  value: '3',
  label: 'Factory'
}, {
  value: '4',
  label: 'Office'
}, {
  value: '5',
  label: 'Hotel/Resort'
}, {
  value: '6',
  label: 'ShopLot'
}, {
  value: '7',
  label: 'Land'
}];
const validationSchema = yup__WEBPACK_IMPORTED_MODULE_3__.object({
  firstName: yup__WEBPACK_IMPORTED_MODULE_3__.string().required('First Name is required'),
  lastName: yup__WEBPACK_IMPORTED_MODULE_3__.string().required('Last Name is required')
}); // ==============================|| FORM WIZARD - VALIDATION  ||============================== //

const AddressForm = ({
  shippingData,
  setShippingData,
  handleNext,
  setErrorIndex
}) => {
  const formik = (0,formik__WEBPACK_IMPORTED_MODULE_2__.useFormik)({
    initialValues: {
      firstName: 'hamirul',
      lastName: 'hafizal',
      category: 'Rent',
      propertyType: 'Office'
    },
    validationSchema,
    onSubmit: values => {
      setShippingData({
        firstName: values.firstName,
        lastName: values.lastName,
        category: values.category,
        propertyType: values.propertyType
      });
      handleNext();
    }
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
      variant: "h5",
      gutterBottom: true,
      sx: {
        mb: 2
      },
      children: "Create Listing"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("form", {
      onSubmit: formik.handleSubmit,
      id: "validation-forms",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
        container: true,
        spacing: 3,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          item: true,
          xs: 12,
          sm: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(components_ui_component_extended_Form_FormControlSelect__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            currencies: type,
            idz: "category",
            namez: "category",
            captionLabel: "Category",
            value: formik.values.category || '',
            onChange: formik.handleChange,
            error: formik.touched.category && Boolean(formik.errors.category),
            helperText: formik.touched.category && formik.errors.category,
            fullWidth: true
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          item: true,
          xs: 12,
          sm: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(components_ui_component_extended_Form_FormControlSelect__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            currencies: propertyTypes,
            idz: "propertyType",
            namez: "propertyType",
            captionLabel: "Property Type",
            value: formik.values.propertyType || '',
            onChange: formik.handleChange,
            error: formik.touched.propertyType && Boolean(formik.errors.propertyType),
            helperText: formik.touched.propertyType && formik.errors.propertyType,
            fullWidth: true
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.TextField, {
            id: "firstName",
            name: "firstName",
            label: "First Name *",
            value: formik.values.firstName,
            onChange: formik.handleChange,
            error: formik.touched.firstName && Boolean(formik.errors.firstName),
            helperText: formik.touched.firstName && formik.errors.firstName,
            fullWidth: true,
            autoComplete: "given-name"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.TextField, {
            id: "lastName",
            name: "lastName",
            label: "Last Name *",
            value: formik.values.lastName,
            onChange: formik.handleChange,
            error: formik.touched.lastName && Boolean(formik.errors.lastName),
            helperText: formik.touched.lastName && formik.errors.lastName,
            fullWidth: true,
            autoComplete: "family-name"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.FormControlLabel, {
            control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Checkbox, {
              color: "secondary",
              name: "saveAddress",
              value: "yes"
            }),
            label: "Use this address for payment details"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack, {
            direction: "row",
            justifyContent: "flex-end",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button, {
                variant: "contained",
                sx: {
                  my: 3,
                  ml: 1
                },
                type: "submit",
                onClick: () => setErrorIndex(0),
                children: "Next"
              })
            })
          })
        })]
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddressForm);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 91193:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ GalleryForm)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_CloudUpload__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44486);
/* harmony import */ var _mui_icons_material_CloudUpload__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CloudUpload__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(91588);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var material_ui_dropzone__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(19640);
/* harmony import */ var material_ui_dropzone__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(material_ui_dropzone__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(17501);
/* harmony import */ var _material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_2__]);
components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// material-ui

 // project imports

 // third-party










const validationSchema = yup__WEBPACK_IMPORTED_MODULE_4__.object({
  size: yup__WEBPACK_IMPORTED_MODULE_4__.mixed().test(200000, 'File Size is too large', value => (value === null || value === void 0 ? void 0 : value.size) <= 2000000)
}); // styles

const ImageWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_8__.styled)('div')(({
  theme
}) => ({
  position: 'relative',
  overflow: 'hidden',
  borderRadius: '4px',
  cursor: 'pointer',
  width: '100%',
  height: 'auto',
  objectFit: 'contain',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  background: theme.palette.background.default,
  '& > svg': {
    verticalAlign: 'sub',
    marginRight: 6
  }
})); // ==============================|| FORM WIZARD - VALIDATION  ||============================== //

function GalleryForm({
  imageProperty,
  setPaymentData,
  handleNext,
  handleBack,
  setErrorIndex
}) {
  const {
    0: avatarPreview,
    1: setAvatarPreview
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)('');
  const {
    0: imgE,
    1: setEImg
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)();
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_8__.useTheme)();
  const formik = (0,formik__WEBPACK_IMPORTED_MODULE_3__.useFormik)({
    initialValues: {
      fileName: imageProperty.fileName,
      type: imageProperty.type,
      size: imageProperty.size,
      imgE: imageProperty.imgE
    },
    validationSchema,
    onSubmit: values => {
      console.log({
        fileName: values.file.name,
        type: values.file.type,
        size: `${values.file.size} bytes`
      });
      setPaymentData({
        fileName: values.file.name,
        type: values.file.type,
        size: `${values.file.size} bytes`,
        imgE: imgE
      });
      handleNext();
    }
  });

  const preViewImage = e => {
    const fileReader = new FileReader();

    fileReader.onload = () => {
      if (fileReader.readyState === 2) {
        formik.setFieldValue('file', e.target.files[0]);
        setAvatarPreview(fileReader.result);
        setEImg(e);
      }
    };

    fileReader.readAsDataURL(e.target.files[0]);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("form", {
      onSubmit: formik.handleSubmit,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
        container: true,
        spacing: 3,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          item: true,
          xs: 12,
          md: 6,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
            variant: "h5",
            gutterBottom: true,
            children: "Cover Image"
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          item: true,
          xs: 12,
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.TextField, {
              accept: "image/*",
              multiple: true,
              name: "file",
              type: "file",
              id: "file-upload",
              fullWidth: true,
              label: "Enter SKU",
              sx: {
                display: 'none'
              },
              onChange: e => {
                preViewImage(e);
              }
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.InputLabel, {
              htmlFor: "file-upload",
              sx: {
                background: theme.palette.background.default,
                py: 3.75,
                px: 0,
                textAlign: 'center',
                borderRadius: '4px',
                cursor: 'pointer',
                mb: 3,
                '& > svg': {
                  verticalAlign: 'sub',
                  mr: 0.5
                }
              },
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((_mui_icons_material_CloudUpload__WEBPACK_IMPORTED_MODULE_1___default()), {}), " Drop file here to upload"]
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(ImageWrapper, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.CardMedia, {
              component: "img",
              image: avatarPreview,
              title: "Product"
            })
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Divider, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack, {
            direction: "row",
            justifyContent: "space-between",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button, {
              onClick: handleBack,
              sx: {
                my: 3,
                ml: 1
              },
              children: "Back"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button, {
                variant: "contained",
                type: "submit",
                sx: {
                  my: 3,
                  ml: 1
                },
                onClick: () => setErrorIndex(1),
                children: "Next"
              })
            })]
          })
        })]
      })
    })
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 95505:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony export default */
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91588);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_1__]);
components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// material-ui
 // project imports

 // third-party






const validationSchema = yup__WEBPACK_IMPORTED_MODULE_3__.object({
  cardName: yup__WEBPACK_IMPORTED_MODULE_3__.string().required('First Name is required'),
  cardNumber: yup__WEBPACK_IMPORTED_MODULE_3__.string().required('Last Name is required')
}); // ==============================|| FORM WIZARD - VALIDATION  ||============================== //

function PaymentForm({
  paymentData,
  setPaymentData,
  handleNext,
  handleBack,
  setErrorIndex
}) {
  const formik = useFormik({
    initialValues: {
      cardName: paymentData.cardName,
      cardNumber: paymentData.cardNumber
    },
    validationSchema,
    onSubmit: values => {
      setPaymentData({
        cardName: values.cardName,
        cardNumber: values.cardNumber
      });
      handleNext();
    }
  });
  return /*#__PURE__*/_jsxs(_Fragment, {
    children: [/*#__PURE__*/_jsx(Typography, {
      variant: "h5",
      gutterBottom: true,
      sx: {
        mb: 2
      },
      children: "Payment method"
    }), /*#__PURE__*/_jsx("form", {
      onSubmit: formik.handleSubmit,
      children: /*#__PURE__*/_jsxs(Grid, {
        container: true,
        spacing: 3,
        children: [/*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          md: 6,
          children: /*#__PURE__*/_jsx(TextField, {
            id: "cardName",
            name: "cardName",
            value: formik.values.cardName,
            onChange: formik.handleChange,
            error: formik.touched.cardName && Boolean(formik.errors.cardName),
            helperText: formik.touched.cardName && formik.errors.cardName,
            label: "Name on card",
            fullWidth: true,
            autoComplete: "cc-name"
          })
        }), /*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          md: 6,
          children: /*#__PURE__*/_jsx(TextField, {
            id: "cardNumber",
            name: "cardNumber",
            label: "Card number",
            value: formik.values.cardNumber,
            onChange: formik.handleChange,
            error: formik.touched.cardNumber && Boolean(formik.errors.cardNumber),
            helperText: formik.touched.cardNumber && formik.errors.cardNumber,
            fullWidth: true,
            autoComplete: "cc-number"
          })
        }), /*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          md: 6,
          children: /*#__PURE__*/_jsx(TextField, {
            id: "expDate",
            label: "Expiry date",
            fullWidth: true,
            autoComplete: "cc-exp"
          })
        }), /*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          md: 6,
          children: /*#__PURE__*/_jsx(TextField, {
            id: "cvv",
            label: "CVV",
            helperText: "Last three digits on signature strip",
            fullWidth: true,
            autoComplete: "cc-csc"
          })
        }), /*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/_jsx(FormControlLabel, {
            control: /*#__PURE__*/_jsx(Checkbox, {
              color: "secondary",
              name: "saveCard",
              value: "yes"
            }),
            label: "Remember credit card details for next time"
          })
        }), /*#__PURE__*/_jsx(Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/_jsxs(Stack, {
            direction: "row",
            justifyContent: "space-between",
            children: [/*#__PURE__*/_jsx(Button, {
              onClick: handleBack,
              sx: {
                my: 3,
                ml: 1
              },
              children: "Back"
            }), /*#__PURE__*/_jsx(AnimateButton, {
              children: /*#__PURE__*/_jsx(Button, {
                variant: "contained",
                type: "submit",
                sx: {
                  my: 3,
                  ml: 1
                },
                onClick: () => setErrorIndex(1),
                children: "Next"
              })
            })]
          })
        })]
      })
    })]
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 19218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Review)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(69484);
/* harmony import */ var _mui_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
 // material-ui



 // ==============================|| FORM WIZARD - VALIDATION  ||============================== //




const products = [{
  name: 'Product 1',
  desc: 'A nice thing',
  price: '$9.99'
}, {
  name: 'Product 2',
  desc: 'Another thing',
  price: '$3.45'
}, {
  name: 'Product 3',
  desc: 'Something else',
  price: '$6.51'
}, {
  name: 'Product 4',
  desc: 'Best thing of all',
  price: '$14.11'
}, {
  name: 'Shipping',
  desc: '',
  price: 'Free'
}];
const addresses = (/* unused pure expression or super */ null && (['1 Material-UI Drive', 'Reactville', 'Anytown', '99999', 'USA']));
const payments = [{
  name: 'Card type',
  detail: 'Visa'
}, {
  name: 'Card holder',
  detail: 'Mr John Smith'
}, {
  name: 'Card number',
  detail: 'xxxx-xxxx-xxxx-1234'
}, {
  name: 'Expiry date',
  detail: '04/2024'
}]; // styles

const ImageWrapper = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)('div')(({
  theme
}) => ({
  position: 'relative',
  overflow: 'hidden',
  borderRadius: '4px',
  cursor: 'pointer',
  width: '100%',
  height: 'auto',
  objectFit: 'contain',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  background: theme.palette.background.default,
  '& > svg': {
    verticalAlign: 'sub',
    marginRight: 6
  }
}));
function Review({
  shippingData,
  imageProperty
}) {
  const theme = (0,_mui_styles__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
  const [avatarPreview, setAvatarPreview] = react__WEBPACK_IMPORTED_MODULE_0__.useState();
  const {
    firstName,
    lastName,
    category,
    propertyType
  } = shippingData;
  const {
    fileName,
    type,
    size,
    imgE
  } = imageProperty;

  const preViewImage = imgE => {
    const fileReader = new FileReader();

    fileReader.onload = () => {
      if (fileReader.readyState === 2) {
        setAvatarPreview(fileReader.result);
      }
    };

    fileReader.readAsDataURL(imgE.target.files[0]);
  };

  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {
    if (imgE !== undefined || imgE !== null) {
      preViewImage(imgE);
    }
  }, [imgE]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
      variant: "h5",
      gutterBottom: true,
      sx: {
        mb: 2
      },
      children: "Order summary"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.List, {
      disablePadding: true,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(ImageWrapper, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardMedia, {
          component: "img",
          image: avatarPreview || '',
          title: "Product"
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
        sx: {
          py: 1,
          px: 0
        },
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListItemText, {
          primary: firstName,
          secondary: lastName
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          variant: "body2",
          children: category
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
        sx: {
          py: 1,
          px: 0
        },
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListItemText, {
          primary: "Total"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          variant: "subtitle1",
          children: propertyType
        })]
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      container: true,
      spacing: 2,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        sm: 6,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          variant: "h6",
          gutterBottom: true,
          sx: {
            mt: 2
          },
          children: "Shipping"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          gutterBottom: true,
          children: "John Smith"
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        container: true,
        direction: "column",
        xs: 12,
        sm: 6,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          variant: "h6",
          gutterBottom: true,
          sx: {
            mt: 2
          },
          children: "Payment details"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          container: true
        })]
      })]
    })]
  });
}

/***/ }),

/***/ 37572:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _AddressForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(58190);
/* harmony import */ var _PaymentForm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(95505);
/* harmony import */ var _GalleryForm__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91193);
/* harmony import */ var _Review__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19218);
/* harmony import */ var components_ui_component_cards_MainCard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(32107);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(91588);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_AddressForm__WEBPACK_IMPORTED_MODULE_2__, _PaymentForm__WEBPACK_IMPORTED_MODULE_3__, _GalleryForm__WEBPACK_IMPORTED_MODULE_4__, components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__]);
([_AddressForm__WEBPACK_IMPORTED_MODULE_2__, _PaymentForm__WEBPACK_IMPORTED_MODULE_3__, _GalleryForm__WEBPACK_IMPORTED_MODULE_4__, components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // material-ui

 // project imports






 // step options




const steps = ['Fill Up Detail', 'Upload Image', 'Review your Listing'];

const getStepContent = (step, handleNext, handleBack, setErrorIndex, shippingData, setShippingData, imageProperty, setPaymentData) => {
  switch (step) {
    case 0:
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_AddressForm__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        handleNext: handleNext,
        setErrorIndex: setErrorIndex,
        shippingData: shippingData,
        setShippingData: setShippingData
      });

    case 1:
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_GalleryForm__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        handleNext: handleNext,
        handleBack: handleBack,
        setErrorIndex: setErrorIndex,
        imageProperty: imageProperty,
        setPaymentData: setPaymentData
      });

    case 2:
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Review__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        shippingData: shippingData,
        imageProperty: imageProperty
      });

    default:
      throw new Error('Unknown step');
  }
}; // ==============================|| FORMS WIZARD - BASIC ||============================== //


const ValidationWizard = () => {
  const [activeStep, setActiveStep] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(0);
  const [shippingData, setShippingData] = react__WEBPACK_IMPORTED_MODULE_0___default().useState({});
  const [imageProperty, setPaymentData] = react__WEBPACK_IMPORTED_MODULE_0___default().useState({});
  const [errorIndex, setErrorIndex] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(null);

  const handleNext = () => {
    setActiveStep(activeStep + 1);
    setErrorIndex(null);
  };

  const handleBack = () => {
    setActiveStep(activeStep - 1);
  };

  const {
    firstName,
    lastName,
    category,
    propertyType
  } = shippingData;
  const {
    fileName,
    type,
    size
  } = imageProperty;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(components_ui_component_cards_MainCard__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
    title: "Create Listing",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stepper, {
      activeStep: activeStep,
      sx: {
        pt: 3,
        pb: 5
      },
      children: steps.map((label, index) => {
        const labelProps = {};

        if (index === errorIndex) {
          labelProps.optional = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
            variant: "caption",
            color: "error",
            children: "Error"
          });
          labelProps.error = true;
        }

        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Step, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.StepLabel, _objectSpread(_objectSpread({}, labelProps), {}, {
            children: label
          }))
        }, label);
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.Fragment, {
      children: activeStep === steps.length ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          variant: "h5",
          gutterBottom: true,
          children: "Thank you for your order."
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          variant: "subtitle1",
          children: "Your order number is #2001539. We have emailed your order confirmation, and will send you an update when your order has shipped."
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
          direction: "row",
          justifyContent: "flex-end",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
              variant: "contained",
              color: "error",
              onClick: () => {
                setShippingData({});
                setPaymentData({});
                setActiveStep(0);
              },
              sx: {
                my: 3,
                ml: 1
              },
              children: "Reset"
            })
          })
        })]
      }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.Fragment, {
        children: [getStepContent(activeStep, handleNext, handleBack, setErrorIndex, shippingData, setShippingData, imageProperty, setPaymentData), activeStep === steps.length - 1 && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
          direction: "row",
          justifyContent: activeStep !== 0 ? 'space-between' : 'flex-end',
          children: [activeStep !== 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
            onClick: handleBack,
            sx: {
              my: 3,
              ml: 1
            },
            children: "Back"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
              variant: "contained",
              onClick: handleNext,
              sx: {
                my: 3,
                ml: 1
              },
              children: activeStep === steps.length - 1 ? 'Place order' : 'Next'
            })
          })]
        })]
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ValidationWizard);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;