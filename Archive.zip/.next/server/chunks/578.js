"use strict";
exports.id = 578;
exports.ids = [578];
exports.modules = {

/***/ 14146:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
// material-ui
 // ==============================|| AUTHENTICATION 1 WRAPPER ||============================== //

const AuthWrapper1 = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({
  theme
}) => ({
  backgroundColor: theme.palette.mode === 'dark' ? theme.palette.background.default : theme.palette.primary.light,
  minHeight: '100vh'
}));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthWrapper1);

/***/ }),

/***/ 65252:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
// material-ui

 // assets


const AuthPattern = '/assets/images/auth/auth-pattern.svg';
const AuthPatternDark = '/assets/images/auth/auth-pattern-dark.svg'; // ===========================|| BACKGROUND GRID PATTERN 1 ||=========================== //

const BackgroundPattern1 = ({
  children
}) => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
    component: "span",
    sx: {
      display: 'flex',
      minHeight: '100vh',
      bgcolor: theme.palette.mode === 'dark' ? theme.palette.dark.dark : '#fff',
      backgroundImage: theme.palette.mode === 'dark' ? `url(${AuthPatternDark})` : `url(${AuthPattern})`,
      position: 'absolute',
      backgroundPosition: '0 0',
      overflow: 'hidden',
      m: '0 0 0 auto',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      opacity: theme.palette.mode === 'dark' ? 0.85 : 0.9
    },
    children: children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BackgroundPattern1);

/***/ })

};
;