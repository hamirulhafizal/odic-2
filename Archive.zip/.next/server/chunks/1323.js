exports.id = 1323;
exports.ids = [1323];
exports.modules = {

/***/ 47372:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks_useConfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20132);
/* harmony import */ var components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(22278);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
// material-ui

 // project imports


 // concat 'px'




function valueText(value) {
  return `${value}px`;
}

const BorderRadius = () => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  const {
    borderRadius,
    onChangeBorderRadius
  } = (0,hooks_useConfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
    title: "Border Radius",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      item: true,
      xs: 12,
      container: true,
      spacing: 2,
      alignItems: "center",
      sx: {
        mt: 2.5
      },
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          variant: "h6",
          color: "secondary",
          children: "4px"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Slider, {
          size: "small",
          value: borderRadius,
          onChange: onChangeBorderRadius,
          getAriaValueText: valueText,
          valueLabelDisplay: "on",
          "aria-labelledby": "discrete-slider-small-steps",
          marks: true,
          step: 2,
          min: 4,
          max: 24,
          color: "secondary",
          sx: {
            '& .MuiSlider-valueLabel': {
              color: theme.palette.mode === 'dark' ? 'secondary.dark' : 'secondary.light'
            }
          }
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          variant: "h6",
          color: "secondary",
          children: "24px"
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BorderRadius);

/***/ }),

/***/ 25273:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var hooks_useConfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20132);
/* harmony import */ var components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(22278);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
// material-ui
 // project imports





const BoxContainer = () => {
  const {
    container,
    onChangeContainer
  } = (0,hooks_useConfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
    title: "Box Container",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.FormControl, {
      component: "fieldset",
      sx: {
        mt: 2
      },
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.FormControlLabel, {
        control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Switch, {
          checked: container,
          onChange: () => onChangeContainer(),
          inputProps: {
            'aria-label': 'controlled-direction'
          }
        }),
        label: "Container"
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BoxContainer);

/***/ }),

/***/ 8730:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks_useConfig__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20132);
/* harmony import */ var components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22278);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
 // material-ui


 // project imports






const FontFamily = () => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
  const {
    fontFamily,
    onChangeFontFamily
  } = (0,hooks_useConfig__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
  let initialFont;

  switch (fontFamily) {
    case `'Inter', sans-serif`:
      initialFont = 'Inter';
      break;

    case `'Poppins', sans-serif`:
      initialFont = 'Poppins';
      break;

    case `'Roboto', sans-serif`:
    default:
      initialFont = 'Roboto';
      break;
  } // state - font family


  const {
    0: font,
    1: setFont
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialFont);

  const handleFont = event => {
    setFont(event.target.value);
    onChangeFontFamily(event.target.value);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
    title: "Font Family",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControl, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.RadioGroup, {
        "aria-label": "font-family",
        value: font,
        onChange: handleFont,
        name: "row-radio-buttons-group",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControlLabel, {
          value: "Roboto",
          control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Radio, {}),
          label: "Roboto",
          sx: {
            '& .MuiSvgIcon-root': {
              fontSize: 28
            },
            '& .MuiFormControlLabel-label': {
              color: theme.palette.grey[900]
            }
          }
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControlLabel, {
          value: "Poppins",
          control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Radio, {}),
          label: "Poppins",
          sx: {
            '& .MuiSvgIcon-root': {
              fontSize: 28
            },
            '& .MuiFormControlLabel-label': {
              color: theme.palette.grey[900]
            }
          }
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControlLabel, {
          value: "Inter",
          control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Radio, {}),
          label: "Inter",
          sx: {
            '& .MuiSvgIcon-root': {
              fontSize: 28
            },
            '& .MuiFormControlLabel-label': {
              color: theme.palette.grey[900]
            }
          }
        })]
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FontFamily);

/***/ }),

/***/ 93418:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var hooks_useConfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20132);
/* harmony import */ var components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(22278);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
// material-ui
 // project imports






const InputFilled = () => {
  const {
    outlinedFilled,
    onChangeOutlinedField
  } = (0,hooks_useConfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
    title: "Input Outlined With Filled",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
      item: true,
      xs: 12,
      container: true,
      spacing: 2,
      alignItems: "center",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
        item: true,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack, {
          spacing: 2,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Switch, {
            checked: outlinedFilled,
            onChange: event => onChangeOutlinedField(event.target.checked),
            inputProps: {
              'aria-label': 'controlled'
            }
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.TextField, {
            fullWidth: true,
            id: "outlined-basic",
            label: outlinedFilled ? 'With Background' : 'Without Background'
          })]
        })
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputFilled);

/***/ }),

/***/ 19470:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks_useConfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20132);
/* harmony import */ var components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(22278);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
// material-ui

 // project imports






const Layout = () => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  const {
    navType,
    rtlLayout,
    onChangeMenuType,
    onChangeRTL
  } = (0,hooks_useConfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
    title: "Layout",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
      component: "fieldset",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
        component: "legend",
        children: "Mode"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.RadioGroup, {
        row: true,
        "aria-label": "layout",
        value: navType,
        onChange: e => onChangeMenuType(e.target.value),
        name: "row-radio-buttons-group",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, {
          value: "light",
          control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Radio, {}),
          label: "Light",
          sx: {
            '& .MuiSvgIcon-root': {
              fontSize: 28
            },
            '& .MuiFormControlLabel-label': {
              color: theme.palette.grey[900]
            }
          }
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, {
          value: "dark",
          control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Radio, {}),
          label: "Dark",
          sx: {
            '& .MuiSvgIcon-root': {
              fontSize: 28
            },
            '& .MuiFormControlLabel-label': {
              color: theme.palette.grey[900]
            }
          }
        })]
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
      component: "fieldset",
      sx: {
        mt: 2
      },
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
        component: "legend",
        children: "Direction"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, {
        control: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Switch, {
          checked: rtlLayout,
          onChange: event => onChangeRTL(event.target.checked),
          inputProps: {
            'aria-label': 'controlled-direction'
          }
        }),
        label: "RTL"
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

/***/ }),

/***/ 5377:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(94116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks_useConfig__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20132);
/* harmony import */ var components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22278);
/* harmony import */ var _scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(70045);
/* harmony import */ var _scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _scss_theme1_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(85546);
/* harmony import */ var _scss_theme1_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_scss_theme1_module_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _scss_theme2_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(12694);
/* harmony import */ var _scss_theme2_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_scss_theme2_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _scss_theme3_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9253);
/* harmony import */ var _scss_theme3_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_scss_theme3_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _scss_theme4_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(39428);
/* harmony import */ var _scss_theme4_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_scss_theme4_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _scss_theme5_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(41133);
/* harmony import */ var _scss_theme5_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_scss_theme5_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _scss_theme6_module_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(18742);
/* harmony import */ var _scss_theme6_module_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_scss_theme6_module_scss__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
// material-ui


 // project imports


 // color import










const PresetColorBox = ({
  color,
  presetColor,
  setPresetColor
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
  item: true,
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
    variant: "rounded",
    color: "inherit",
    sx: {
      background: `linear-gradient(135deg, ${color.primary} 50%, ${color.secondary} 50%)`,
      opacity: presetColor === color.id ? 0.6 : 1,
      cursor: 'pointer'
    },
    onClick: () => setPresetColor(color.id),
    children: presetColor === color.id && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__.IconChecks, {
      color: "#fff"
    })
  })
});

const PresetColor = () => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
  const {
    presetColor,
    onChangePresetColor
  } = (0,hooks_useConfig__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
  const colorOptions = [{
    id: 'default',
    primary: theme.palette.mode === 'dark' ? (_scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_6___default().darkPrimaryMain) : (_scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_6___default().primaryMain),
    secondary: theme.palette.mode === 'dark' ? (_scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_6___default().darkSecondaryMain) : (_scss_themes_vars_module_scss__WEBPACK_IMPORTED_MODULE_6___default().secondaryMain)
  }, {
    id: 'theme1',
    primary: theme.palette.mode === 'dark' ? (_scss_theme1_module_scss__WEBPACK_IMPORTED_MODULE_7___default().darkPrimaryMain) : (_scss_theme1_module_scss__WEBPACK_IMPORTED_MODULE_7___default().primaryMain),
    secondary: theme.palette.mode === 'dark' ? (_scss_theme1_module_scss__WEBPACK_IMPORTED_MODULE_7___default().darkSecondaryMain) : (_scss_theme1_module_scss__WEBPACK_IMPORTED_MODULE_7___default().secondaryMain)
  }, {
    id: 'theme2',
    primary: theme.palette.mode === 'dark' ? (_scss_theme2_module_scss__WEBPACK_IMPORTED_MODULE_8___default().darkPrimaryMain) : (_scss_theme2_module_scss__WEBPACK_IMPORTED_MODULE_8___default().primaryMain),
    secondary: theme.palette.mode === 'dark' ? (_scss_theme2_module_scss__WEBPACK_IMPORTED_MODULE_8___default().darkSecondaryMain) : (_scss_theme2_module_scss__WEBPACK_IMPORTED_MODULE_8___default().secondaryMain)
  }, {
    id: 'theme3',
    primary: theme.palette.mode === 'dark' ? (_scss_theme3_module_scss__WEBPACK_IMPORTED_MODULE_9___default().darkPrimaryMain) : (_scss_theme3_module_scss__WEBPACK_IMPORTED_MODULE_9___default().primaryMain),
    secondary: theme.palette.mode === 'dark' ? (_scss_theme3_module_scss__WEBPACK_IMPORTED_MODULE_9___default().darkSecondaryMain) : (_scss_theme3_module_scss__WEBPACK_IMPORTED_MODULE_9___default().secondaryMain)
  }, {
    id: 'theme4',
    primary: theme.palette.mode === 'dark' ? (_scss_theme4_module_scss__WEBPACK_IMPORTED_MODULE_10___default().darkPrimaryMain) : (_scss_theme4_module_scss__WEBPACK_IMPORTED_MODULE_10___default().primaryMain),
    secondary: theme.palette.mode === 'dark' ? (_scss_theme4_module_scss__WEBPACK_IMPORTED_MODULE_10___default().darkSecondaryMain) : (_scss_theme4_module_scss__WEBPACK_IMPORTED_MODULE_10___default().secondaryMain)
  }, {
    id: 'theme5',
    primary: theme.palette.mode === 'dark' ? (_scss_theme5_module_scss__WEBPACK_IMPORTED_MODULE_11___default().darkPrimaryMain) : (_scss_theme5_module_scss__WEBPACK_IMPORTED_MODULE_11___default().primaryMain),
    secondary: theme.palette.mode === 'dark' ? (_scss_theme5_module_scss__WEBPACK_IMPORTED_MODULE_11___default().darkSecondaryMain) : (_scss_theme5_module_scss__WEBPACK_IMPORTED_MODULE_11___default().secondaryMain)
  }, {
    id: 'theme6',
    primary: theme.palette.mode === 'dark' ? (_scss_theme6_module_scss__WEBPACK_IMPORTED_MODULE_12___default().darkPrimaryMain) : (_scss_theme6_module_scss__WEBPACK_IMPORTED_MODULE_12___default().primaryMain),
    secondary: theme.palette.mode === 'dark' ? (_scss_theme6_module_scss__WEBPACK_IMPORTED_MODULE_12___default().darkSecondaryMain) : (_scss_theme6_module_scss__WEBPACK_IMPORTED_MODULE_12___default().secondaryMain)
  }];
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(components_ui_component_cards_SubCard__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
    title: "Preset Color",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      item: true,
      container: true,
      spacing: 2,
      alignItems: "center",
      children: colorOptions.map((color, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(PresetColorBox, {
        color: color,
        presetColor: presetColor,
        setPresetColor: onChangePresetColor
      }, index))
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PresetColor);

/***/ }),

/***/ 91323:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(94116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(55162);
/* harmony import */ var react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _BorderRadius__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(47372);
/* harmony import */ var _Layout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(19470);
/* harmony import */ var _PresetColor__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5377);
/* harmony import */ var _FontFamily__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8730);
/* harmony import */ var _InputFilled__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(93418);
/* harmony import */ var _BoxContainer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(25273);
/* harmony import */ var components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(91588);
/* harmony import */ var store_constant__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(49514);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_11__]);
components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_11__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
 // material-ui



 // third-party

 // project imports








 // ==============================|| LIVE CUSTOMIZATION ||============================== //





const Customization = () => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)(); // drawer on/off

  const {
    0: open,
    1: setOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const handleToggle = () => {
    setOpen(!open);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
      title: "Live Customize",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Fab, {
        component: "div",
        onClick: handleToggle,
        size: "medium",
        variant: "circular",
        color: "secondary",
        sx: {
          borderRadius: 0,
          borderTopLeftRadius: '50%',
          borderBottomLeftRadius: '50%',
          borderTopRightRadius: '50%',
          borderBottomRightRadius: '4px',
          top: '25%',
          position: 'fixed',
          right: 10,
          zIndex: theme.zIndex.speedDial,
          boxShadow: theme.customShadows.secondary
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(components_ui_component_extended_AnimateButton__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
          type: "rotate",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
            color: "inherit",
            size: "large",
            disableRipple: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_3__.IconSettings, {})
          })
        })
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Drawer, {
      anchor: "right",
      onClose: handleToggle,
      open: open,
      PaperProps: {
        sx: {
          width: 280
        }
      },
      children: open && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_4___default()), {
        component: "div",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          container: true,
          spacing: store_constant__WEBPACK_IMPORTED_MODULE_13__/* .gridSpacing */ .dv,
          sx: {
            p: 3
          },
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_Layout__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_PresetColor__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_FontFamily__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_BorderRadius__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_InputFilled__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {})
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_BoxContainer__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
          })]
        })
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Customization);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 85546:
/***/ ((module) => {

// Exports
module.exports = {
	"paper": "#fff",
	"primaryLight": "#eceff1",
	"primary200": "#b0bec5",
	"primaryMain": "#607d8b",
	"primaryDark": "#546e7a",
	"primary800": "#455a64",
	"secondaryLight": "#e0f2f1",
	"secondary200": "#80cbc4",
	"secondaryMain": "#009688",
	"secondaryDark": "#00897b",
	"secondary800": "#00695c",
	"successLight": "#edf7ed",
	"success200": "#b6e0b3",
	"successMain": "#6cc067",
	"successDark": "#64ba5f",
	"errorLight": "#e48784",
	"errorMain": "#d9534f",
	"errorDark": "#d54c48",
	"orangeLight": "#fbe9e7",
	"orangeMain": "#ffab91",
	"orangeDark": "#d84315",
	"warningLight": "#fdf5ea",
	"warningMain": "#f0ad4e",
	"warningDark": "#ec9c3d",
	"grey50": "#fafafa",
	"grey100": "#f5f5f5",
	"grey200": "#eee",
	"grey300": "#e0e0e0",
	"grey500": "#9e9e9e",
	"grey600": "#757575",
	"grey700": "#616161",
	"grey900": "#212121",
	"darkPaper": "#060d12",
	"darkBackground": "#0e1b23",
	"darkLevel1": "#0b161d",
	"darkLevel2": "#14252f",
	"darkTextTitle": "#e4e8f7",
	"darkTextPrimary": "#d5d9e9",
	"darkTextSecondary": "#d8ddf0",
	"darkPrimaryLight": "#eceff1",
	"darkPrimaryMain": "#78919c",
	"darkPrimaryDark": "#587583",
	"darkPrimary200": "#b0bec5",
	"darkPrimary800": "#44606e",
	"darkSecondaryLight": "#e0f2f1",
	"darkSecondaryMain": "#009688",
	"darkSecondaryDark": "#00897b",
	"darkSecondary200": "#80cbc4",
	"darkSecondary800": "#00695c"
};


/***/ }),

/***/ 12694:
/***/ ((module) => {

// Exports
module.exports = {
	"paper": "#fff",
	"primaryLight": "#e4e7ec",
	"primary200": "#909ab0",
	"primaryMain": "#203461",
	"primaryDark": "#1c2f59",
	"primary800": "#132145",
	"secondaryLight": "#fde8ef",
	"secondary200": "#f6a0bd",
	"secondaryMain": "#ec407a",
	"secondaryDark": "#ea3a72",
	"secondary800": "#e42a5d",
	"successLight": "#e3f8e8",
	"success200": "#8be09f",
	"successMain": "#17c13e",
	"successDark": "#14bb38",
	"errorLight": "#e48784",
	"errorMain": "#d9534f",
	"errorDark": "#d54c48",
	"orangeLight": "#fbe9e7",
	"orangeMain": "#ffab91",
	"orangeDark": "#d84315",
	"warningLight": "#fdf5ea",
	"warningMain": "#f0ad4e",
	"warningDark": "#ec9c3d",
	"grey50": "#fafafa",
	"grey100": "#f5f5f5",
	"grey200": "#eee",
	"grey300": "#e0e0e0",
	"grey500": "#9e9e9e",
	"grey600": "#757575",
	"grey700": "#616161",
	"grey900": "#212121",
	"darkPaper": "#030614",
	"darkBackground": "#0a0f23",
	"darkLevel1": "#070e13",
	"darkLevel2": "#12172f",
	"darkTextTitle": "#e4e8f7",
	"darkTextPrimary": "#d5d9e9",
	"darkTextSecondary": "#d8ddf0",
	"darkPrimaryLight": "#ecedf1",
	"darkPrimaryMain": "#606d88",
	"darkPrimaryDark": "#586580",
	"darkPrimary200": "#b0b6c4",
	"darkPrimary800": "#44506b",
	"darkSecondaryLight": "#fde8ef",
	"darkSecondaryMain": "#ec407a",
	"darkSecondaryDark": "#ea3a72",
	"darkSecondary200": "#f6a0bd",
	"darkSecondary800": "#e42a5d"
};


/***/ }),

/***/ 9253:
/***/ ((module) => {

// Exports
module.exports = {
	"paper": "#fff",
	"primaryLight": "#e3ebeb",
	"primary200": "#8bacad",
	"primaryMain": "#16595a",
	"primaryDark": "#135152",
	"primary800": "#0c3e3f",
	"secondaryLight": "#f8f0e5",
	"secondary200": "#e3bf91",
	"secondaryMain": "#c77e23",
	"secondaryDark": "#c1761f",
	"secondary800": "#b36115",
	"successLight": "#b9f6ca",
	"success200": "#69f0ae",
	"successMain": "#00e676",
	"successDark": "#00c853",
	"errorLight": "#ef9a9a",
	"errorMain": "#f44336",
	"errorDark": "#c62828",
	"orangeLight": "#fbe9e7",
	"orangeMain": "#ffab91",
	"orangeDark": "#d84315",
	"warningLight": "#fff8e1",
	"warningMain": "#ffe57f",
	"warningDark": "#ffc107",
	"grey50": "#fafafa",
	"grey100": "#f5f5f5",
	"grey200": "#eee",
	"grey300": "#e0e0e0",
	"grey500": "#9e9e9e",
	"grey600": "#757575",
	"grey700": "#616161",
	"grey900": "#212121",
	"darkPaper": "#010f17",
	"darkBackground": "#010606",
	"darkLevel1": "#02131d",
	"darkLevel2": "#010f17",
	"darkTextTitle": "#fff",
	"darkTextPrimary": "#fff",
	"darkTextSecondary": "#8492c4",
	"darkPrimaryLight": "#eceff1",
	"darkPrimaryMain": "#1f7778",
	"darkPrimaryDark": "#1b6f70",
	"darkPrimary200": "#8fbbbc",
	"darkPrimary800": "#125a5b",
	"darkSecondaryLight": "#f8f0e5",
	"darkSecondaryMain": "#c77e23",
	"darkSecondaryDark": "#c1761f",
	"darkSecondary200": "#e3bf91",
	"darkSecondary800": "#b36115"
};


/***/ }),

/***/ 39428:
/***/ ((module) => {

// Exports
module.exports = {
	"paper": "#fff",
	"primaryLight": "#e3e8e8",
	"primary200": "#8b9fa1",
	"primaryMain": "#173e43",
	"primaryDark": "#14383d",
	"primary800": "#0d282c",
	"secondaryLight": "#e8f6f5",
	"secondary200": "#9fd8d6",
	"secondaryMain": "#3fb0ac",
	"secondaryDark": "#39a9a5",
	"secondary800": "#299792",
	"successLight": "#b9f6ca",
	"success200": "#69f0ae",
	"successMain": "#00e676",
	"successDark": "#00c853",
	"errorLight": "#ef9a9a",
	"errorMain": "#f44336",
	"errorDark": "#c62828",
	"orangeLight": "#fbe9e7",
	"orangeMain": "#ffab91",
	"orangeDark": "#d84315",
	"warningLight": "#fff8e1",
	"warningMain": "#ffe57f",
	"warningDark": "#ffc107",
	"grey50": "#fafafa",
	"grey100": "#f5f5f5",
	"grey200": "#eee",
	"grey300": "#e0e0e0",
	"grey500": "#9e9e9e",
	"grey600": "#757575",
	"grey700": "#616161",
	"grey900": "#212121",
	"darkPaper": "#051114",
	"darkBackground": "#030708",
	"darkLevel1": "#02131d",
	"darkLevel2": "#051114",
	"darkTextTitle": "#fff",
	"darkTextPrimary": "#fff",
	"darkTextSecondary": "#ccd2eb",
	"darkPrimaryLight": "#e3e8e8",
	"darkPrimaryMain": "#3a5b5f",
	"darkPrimaryDark": "#14383d",
	"darkPrimary200": "#8b9fa1",
	"darkPrimary800": "#0d282c",
	"darkSecondaryLight": "#e8f6f5",
	"darkSecondaryMain": "#3fb0ac",
	"darkSecondaryDark": "#39a9a5",
	"darkSecondary200": "#9fd8d6",
	"darkSecondary800": "#299792"
};


/***/ }),

/***/ 41133:
/***/ ((module) => {

// Exports
module.exports = {
	"paper": "#fff",
	"primaryLight": "#e2e5e8",
	"primary200": "#8591a1",
	"primaryMain": "#0a2342",
	"primaryDark": "#091f3c",
	"primary800": "#05152b",
	"secondaryLight": "#e6f4f1",
	"secondary200": "#96d2c6",
	"secondaryMain": "#2ca58d",
	"secondaryDark": "#279d85",
	"secondary800": "#1b8a70",
	"successLight": "#b9f6ca",
	"success200": "#69f0ae",
	"successMain": "#00e676",
	"successDark": "#00c853",
	"errorLight": "#ef9a9a",
	"errorMain": "#f44336",
	"errorDark": "#c62828",
	"orangeLight": "#fbe9e7",
	"orangeMain": "#ffab91",
	"orangeDark": "#d84315",
	"warningLight": "#fff8e1",
	"warningMain": "#ffe57f",
	"warningDark": "#ffc107",
	"grey50": "#fafafa",
	"grey100": "#f5f5f5",
	"grey200": "#eee",
	"grey300": "#e0e0e0",
	"grey500": "#9e9e9e",
	"grey600": "#757575",
	"grey700": "#616161",
	"grey900": "#212121",
	"darkPaper": "#030c1d",
	"darkBackground": "#051327",
	"darkLevel1": "#071a33",
	"darkLevel2": "#091f3c",
	"darkTextTitle": "#d7dcec",
	"darkTextPrimary": "#bdc8f0",
	"darkTextSecondary": "#8492c4",
	"darkPrimaryLight": "#e2e5e8",
	"darkPrimaryMain": "#54657b",
	"darkPrimaryDark": "#2f445e",
	"darkPrimary200": "#8591a1",
	"darkPrimary800": "#05152b",
	"darkSecondaryLight": "#e6f4f1",
	"darkSecondaryMain": "#2ca58d",
	"darkSecondaryDark": "#279d85",
	"darkSecondary200": "#96d2c6",
	"darkSecondary800": "#1b8a70"
};


/***/ }),

/***/ 18742:
/***/ ((module) => {

// Exports
module.exports = {
	"paper": "#fff",
	"primaryLight": "#e8eaf6",
	"primary200": "#9fa8da",
	"primaryMain": "#3f51b5",
	"primaryDark": "#3949ab",
	"primary800": "#283593",
	"secondaryLight": "#e8eaf6",
	"secondary200": "#9fa8da",
	"secondaryMain": "#3f51b5",
	"secondaryDark": "#3949ab",
	"secondary800": "#283593",
	"successLight": "#b9f6ca",
	"success200": "#69f0ae",
	"successMain": "#00e676",
	"successDark": "#00c853",
	"errorLight": "#ef9a9a",
	"errorMain": "#f44336",
	"errorDark": "#c62828",
	"orangeLight": "#fbe9e7",
	"orangeMain": "#ffab91",
	"orangeDark": "#d84315",
	"warningLight": "#fff8e1",
	"warningMain": "#ffe57f",
	"warningDark": "#ffc107",
	"grey50": "#fafafa",
	"grey100": "#f5f5f5",
	"grey200": "#eee",
	"grey300": "#e0e0e0",
	"grey500": "#9e9e9e",
	"grey600": "#757575",
	"grey700": "#616161",
	"grey900": "#212121",
	"darkPaper": "#111936",
	"darkBackground": "#1a223f",
	"darkLevel1": "#29314f",
	"darkLevel2": "#212946",
	"darkTextTitle": "#d7dcec",
	"darkTextPrimary": "#bdc8f0",
	"darkTextSecondary": "#8492c4",
	"darkPrimaryLight": "#eeedfd",
	"darkPrimaryMain": "#7267ef",
	"darkPrimaryDark": "#6a5fed",
	"darkPrimary200": "#b9b3f7",
	"darkPrimary800": "#554ae8",
	"darkSecondaryLight": "#eeedfd",
	"darkSecondaryMain": "#7267ef",
	"darkSecondaryDark": "#6a5fed",
	"darkSecondary200": "#b9b3f7",
	"darkSecondary800": "#554ae8"
};


/***/ })

};
;